﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

// Token: 0x0200000D RID: 13
[DebuggerNonUserCode]
[CompilerGenerated]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
internal class Class7
{
	// Token: 0x06000065 RID: 101 RVA: 0x000088A2 File Offset: 0x00006AA2
	internal Class7()
	{
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000066 RID: 102 RVA: 0x00008A84 File Offset: 0x00006C84
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager_0
	{
		get
		{
			bool flag = Class7.resourceManager_0 == null;
			if (flag)
			{
				ResourceManager resourceManager = new ResourceManager("%<>\\&uqjB@v5oYB1gA:'QuNR/)", typeof(Class7).Assembly);
				Class7.resourceManager_0 = resourceManager;
			}
			return Class7.resourceManager_0;
		}
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000067 RID: 103 RVA: 0x00008ACC File Offset: 0x00006CCC
	// (set) Token: 0x06000068 RID: 104 RVA: 0x00008AE3 File Offset: 0x00006CE3
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo CultureInfo_0
	{
		get
		{
			return Class7.cultureInfo_0;
		}
		set
		{
			Class7.cultureInfo_0 = value;
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x06000069 RID: 105 RVA: 0x00008AEC File Offset: 0x00006CEC
	internal static byte[] Byte_0
	{
		get
		{
			object @object = Class7.ResourceManager_0.GetObject("gaster", Class7.cultureInfo_0);
			return (byte[])@object;
		}
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x0600006A RID: 106 RVA: 0x00008B1C File Offset: 0x00006D1C
	internal static byte[] Byte_1
	{
		get
		{
			object @object = Class7.ResourceManager_0.GetObject("libcrypto_1_1_x64", Class7.cultureInfo_0);
			return (byte[])@object;
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x0600006B RID: 107 RVA: 0x00008B4C File Offset: 0x00006D4C
	internal static byte[] Byte_2
	{
		get
		{
			object @object = Class7.ResourceManager_0.GetObject("libssl_1_1_x64", Class7.cultureInfo_0);
			return (byte[])@object;
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x0600006C RID: 108 RVA: 0x00008B7C File Offset: 0x00006D7C
	internal static byte[] Byte_3
	{
		get
		{
			object @object = Class7.ResourceManager_0.GetObject("libusb_1_0", Class7.cultureInfo_0);
			return (byte[])@object;
		}
	}

	// Token: 0x04000030 RID: 48
	private static ResourceManager resourceManager_0;

	// Token: 0x04000031 RID: 49
	private static CultureInfo cultureInfo_0;
}
