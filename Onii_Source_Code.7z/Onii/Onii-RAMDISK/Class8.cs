﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

// Token: 0x0200000E RID: 14
internal class Class8
{
	// Token: 0x0600006D RID: 109 RVA: 0x00008BAC File Offset: 0x00006DAC
	public void method_0(string string_0, string string_1, string string_2)
	{
		using (Aes aes = Aes.Create())
		{
			byte[] bytes = Encoding.UTF8.GetBytes(string_2);
			Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(bytes, new byte[8], 1000);
			aes.Key = rfc2898DeriveBytes.GetBytes(aes.KeySize / 8);
			aes.IV = rfc2898DeriveBytes.GetBytes(aes.BlockSize / 8);
			using (FileStream fileStream = new FileStream(string_0, FileMode.Open))
			{
				using (FileStream fileStream2 = new FileStream(string_1, FileMode.Create))
				{
					using (CryptoStream cryptoStream = new CryptoStream(fileStream2, aes.CreateEncryptor(), CryptoStreamMode.Write))
					{
						fileStream.CopyTo(cryptoStream);
					}
				}
			}
		}
	}

	// Token: 0x0600006E RID: 110 RVA: 0x00008CA8 File Offset: 0x00006EA8
	public void method_1(string string_0, string string_1, string string_2)
	{
		using (Aes aes = Aes.Create())
		{
			byte[] bytes = Encoding.UTF8.GetBytes(string_2);
			Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(bytes, new byte[8], 1000);
			aes.Key = rfc2898DeriveBytes.GetBytes(aes.KeySize / 8);
			aes.IV = rfc2898DeriveBytes.GetBytes(aes.BlockSize / 8);
			using (FileStream fileStream = new FileStream(string_0, FileMode.Open))
			{
				using (CryptoStream cryptoStream = new CryptoStream(fileStream, aes.CreateDecryptor(), CryptoStreamMode.Read))
				{
					using (FileStream fileStream2 = new FileStream(string_1, FileMode.Create))
					{
						cryptoStream.CopyTo(fileStream2);
					}
				}
			}
		}
	}
}
