﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

// Token: 0x02000013 RID: 19
public class GClass0
{
	// Token: 0x17000009 RID: 9
	// (get) Token: 0x060000D1 RID: 209 RVA: 0x0000F974 File Offset: 0x0000DB74
	// (set) Token: 0x060000D2 RID: 210 RVA: 0x0000F97C File Offset: 0x0000DB7C
	private string String_0 { get; set; }

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x060000D3 RID: 211 RVA: 0x0000F985 File Offset: 0x0000DB85
	// (set) Token: 0x060000D4 RID: 212 RVA: 0x0000F98D File Offset: 0x0000DB8D
	private string String_1 { get; set; }

	// Token: 0x060000D5 RID: 213 RVA: 0x0000F998 File Offset: 0x0000DB98
	private string method_0(string string_2)
	{
		return string.Join("", Encoding.GetEncoding("BIG5").GetBytes(string_2).Select(new Func<byte, string>(GClass0.Class5.ab9.method_0)));
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x0000F9DC File Offset: 0x0000DBDC
	private byte[] method_1(string string_2)
	{
		bool flag = string_2.Length % 2 == 0;
		if (flag)
		{
			byte[] array = new byte[string_2.Length / 2];
			for (int i = 0; i < array.Length; i++)
			{
				string text = string_2.Substring(i * 2, 2);
				array[i] = byte.Parse(text, NumberStyles.HexNumber, CultureInfo.InvariantCulture);
			}
			return array;
		}
		throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, "The binary key cannot have an odd number of digits: {0}", string_2));
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x0000FA5C File Offset: 0x0000DC5C
	private string method_2(string string_2)
	{
		byte[] array = new byte[0];
		array = ((!string_2.Contains("0x")) ? this.method_1(Regex.Replace(string_2, " ", string.Empty).Normalize().Trim()) : this.method_1(Regex.Replace(string_2, "0x|[ ,]", string.Empty).Normalize().Trim()));
		return Encoding.ASCII.GetString(array);
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x0000FAD0 File Offset: 0x0000DCD0
	private void method_3(string string_2)
	{
		try
		{
			Process[] processes = Process.GetProcesses();
			Process[] array = processes;
			foreach (Process process in array)
			{
				bool flag = process.ProcessName.ToLower().Contains(string_2);
				if (flag)
				{
					process.Kill();
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x0000FB3C File Offset: 0x0000DD3C
	public void method_4()
	{
		this.method_3("gaster");
		try
		{
			bool flag = Directory.Exists(this.String_0);
			if (flag)
			{
				Directory.Delete(this.String_0, true);
			}
		}
		catch
		{
		}
	}

	// Token: 0x060000DA RID: 218 RVA: 0x0000FB90 File Offset: 0x0000DD90
	public void method_5()
	{
		try
		{
			this.method_3("gaster");
			Console.WriteLine("Go To PWN");
			Process process = new Process
			{
				StartInfo = new ProcessStartInfo
				{
					UseShellExecute = false,
					CreateNoWindow = true,
					FileName = this.String_1,
					Verb = "runas",
					Arguments = "pwn",
					WorkingDirectory = Path.GetDirectoryName(this.String_1),
					RedirectStandardOutput = true,
					RedirectStandardError = true
				}
			};
			process.Start();
			process.WaitForExit();
		}
		catch (Exception ex)
		{
			throw new Exception(ex.Message);
		}
	}

	// Token: 0x060000DB RID: 219 RVA: 0x0000FC50 File Offset: 0x0000DE50
	public void method_6()
	{
		try
		{
			this.method_3("gaster");
			Console.WriteLine("GASTER");
			byte[] byte_ = Class7.Byte_0;
			byte[] byte_2 = Class7.Byte_1;
			byte[] byte_3 = Class7.Byte_3;
			this.String_0 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), this.method_0(SystemInformation.ComputerName));
			bool flag = Directory.Exists(this.String_0);
			if (flag)
			{
				Directory.Delete(this.String_0, true);
			}
			bool flag2 = !Directory.Exists(this.String_0);
			if (flag2)
			{
				Directory.CreateDirectory(this.String_0);
			}
			this.String_1 = Path.Combine(this.String_0, "gaster.exe");
			string text = Path.Combine(this.String_0, "gaster.exe");
			string text2 = Path.Combine(this.String_0, "libcrypto-1_1-x64.dll");
			string text3 = Path.Combine(this.String_0, "libusb-1.0.dll");
			bool flag3 = !File.Exists(text);
			if (flag3)
			{
				File.WriteAllBytes(text, byte_);
			}
			bool flag4 = !File.Exists(text2);
			if (flag4)
			{
				File.WriteAllBytes(text2, byte_2);
			}
			bool flag5 = !File.Exists(text3);
			if (flag5)
			{
				File.WriteAllBytes(text3, byte_3);
			}
		}
		catch
		{
			try
			{
				this.method_6();
			}
			catch
			{
				throw new Exception("database output Lỗi ");
			}
		}
	}

	// Token: 0x0400009B RID: 155
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_0;

	// Token: 0x0400009C RID: 156
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_1;

	// Token: 0x02000021 RID: 33
	[CompilerGenerated]
	[Serializable]
	private sealed class Class5
	{
		// Token: 0x06000105 RID: 261 RVA: 0x000106B0 File Offset: 0x0000E8B0
		internal string method_0(byte byte_0)
		{
			return string.Format("{0:X2}", byte_0);
		}

		// Token: 0x040000B8 RID: 184
		public static readonly GClass0.Class5 ab9 = new GClass0.Class5();

		// Token: 0x040000B9 RID: 185
		public static Func<byte, string> ab9__8_0;
	}
}
