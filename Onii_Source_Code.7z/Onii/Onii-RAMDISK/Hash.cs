﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x0200000B RID: 11
[CompilerGenerated]
internal sealed class Hash
{
	// Token: 0x06000053 RID: 83 RVA: 0x00008914 File Offset: 0x00006B14
	internal static uint smethod_0(string string_0)
	{
		uint num = 0U;
		bool flag = string_0 != null;
		if (flag)
		{
			num = 2166136261U;
			for (int i = 0; i < string_0.Length; i++)
			{
				num = ((uint)string_0[i] ^ num) * 16777619U;
			}
		}
		return num;
	}
}
