﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ionic.Zip;

// Token: 0x02000004 RID: 4
internal class Class17
{
	// Token: 0x06000013 RID: 19 RVA: 0x00002C7C File Offset: 0x00000E7C
	public void method_0()
	{
		string text = Class20.string_4;
		string text2 = text;
		uint num = Hash.smethod_0(text2);
		bool flag = num > 1134978372U;
		if (flag)
		{
			bool flag2 = num > 2337319562U;
			if (flag2)
			{
				bool flag3 = num <= 3579376904U;
				if (flag3)
				{
					bool flag4 = num == 3266955512U;
					if (flag4)
					{
						bool flag5 = text2 == "iPad7,11";
						if (flag5)
						{
							this.method_1();
							return;
						}
					}
					else
					{
						bool flag6 = num != 3317288369U;
						if (flag6)
						{
							bool flag7 = num == 3579376904U;
							if (flag7)
							{
								bool flag8 = text2 == "iPhone8,4";
								if (flag8)
								{
									this.method_1();
									MessageBox.Show("Thiết bị : " + Class20.string_4 + " Phải có DCSD!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
									return;
								}
							}
						}
						else
						{
							bool flag9 = text2 == "iPad7,12";
							if (flag9)
							{
								this.method_1();
								return;
							}
						}
					}
				}
				else
				{
					bool flag10 = num > 3680042618U;
					if (flag10)
					{
						bool flag11 = num == 4191237488U;
						if (flag11)
						{
							bool flag12 = text2 == "iPad6,3";
							if (flag12)
							{
								this.method_1();
								return;
							}
						}
						else
						{
							bool flag13 = num == 4258347964U && text2 == "iPad6,7";
							if (flag13)
							{
								this.method_1();
								return;
							}
						}
					}
					else
					{
						bool flag14 = num != 3663264999U;
						if (flag14)
						{
							bool flag15 = num == 3680042618U;
							if (flag15)
							{
								bool flag16 = text2 == "iPhone8,2";
								if (flag16)
								{
									this.method_1();
									MessageBox.Show("Thiết bị : " + Class20.string_4 + " Phải có DCSD!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
									return;
								}
							}
						}
						else
						{
							bool flag17 = text2 == "iPhone8,1";
							if (flag17)
							{
								this.method_1();
								MessageBox.Show("Thiết bị : " + Class20.string_4 + " Phải có DCSD!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
								return;
							}
						}
					}
				}
			}
			else
			{
				bool flag18 = num <= 2286986705U;
				if (flag18)
				{
					bool flag19 = num != 2253431467U;
					if (flag19)
					{
						bool flag20 = num != 2270209086U;
						if (flag20)
						{
							bool flag21 = num == 2286986705U && text2 == "iPhone10,4";
							if (flag21)
							{
								this.method_1();
								return;
							}
						}
						else
						{
							bool flag22 = text2 == "iPhone10,5";
							if (flag22)
							{
								this.method_1();
								return;
							}
						}
					}
					else
					{
						bool flag23 = text2 == "iPhone10,6";
						if (flag23)
						{
							this.method_1();
							return;
						}
					}
				}
				else
				{
					bool flag24 = num != 2303764324U;
					if (flag24)
					{
						bool flag25 = num != 2320541943U;
						if (flag25)
						{
							bool flag26 = num == 2337319562U;
							if (flag26)
							{
								bool flag27 = text2 == "iPhone10,1";
								if (flag27)
								{
									this.method_1();
									return;
								}
							}
						}
						else
						{
							bool flag28 = text2 == "iPhone10,2";
							if (flag28)
							{
								this.method_1();
								return;
							}
						}
					}
					else
					{
						bool flag29 = text2 == "iPhone10,3";
						if (flag29)
						{
							this.method_1();
							return;
						}
					}
				}
			}
		}
		else
		{
			bool flag30 = num <= 301896402U;
			if (flag30)
			{
				bool flag31 = num <= 240921132U;
				if (flag31)
				{
					bool flag32 = num != 13713525U;
					if (flag32)
					{
						bool flag33 = num == 218008307U;
						if (flag33)
						{
							bool flag34 = text2 == "iPad7,3";
							if (flag34)
							{
								this.method_1();
								return;
							}
						}
						else
						{
							bool flag35 = num == 240921132U && text2 == "iPad6,12";
							if (flag35)
							{
								this.method_1();
								return;
							}
						}
					}
					else
					{
						bool flag36 = text2 == "iPad6,4";
						if (flag36)
						{
							this.method_1();
							return;
						}
					}
				}
				else
				{
					bool flag37 = num == 268341164U;
					if (flag37)
					{
						bool flag38 = text2 == "iPad7,6";
						if (flag38)
						{
							this.method_1();
							return;
						}
					}
					else
					{
						bool flag39 = num == 291253989U;
						if (flag39)
						{
							bool flag40 = text2 == "iPad6,11";
							if (flag40)
							{
								this.method_1();
								return;
							}
						}
						else
						{
							bool flag41 = num == 301896402U;
							if (flag41)
							{
								bool flag42 = text2 == "iPad7,4";
								if (flag42)
								{
									this.method_1();
									return;
								}
							}
						}
					}
				}
			}
			else
			{
				bool flag43 = num <= 926932844U;
				if (flag43)
				{
					bool flag44 = num != 318674021U;
					if (flag44)
					{
						bool flag45 = num != 876599987U;
						if (flag45)
						{
							bool flag46 = num == 926932844U;
							if (flag46)
							{
								bool flag47 = text2 == "iPhone9,1";
								if (flag47)
								{
									this.method_1();
									return;
								}
							}
						}
						else
						{
							bool flag48 = text2 == "iPhone9,4";
							if (flag48)
							{
								this.method_1();
								return;
							}
						}
					}
					else
					{
						bool flag49 = text2 == "iPad7,5";
						if (flag49)
						{
							this.method_1();
							return;
						}
					}
				}
				else
				{
					bool flag50 = num > 977265701U;
					if (flag50)
					{
						bool flag51 = num == 1118200753U;
						if (flag51)
						{
							bool flag52 = text2 == "iPad5,3";
							if (flag52)
							{
								this.method_1();
								return;
							}
						}
						else
						{
							bool flag53 = num == 1134978372U && text2 == "iPad5,4";
							if (flag53)
							{
								this.method_1();
								return;
							}
						}
					}
					else
					{
						bool flag54 = num == 960488082U;
						if (flag54)
						{
							bool flag55 = text2 == "iPhone9,3";
							if (flag55)
							{
								this.method_1();
								return;
							}
						}
						else
						{
							bool flag56 = num == 977265701U;
							if (flag56)
							{
								bool flag57 = text2 == "iPhone9,2";
								if (flag57)
								{
									this.method_1();
									return;
								}
							}
						}
					}
				}
			}
		}
		MessageBox.Show("Thiết bị : " + Class20.string_4 + " Không hỗ trợ!\n Hãy dùng Magiccfg !!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
	}

	// Token: 0x06000014 RID: 20 RVA: 0x000032CC File Offset: 0x000014CC
	public void method_1()
	{
		string text = Class20.string_4 + "-" + Class20.string_0 + ".zip";
		this.method_16();
		bool flag = !File.Exists(".\\Data\\" + text);
		if (flag)
		{
			this.method_18(Class17.string_3, text);
			this.method_14(3);
			this.method_13(text);
			this.method_14(1);
			File.Delete(Class17.string_0 + "\\Data\\" + text);
			bool flag2 = !(Class20.string_9 == "0x8010") && !(Class20.string_9 == "0x8015") && !(Class20.string_9 == "0x8011") && !(Class20.string_9 == "0x8012");
			if (flag2)
			{
				this.method_3();
				this.method_14(1);
			}
			else
			{
				this.method_2();
				this.method_14(1);
			}
		}
		else
		{
			Console.WriteLine("File Exist");
			this.method_13(text);
			this.method_14(1);
			bool flag3 = !(Class20.string_9 == "0x8010") && !(Class20.string_9 == "0x8015") && !(Class20.string_9 == "0x8011") && !(Class20.string_9 == "0x8012");
			if (flag3)
			{
				this.method_3();
				this.method_14(1);
			}
			else
			{
				this.method_2();
				this.method_14(1);
			}
			this.method_14(1);
		}
	}

	// Token: 0x06000015 RID: 21 RVA: 0x0000345C File Offset: 0x0000165C
	public void method_2()
	{
		this.method_15(10, "==> Truyền Boot bước 1 <==");
		Class17.smethod_1(".\\files\\irecovery -f .\\files\\swp\\iBoot.img4");
		this.method_14(1);
		this.method_15(30, "==> Truyền Boot bước 2 <==");
		Class17.smethod_1(".\\files\\irecovery -f .\\files\\swp\\iBoot.img4");
		File.Delete(Class17.string_0 + "\\files\\swp\\iBoot.img4");
		this.method_14(3);
		this.method_15(50, "==> Truyền Boot bước 3 <==");
		Class17.smethod_1(".\\files\\irecovery -f .\\files\\swp\\diag.img4");
		File.Delete(Class17.string_0 + "\\files\\swp\\iBoot.img4");
		this.method_14(3);
		Class17.smethod_1(".\\files\\irecovery -c \"setenv boot-args usbserial=enabled\"");
		this.method_15(70, "[+] Cài Boot args");
		this.method_14(3);
		Class17.smethod_1(".\\files\\irecovery -c \"saveenv\"");
		this.method_14(4);
		Console.WriteLine("Done");
		Class17.smethod_1(".\\files\\irecovery -c go");
		this.method_15(90, "[+] Vào chế độ Purple");
		this.method_14(6);
		this.method_16();
		Console.WriteLine("==> Hoàn thành");
		this.method_12();
	}

	// Token: 0x06000016 RID: 22 RVA: 0x00003570 File Offset: 0x00001770
	public void method_3()
	{
		this.method_15(10, "==> Truyền Boot bước 1 <==");
		Class17.smethod_1(".\\files\\irecovery -f .\\files\\swp\\iBSS.img4");
		this.method_14(3);
		Class17.smethod_1(".\\files\\irecovery -f .\\files\\swp\\iBSS.img4");
		this.method_14(3);
		this.method_15(30, "==> Truyền Boot bước 2 <==");
		Class17.smethod_1("\\files\\irecovery -f .\\files\\swp\\iBEC.img4");
		this.method_14(3);
		this.method_15(50, "==> Truyền Boot bước 3 <==");
		Class17.smethod_1("\\files\\irecovery -f .\\files\\swp\\diag.img4");
		this.method_14(3);
		Class17.smethod_1(".\\files\\irecovery -c \"clearenv boot-args\"");
		this.method_15(70, "[+] Cài Boot args");
		this.method_14(3);
		Class17.smethod_1(".\\files\\irecovery -c \"clearenv 1\"");
		this.method_14(4);
		Console.WriteLine("Done");
		Class17.smethod_1(".\\files\\irecovery -c go");
		this.method_15(90, "[+] Vào chế độ Purple");
		this.method_14(6);
		this.method_16();
		Console.WriteLine("==> Hoàn thành");
		this.method_12();
	}

	// Token: 0x06000017 RID: 23 RVA: 0x00003670 File Offset: 0x00001870
	public void method_4()
	{
		string text = Class20.string_4;
		string text2 = text;
		uint num = Hash.smethod_0(text2);
		bool flag = num > 1101423134U;
		if (flag)
		{
			bool flag2 = num <= 2303764324U;
			if (flag2)
			{
				bool flag3 = num <= 1760014814U;
				if (flag3)
				{
					bool flag4 = num > 1134978372U;
					if (flag4)
					{
						bool flag5 = num == 1743237195U;
						if (flag5)
						{
							bool flag6 = text2 == "iPhone7,2";
							if (flag6)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag7 = num == 1760014814U && text2 == "iPhone7,1";
							if (flag7)
							{
								this.method_5();
								return;
							}
						}
					}
					else
					{
						bool flag8 = num != 1118200753U;
						if (flag8)
						{
							bool flag9 = num == 1134978372U;
							if (flag9)
							{
								bool flag10 = text2 == "iPad5,4";
								if (flag10)
								{
									this.method_5();
									return;
								}
							}
						}
						else
						{
							bool flag11 = text2 == "iPad5,3";
							if (flag11)
							{
								this.method_5();
								return;
							}
						}
					}
				}
				else
				{
					bool flag12 = num <= 2270209086U;
					if (flag12)
					{
						bool flag13 = num != 2253431467U;
						if (flag13)
						{
							bool flag14 = num == 2270209086U;
							if (flag14)
							{
								bool flag15 = text2 == "iPhone10,5";
								if (flag15)
								{
									this.method_5();
									return;
								}
							}
						}
						else
						{
							bool flag16 = text2 == "iPhone10,6";
							if (flag16)
							{
								this.method_5();
								return;
							}
						}
					}
					else
					{
						bool flag17 = num == 2286986705U;
						if (flag17)
						{
							bool flag18 = text2 == "iPhone10,4";
							if (flag18)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag19 = num == 2303764324U && text2 == "iPhone10,3";
							if (flag19)
							{
								this.method_5();
								return;
							}
						}
					}
				}
			}
			else
			{
				bool flag20 = num <= 3317288369U;
				if (flag20)
				{
					bool flag21 = num <= 2337319562U;
					if (flag21)
					{
						bool flag22 = num != 2320541943U;
						if (flag22)
						{
							bool flag23 = num == 2337319562U;
							if (flag23)
							{
								bool flag24 = text2 == "iPhone10,1";
								if (flag24)
								{
									this.method_5();
									return;
								}
							}
						}
						else
						{
							bool flag25 = text2 == "iPhone10,2";
							if (flag25)
							{
								this.method_5();
								return;
							}
						}
					}
					else
					{
						bool flag26 = num != 3266955512U;
						if (flag26)
						{
							bool flag27 = num == 3317288369U;
							if (flag27)
							{
								bool flag28 = text2 == "iPad7,12";
								if (flag28)
								{
									this.method_5();
									return;
								}
							}
						}
						else
						{
							bool flag29 = text2 == "iPad7,11";
							if (flag29)
							{
								this.method_5();
								return;
							}
						}
					}
				}
				else
				{
					bool flag30 = num <= 3663264999U;
					if (flag30)
					{
						bool flag31 = num != 3579376904U;
						if (flag31)
						{
							bool flag32 = num == 3663264999U && text2 == "iPhone8,1";
							if (flag32)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag33 = text2 == "iPhone8,4";
							if (flag33)
							{
								this.method_5();
								return;
							}
						}
					}
					else
					{
						bool flag34 = num == 3680042618U;
						if (flag34)
						{
							bool flag35 = text2 == "iPhone8,2";
							if (flag35)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag36 = num == 4191237488U;
							if (flag36)
							{
								bool flag37 = text2 == "iPad6,3";
								if (flag37)
								{
									this.method_5();
									return;
								}
							}
							else
							{
								bool flag38 = num == 4258347964U;
								if (flag38)
								{
									bool flag39 = text2 == "iPad6,7";
									if (flag39)
									{
										this.method_5();
										return;
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			bool flag40 = num <= 291253989U;
			if (flag40)
			{
				bool flag41 = num > 218008307U;
				if (flag41)
				{
					bool flag42 = num <= 251563545U;
					if (flag42)
					{
						bool flag43 = num != 240921132U;
						if (flag43)
						{
							bool flag44 = num == 251563545U && text2 == "iPad7,1";
							if (flag44)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag45 = text2 == "iPad6,12";
							if (flag45)
							{
								this.method_5();
								return;
							}
						}
					}
					else
					{
						bool flag46 = num != 268341164U;
						if (flag46)
						{
							bool flag47 = num == 291253989U && text2 == "iPad6,11";
							if (flag47)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag48 = text2 == "iPad7,6";
							if (flag48)
							{
								this.method_5();
								return;
							}
						}
					}
				}
				else
				{
					bool flag49 = num <= 80824001U;
					if (flag49)
					{
						bool flag50 = num != 13713525U;
						if (flag50)
						{
							bool flag51 = num == 80824001U && text2 == "iPad6,8";
							if (flag51)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag52 = text2 == "iPad6,4";
							if (flag52)
							{
								this.method_5();
								return;
							}
						}
					}
					else
					{
						bool flag53 = num == 201230688U;
						if (flag53)
						{
							bool flag54 = text2 == "iPad7,2";
							if (flag54)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag55 = num == 218008307U && text2 == "iPad7,3";
							if (flag55)
							{
								this.method_5();
								return;
							}
						}
					}
				}
			}
			else
			{
				bool flag56 = num > 897947417U;
				if (flag56)
				{
					bool flag57 = num > 960488082U;
					if (flag57)
					{
						bool flag58 = num == 977265701U;
						if (flag58)
						{
							bool flag59 = text2 == "iPhone9,2";
							if (flag59)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag60 = num != 1084645515U;
							if (flag60)
							{
								bool flag61 = num == 1101423134U;
								if (flag61)
								{
									bool flag62 = text2 == "iPad5,2";
									if (flag62)
									{
										this.method_5();
										return;
									}
								}
							}
							else
							{
								bool flag63 = text2 == "iPad5,1";
								if (flag63)
								{
									this.method_5();
									return;
								}
							}
						}
					}
					else
					{
						bool flag64 = num == 926932844U;
						if (flag64)
						{
							bool flag65 = text2 == "iPhone9,1";
							if (flag65)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag66 = num == 960488082U && text2 == "iPhone9,3";
							if (flag66)
							{
								this.method_5();
								return;
							}
						}
					}
				}
				else
				{
					bool flag67 = num <= 318674021U;
					if (flag67)
					{
						bool flag68 = num == 301896402U;
						if (flag68)
						{
							bool flag69 = text2 == "iPad7,4";
							if (flag69)
							{
								this.method_5();
								return;
							}
						}
						else
						{
							bool flag70 = num == 318674021U;
							if (flag70)
							{
								bool flag71 = text2 == "iPad7,5";
								if (flag71)
								{
									this.method_5();
									return;
								}
							}
						}
					}
					else
					{
						bool flag72 = num != 876599987U;
						if (flag72)
						{
							bool flag73 = num == 897947417U;
							if (flag73)
							{
								bool flag74 = text2 == "iPod9,1";
								if (flag74)
								{
									this.method_5();
									return;
								}
							}
						}
						else
						{
							bool flag75 = text2 == "iPhone9,4";
							if (flag75)
							{
								this.method_5();
								return;
							}
						}
					}
				}
			}
		}
		MessageBox.Show("Thiết bị : " + Class20.string_4 + " Không hỗ trợ!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
	}

	// Token: 0x06000018 RID: 24 RVA: 0x00003E3C File Offset: 0x0000203C
	public void method_5()
	{
		Class8 @class = new Class8();
		this.method_16();
		this.method_14(1);
		bool flag = File.Exists(".\\Data\\" + Class17.string_4 + ".iboy");
		if (flag)
		{
			string text = string.Concat(new string[]
			{
				Class17.string_0,
				"\\files\\tmp\\",
				Class20.string_4,
				"-",
				Class20.string_0,
				".zip"
			});
			string text2 = Class17.string_0 + "\\Data\\" + Class17.string_4 + ".iboy";
			string text3 = "U3RlYWx0aE1lISEhIQ==";
			Console.WriteLine("Ada File");
			@class.method_1(text2, text, text3);
			this.method_14(3);
			this.method_10(Class20.string_4 + "-" + Class20.string_0 + ".zip");
			this.method_14(3);
			File.Delete(text);
			this.method_9();
		}
		else
		{
			Console.WriteLine("File Notfound then Download");
			this.method_18(Class17.string_5, Class17.string_4 + ".iboy");
		}
		this.method_16();
	}

	// Token: 0x06000019 RID: 25 RVA: 0x00003F64 File Offset: 0x00002164
	public void method_6()
	{
		string text = Class20.string_4;
		string text2 = text;
		uint num = Hash.smethod_0(text2);
		bool flag = num > 318674021U;
		if (flag)
		{
			bool flag2 = num > 2320541943U;
			if (flag2)
			{
				bool flag3 = num > 3266955512U;
				if (flag3)
				{
					bool flag4 = num == 3317288369U;
					if (flag4)
					{
						bool flag5 = text2 == "iPad7,12";
						if (flag5)
						{
							this.method_7();
							return;
						}
					}
					else
					{
						bool flag6 = num == 4191237488U;
						if (flag6)
						{
							bool flag7 = text2 == "iPad6,3";
							if (flag7)
							{
								this.method_7();
								return;
							}
						}
						else
						{
							bool flag8 = num == 4258347964U;
							if (flag8)
							{
								bool flag9 = text2 == "iPad6,7";
								if (flag9)
								{
									this.method_7();
									return;
								}
							}
						}
					}
				}
				else
				{
					bool flag10 = num != 2337319562U;
					if (flag10)
					{
						bool flag11 = num == 3266955512U;
						if (flag11)
						{
							bool flag12 = text2 == "iPad7,11";
							if (flag12)
							{
								this.method_7();
								return;
							}
						}
					}
					else
					{
						bool flag13 = text2 == "iPhone10,1";
						if (flag13)
						{
							this.method_7();
							return;
						}
					}
				}
			}
			else
			{
				bool flag14 = num > 2270209086U;
				if (flag14)
				{
					bool flag15 = num == 2286986705U;
					if (flag15)
					{
						bool flag16 = text2 == "iPhone10,4";
						if (flag16)
						{
							this.method_7();
							return;
						}
					}
					else
					{
						bool flag17 = num != 2303764324U;
						if (flag17)
						{
							bool flag18 = num == 2320541943U && text2 == "iPhone10,2";
							if (flag18)
							{
								this.method_7();
								return;
							}
						}
						else
						{
							bool flag19 = text2 == "iPhone10,3";
							if (flag19)
							{
								this.method_7();
								return;
							}
						}
					}
				}
				else
				{
					bool flag20 = num == 2253431467U;
					if (flag20)
					{
						bool flag21 = text2 == "iPhone10,6";
						if (flag21)
						{
							this.method_7();
							return;
						}
					}
					else
					{
						bool flag22 = num == 2270209086U && text2 == "iPhone10,5";
						if (flag22)
						{
							this.method_7();
							return;
						}
					}
				}
			}
		}
		else
		{
			bool flag23 = num <= 240921132U;
			if (flag23)
			{
				bool flag24 = num <= 80824001U;
				if (flag24)
				{
					bool flag25 = num == 13713525U;
					if (flag25)
					{
						bool flag26 = text2 == "iPad6,4";
						if (flag26)
						{
							this.method_7();
							return;
						}
					}
					else
					{
						bool flag27 = num == 80824001U && text2 == "iPad6,8";
						if (flag27)
						{
							this.method_7();
							return;
						}
					}
				}
				else
				{
					bool flag28 = num == 201230688U;
					if (flag28)
					{
						bool flag29 = text2 == "iPad7,2";
						if (flag29)
						{
							this.method_7();
							return;
						}
					}
					else
					{
						bool flag30 = num != 218008307U;
						if (flag30)
						{
							bool flag31 = num == 240921132U && text2 == "iPad6,12";
							if (flag31)
							{
								this.method_7();
								return;
							}
						}
						else
						{
							bool flag32 = text2 == "iPad7,3";
							if (flag32)
							{
								this.method_7();
								return;
							}
						}
					}
				}
			}
			else
			{
				bool flag33 = num > 268341164U;
				if (flag33)
				{
					bool flag34 = num == 291253989U;
					if (flag34)
					{
						bool flag35 = text2 == "iPad6,11";
						if (flag35)
						{
							this.method_7();
							return;
						}
					}
					else
					{
						bool flag36 = num != 301896402U;
						if (flag36)
						{
							bool flag37 = num == 318674021U;
							if (flag37)
							{
								bool flag38 = text2 == "iPad7,5";
								if (flag38)
								{
									this.method_7();
									return;
								}
							}
						}
						else
						{
							bool flag39 = text2 == "iPad7,4";
							if (flag39)
							{
								this.method_7();
								return;
							}
						}
					}
				}
				else
				{
					bool flag40 = num != 251563545U;
					if (flag40)
					{
						bool flag41 = num == 268341164U;
						if (flag41)
						{
							bool flag42 = text2 == "iPad7,6";
							if (flag42)
							{
								this.method_7();
								return;
							}
						}
					}
					else
					{
						bool flag43 = text2 == "iPad7,1";
						if (flag43)
						{
							this.method_7();
							return;
						}
					}
				}
			}
		}
		MessageBox.Show("Device Không hỗ trợ in Boot2 !!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
	}

	// Token: 0x0600001A RID: 26 RVA: 0x000043D8 File Offset: 0x000025D8
	public void method_7()
	{
		Class8 @class = new Class8();
		this.method_16();
		this.method_14(1);
		bool flag = !File.Exists(".\\Data\\" + Class17.string_4 + ".iboy");
		if (flag)
		{
			this.method_18(Class17.string_5, Class17.string_4 + ".iboy");
		}
		else
		{
			Console.WriteLine("Ada File");
			string text = string.Concat(new string[]
			{
				Class17.string_0,
				"\\files\\tmp\\",
				Class20.string_4,
				"-",
				Class20.string_0,
				".zip"
			});
			string text2 = Class17.string_0 + "\\Data\\" + Class17.string_4 + ".iboy";
			string text3 = "U3RlYWx0aE1lISEhIQ==";
			@class.method_1(text2, text, text3);
			this.method_14(3);
			this.method_10(Class20.string_4 + "-" + Class20.string_0 + ".zip");
			this.method_14(3);
			File.Delete(text);
			this.method_8();
		}
		this.method_16();
	}

	// Token: 0x0600001B RID: 27 RVA: 0x000044F8 File Offset: 0x000026F8
	public void method_8()
	{
		try
		{
			this.method_15(10, "bắt đầu Boot Patch");
			this.method_15(20, "Truyền iBSS");
			this.method_14(1);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\iBSS.img4");
			this.method_14(3);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\iBSS.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\iBSS.img4");
			this.method_14(3);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\iBEC.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\iBEC.img4");
			this.method_14(3);
			bool flag = !(Class20.string_9 == "0x8010") && !(Class20.string_9 == "0x8015") && !(Class20.string_9 == "0x8011") && !(Class20.string_9 == "0x8012");
			if (flag)
			{
				Console.WriteLine("Bỏ qua trình nạp");
			}
			else
			{
				Console.WriteLine("6");
				Class17.smethod_1(".\\files\\irecovery -c go");
			}
			this.method_14(3);
			this.method_15(30, "Truyền Logo");
			Console.WriteLine("7");
			Class17.smethod_1(".\\files\\irecovery -f .\\files\\shsh\\" + Class20.string_9);
			File.Delete(Class17.string_2 + ".\\files\\tmp\\logo.img4");
			Class17.smethod_1(".\\files\\irecovery  -c \"setpicture 0\"");
			Class17.smethod_1(".\\files\\irecovery  -c \"bgcolor 0 0 0\"");
			this.method_15(40, "Truyền DeviceTree");
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\devicetree.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\devicetree.img4");
			Class17.smethod_1(".\\files\\irecovery -c devicetree");
			this.method_14(3);
			this.method_15(65, "Truyền Ramdisk");
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\ramdisk.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\ramdisk.img4");
			Class17.smethod_1(".\\files\\irecovery -c ramdisk");
			this.method_14(3);
			this.method_15(65, "Truyền SEP");
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\sep-fw.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\sep-fw.img4");
			Class17.smethod_1(".\\files\\irecovery -c rsepfirmware");
			this.method_14(2);
			this.method_15(75, "Truyền Trustcache");
			this.method_14(3);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\trustcache.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\trustcache.img4");
			Class17.smethod_1(".\\files\\irecovery -c firmware");
			this.method_14(2);
			this.method_15(90, "Truyền Kernel");
			this.method_14(3);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\kernelcache.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\kernelcache.img4");
			Class17.smethod_1(".\\files\\irecovery -c bootx");
			this.method_16();
			this.method_14(5);
			this.method_11();
		}
		catch (Exception ex)
		{
			this.method_16();
			MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x0600001C RID: 28 RVA: 0x0000487C File Offset: 0x00002A7C
	public void method_9()
	{
		try
		{
			this.method_15(10, "bắt đầu Boot Patch");
			this.method_15(20, "Truyền iBSS");
			Class17.smethod_1(".\\files\\irecovery -f .\\files\\shsh\\" + Class20.string_9 + ".shsh");
			this.method_14(1);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\iBSS.img4");
			this.method_14(2);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\iBSS.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\iBSS.img4");
			this.method_14(3);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\iBEC.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\iBEC.img4");
			this.method_14(3);
			this.method_15(30, "Truyền Logo");
			Class17.smethod_1(".\\files\\irecovery -f .\\files\\shsh\\" + Class20.string_9);
			File.Delete(Class17.string_2 + ".\\files\\tmp\\logo.img4");
			Class17.smethod_1(".\\files\\irecovery  -c \"setpicture 0\"");
			Class17.smethod_1(".\\files\\irecovery  -c \"bgcolor 0 0 0\"");
			this.method_15(50, "Truyền Ramdisk");
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\ramdisk.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\ramdisk.img4");
			Class17.smethod_1(".\\files\\irecovery -c ramdisk");
			this.method_14(2);
			this.method_15(65, "Truyền DeviceTree");
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\devicetree.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\devicetree.img4");
			Class17.smethod_1(".\\files\\irecovery -c devicetree");
			this.method_14(2);
			this.method_15(75, "Truyền Trustcache");
			this.method_14(3);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\trustcache.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\trustcache.img4");
			Class17.smethod_1(".\\files\\irecovery -c firmware");
			this.method_14(2);
			this.method_15(90, "Truyền Kernel");
			this.method_14(3);
			Class17.smethod_1(".\\files\\irecovery -f " + Class17.string_2 + ".\\files\\tmp\\kernelcache.img4");
			File.Delete(Class17.string_2 + ".\\files\\tmp\\kernelcache.img4");
			Class17.smethod_1(".\\files\\irecovery -c bootx");
			this.method_16();
			this.method_14(5);
			this.method_11();
		}
		catch (Exception ex)
		{
			this.method_16();
			MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x0600001D RID: 29 RVA: 0x00004B44 File Offset: 0x00002D44
	public void method_10(string string_6)
	{
		try
		{
			this.method_15(50, "==> Giải nén Bootchain <==");
			this.method_16();
			string text = Class17.string_2 + "\\files\\tmp\\";
			using (ZipFile zipFile = ZipFile.Read(Class17.string_0 + "/files/tmp/" + string_6))
			{
				zipFile.Password = "iBoyRamdisk123!@#";
				foreach (ZipEntry zipEntry in zipFile)
				{
					zipEntry.Extract(text, ExtractExistingFileAction.OverwriteSilently);
				}
			}
			this.method_15(100, "==> Ramdisk giải nén thành công <==");
			Console.WriteLine("=>> Ramdisk giải nén thành công <==");
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Cảnh báo !", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x0600001E RID: 30 RVA: 0x00004C3C File Offset: 0x00002E3C
	public void method_11()
	{
		try
		{
			using (Process process = new Process())
			{
				process.StartInfo.FileName = Class17.string_0 + ".\\files\\irecovery.exe";
				process.StartInfo.Arguments = "-m";
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				process.StartInfo.CreateNoWindow = true;
				process.Start();
				StreamReader standardOutput = process.StandardOutput;
				string text = standardOutput.ReadToEnd();
				process.WaitForExit();
				Class20.string_10 = text;
				bool flag = text.Contains("Recovery");
				bool flag2 = text.Contains("DFU");
				bool flag3 = text.Contains("Lỗi:");
				bool flag4 = !flag;
				if (flag4)
				{
					bool flag5 = !flag2;
					if (flag5)
					{
						bool flag6 = flag3;
						if (flag6)
						{
							this.method_15(100, "Thiết bị boot thành công !");
							MessageBox.Show("Thiết bị boot thành công ! Giờ bấm kết nối SSH", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							this.method_15(100, "Thiết bị boot thành công !");
							MessageBox.Show("Thiết bị boot thành công ! Giờ bấm kết nối SSH", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else
					{
						this.method_15(99, "Thiết bị trong chế độ DFU, Boot Ramdisk lỗi");
						MessageBox.Show("Thiết bị không boot thành SSH Ramdisk, Kiểm tra drivers và thử lại", "Onii Ramdisk Lỗi!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				else
				{
					this.method_15(99, "Thiết bị trong chế độ recovery!");
					MessageBox.Show("Thiết bị không boot thành SSH Ramdisk, Kiểm tra drivers và thử lại", "Onii Ramdisk Lỗi!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
		}
		catch (Exception ex)
		{
			this.method_16();
			MessageBox.Show(ex.Message);
		}
	}

	// Token: 0x0600001F RID: 31 RVA: 0x00004E10 File Offset: 0x00003010
	public void method_12()
	{
		try
		{
			using (Process process = new Process())
			{
				process.StartInfo.FileName = Class17.string_0 + ".\\files\\irecovery.exe";
				process.StartInfo.Arguments = "-m";
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				process.StartInfo.CreateNoWindow = true;
				process.Start();
				StreamReader standardOutput = process.StandardOutput;
				string text = standardOutput.ReadToEnd();
				process.WaitForExit();
				Class20.string_10 = text;
				bool flag = text.Contains("Recovery");
				bool flag2 = text.Contains("DFU");
				bool flag3 = text.Contains("Lỗi:");
				bool flag4 = flag;
				if (flag4)
				{
					this.method_15(99, "Lỗi DEVICE NOT BOOTED BAD DRIVERS!");
					MessageBox.Show("Thiết bị không boot sang PURPLE MODE, Kiểm tra drivers và thử lại", "Onii Ramdisk Lỗi!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
				{
					bool flag5 = flag2;
					if (flag5)
					{
						this.method_15(99, "Lỗi DEVICE NOT BOOTED");
						MessageBox.Show("Thiết bị không boot sang PURPLE MODE, Kiểm tra drivers và thử lại", "Onii Ramdisk Lỗi!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					else
					{
						bool flag6 = !flag3;
						if (flag6)
						{
							this.method_15(100, "Thiết bị boot thành công !");
							MessageBox.Show("Thiết bị boot thành công ! Giờ kiểm tra DIAG CDC Driver từ Device Manage\n Một vài thiế bị không hiện màn tím nhưng hoàn thành vào Diag Mode \niPhone 6s - 6plus cần DCSD Cable", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							this.method_15(100, "Thiết bị boot thành công !");
							MessageBox.Show("Thiết bị boot thành công ! Giờ kiểm tra DIAG CDC Driver từ Device Manage \n Một vài thiế bị không hiện màn tím nhưng hoàn thành vào Diag Mode \niPhone 6s - 6plus cần DCSD Cable", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.method_16();
			MessageBox.Show(ex.Message);
		}
	}

	// Token: 0x06000020 RID: 32 RVA: 0x00004FDC File Offset: 0x000031DC
	public void method_13(string string_6)
	{
		try
		{
			this.method_15(50, "==> Giải nén Bootchain <==");
			this.method_16();
			string text = Class17.string_0 + "/files/swp/";
			using (ZipFile zipFile = ZipFile.Read(Class17.string_0 + "/Data/" + string_6))
			{
				zipFile.Password = "iBoyRamdisk123!@#";
				foreach (ZipEntry zipEntry in zipFile)
				{
					zipEntry.Extract(text, ExtractExistingFileAction.OverwriteSilently);
				}
			}
			this.method_15(100, "==> Extract Hoàn thành <==");
			Console.WriteLine("=>> Purple Boot đã được giải nén <==");
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Cảnh báo !", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x06000021 RID: 33 RVA: 0x000050D4 File Offset: 0x000032D4
	public void method_14(int int_0)
	{
		Thread.Sleep(int_0 * 1000);
	}

	// Token: 0x06000022 RID: 34 RVA: 0x000050E4 File Offset: 0x000032E4
	[DebuggerStepThrough]
	public static Task smethod_0(int int_0)
	{
		Class17.<smethod_0>d__15 <smethod_0>d__ = new Class17.<smethod_0>d__15();
		<smethod_0>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
		<smethod_0>d__.int_0 = int_0;
		<smethod_0>d__.<>1__state = -1;
		<smethod_0>d__.<>t__builder.Start<Class17.<smethod_0>d__15>(ref <smethod_0>d__);
		return <smethod_0>d__.<>t__builder.Task;
	}

	// Token: 0x06000023 RID: 35 RVA: 0x00005128 File Offset: 0x00003328
	private static void smethod_1(string string_6)
	{
		ProcessStartInfo processStartInfo = new ProcessStartInfo("cmd", "/c " + string_6);
		processStartInfo.RedirectStandardOutput = true;
		processStartInfo.UseShellExecute = false;
		processStartInfo.CreateNoWindow = true;
		Process process = new Process();
		process.StartInfo = processStartInfo;
		process.Start();
		string text = process.StandardOutput.ReadToEnd();
		Console.WriteLine(text);
	}

	// Token: 0x06000024 RID: 36 RVA: 0x0000518C File Offset: 0x0000338C
	public void method_15(int int_0, string string_6 = "")
	{
		Class17.Class18 @class = new Class17.Class18();
		@class.int_0 = int_0;
		@class.FRM_Onii_0 = (FRM_Onii)Application.OpenForms["FRM_Onii"];
		@class.FRM_Onii_0.Invoke(new MethodInvoker(@class.method_0));
		bool flag = Class20.bool_0;
		if (flag)
		{
			Console.WriteLine(@class.int_0.ToString() + string_6);
		}
		@class.FRM_Onii_0.method_5(string_6);
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00005208 File Offset: 0x00003408
	public void method_16()
	{
		try
		{
			bool flag = Directory.Exists(Class17.string_1);
			if (flag)
			{
				Directory.Delete(Class17.string_1, true);
			}
			Thread.Sleep(1000);
			Directory.CreateDirectory(Class17.string_1);
		}
		catch (Exception)
		{
		}
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00005264 File Offset: 0x00003464
	public void method_17()
	{
		try
		{
			bool flag = Directory.Exists(Class17.string_2);
			if (flag)
			{
				Directory.Delete(Class17.string_2, true);
			}
			Thread.Sleep(1000);
			Directory.CreateDirectory(Class17.string_2);
		}
		catch (Exception)
		{
		}
	}

	// Token: 0x06000027 RID: 39 RVA: 0x000052C0 File Offset: 0x000034C0
	public void method_18(string string_6, string string_7)
	{
		try
		{
			WebClient webClient = new WebClient();
			webClient.DownloadProgressChanged += this.method_19;
			webClient.DownloadFileCompleted += this.method_20;
			webClient.Headers.Add("User-Agent: Other");
			webClient.DownloadFileAsync(new Uri(string_6), Class17.string_0 + "/Data/" + string_7);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message + " 404 Result = Purple Boot không tồn tại trong Server", "Tải về thất bại", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x06000028 RID: 40 RVA: 0x00005360 File Offset: 0x00003560
	public void method_19(object sender, DownloadProgressChangedEventArgs e)
	{
		double num = double.Parse(e.BytesReceived.ToString());
		double num2 = double.Parse(e.TotalBytesToReceive.ToString());
		double num3 = num / num2 * 100.0;
		this.method_15(int.Parse(Math.Truncate(num3).ToString()), "Đã tải về Ramdisk Data : " + string.Format(" {0} MB / {1} MB", ((double)e.BytesReceived / 1024.0 / 1024.0).ToString("0.00"), ((double)e.TotalBytesToReceive / 1024.0 / 1024.0).ToString("0.00")));
	}

	// Token: 0x06000029 RID: 41 RVA: 0x00005428 File Offset: 0x00003628
	private void method_20(object sender, AsyncCompletedEventArgs e)
	{
		this.method_15(100, "Tải về hoàn thành, Bấm để boot");
		bool flag = !(Class20.string_13 == "ramdisk");
		if (flag)
		{
			MessageBox.Show("Bấm lại nút  !!!", "Tải về hoàn thành !", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else
		{
			MessageBox.Show("Bấm boot ramdisk lại !!!", "Tải về hoàn thành !", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	// Token: 0x04000004 RID: 4
	public static string string_0 = Environment.CurrentDirectory;

	// Token: 0x04000005 RID: 5
	public static string string_1 = Class17.string_0 + "\\files\\swp\\";

	// Token: 0x04000006 RID: 6
	public static string string_2 = "C:\\Windows\\apppatch\\Apple\\";

	// Token: 0x04000007 RID: 7
	public static string string_3 = string.Concat(new string[]
	{
		"https://pentaboy.my.id/purple/",
		Class20.string_4,
		"-",
		Class20.string_0,
		".zip"
	});

	// Token: 0x04000008 RID: 8
	public static string string_4 = string.Concat(new string[]
	{
		Class20.string_4,
		"-",
		Class20.string_0,
		"-",
		Class20.string_11
	});

	// Token: 0x04000009 RID: 9
	public static string string_5 = string.Concat(new string[]
	{
		"https://sin1.contabostorage.com/47c5cad1ab9a448dbb8f520da61dcd7b:windows/",
		Class20.string_11,
		"/",
		Class17.string_4,
		".iboy"
	});

	// Token: 0x0400000A RID: 10
	private GClass2 gclass2_0 = new GClass2();

	// Token: 0x0400000B RID: 11
	public bool bool_0 = false;

	// Token: 0x02000019 RID: 25
	[CompilerGenerated]
	private sealed class Class18
	{
		// Token: 0x060000F7 RID: 247 RVA: 0x00010499 File Offset: 0x0000E699
		internal void method_0()
		{
			this.FRM_Onii_0.method_6(this.int_0, this.int_0.ToString());
		}

		// Token: 0x040000A9 RID: 169
		public FRM_Onii FRM_Onii_0;

		// Token: 0x040000AA RID: 170
		public int int_0;
	}
}
