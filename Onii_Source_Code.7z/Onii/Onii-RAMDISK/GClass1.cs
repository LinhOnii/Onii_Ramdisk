﻿using System;

// Token: 0x02000014 RID: 20
public static class GClass1
{
	// Token: 0x0400009D RID: 157
	public static string string_0 = "";

	// Token: 0x0400009E RID: 158
	public static string string_1 = Environment.CurrentDirectory + "bin/off.txt";

	// Token: 0x0400009F RID: 159
	public static string string_2 = "";

	// Token: 0x040000A0 RID: 160
	public static string string_3 = "";

	// Token: 0x040000A1 RID: 161
	public static string string_4 = "";

	// Token: 0x040000A2 RID: 162
	public static string string_5 = "";
}
