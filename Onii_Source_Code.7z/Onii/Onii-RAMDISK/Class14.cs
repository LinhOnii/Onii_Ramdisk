﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;

// Token: 0x02000002 RID: 2
internal class Class14
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	public void method_0(string string_1)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append(string_1);
		File.AppendAllText(".\\iRecovery_log.txt", stringBuilder.ToString());
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00002080 File Offset: 0x00000280
	public void method_1(string string_1, string string_2, string string_3)
	{
		bool flag = string_1 != "";
		if (flag)
		{
			string text = "CD Resources\\tmp\\" + string_1 + "\n..\\..\\..\\files\\irecovery.exe";
			string text2 = string.Concat(new string[]
			{
				"@ECHO OFF\n",
				text,
				" ",
				string_2,
				" ",
				string_3
			});
			File.WriteAllText("del.cmd", text2);
			try
			{
				this.process_0 = new Process
				{
					StartInfo = new ProcessStartInfo
					{
						FileName = "del.cmd",
						UseShellExecute = false,
						RedirectStandardOutput = true,
						CreateNoWindow = true
					}
				};
				this.process_0.Start();
				StreamReader standardOutput = this.process_0.StandardOutput;
				standardOutput.ReadToEnd();
				this.process_0.WaitForExit();
				goto IL_18B;
			}
			catch (Exception)
			{
				goto IL_18B;
			}
		}
		string text3 = ".\\files\\irecovery.exe";
		string text4 = string.Concat(new string[]
		{
			"@ECHO OFF\n",
			text3,
			" ",
			string_2,
			" ",
			string_3
		});
		File.WriteAllText("del.cmd", text4);
		try
		{
			this.process_0 = new Process
			{
				StartInfo = new ProcessStartInfo
				{
					FileName = "del.cmd",
					UseShellExecute = false,
					RedirectStandardOutput = true,
					CreateNoWindow = true
				}
			};
			this.process_0.Start();
			StreamReader standardOutput2 = this.process_0.StandardOutput;
			standardOutput2.ReadToEnd();
			this.process_0.WaitForExit();
		}
		catch (Exception)
		{
		}
		IL_18B:
		this.method_4("del.cmd");
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00002244 File Offset: 0x00000444
	public void method_2(string string_1)
	{
		this.process_0 = new Process
		{
			StartInfo = new ProcessStartInfo
			{
				FileName = ".\\files\\curl.exe",
				Arguments = string_1,
				UseShellExecute = false,
				RedirectStandardOutput = true,
				CreateNoWindow = true
			}
		};
		this.process_0.Start();
		this.process_0.WaitForExit();
	}

	// Token: 0x06000004 RID: 4 RVA: 0x000022B0 File Offset: 0x000004B0
	public string method_3(string string_1)
	{
		string text3;
		try
		{
			string text = "@echo off\n" + string_1;
			File.WriteAllText("temp.cmd", text);
			this.process_0 = new Process
			{
				StartInfo = new ProcessStartInfo
				{
					FileName = "temp.cmd",
					UseShellExecute = false,
					RedirectStandardOutput = true,
					CreateNoWindow = true
				}
			};
			this.process_0.Start();
			StreamReader standardOutput = this.process_0.StandardOutput;
			string text2 = standardOutput.ReadToEnd();
			this.process_0.WaitForExit();
			this.method_4("temp.cmd");
			text3 = text2;
		}
		catch
		{
			text3 = "Lỗi";
		}
		return text3;
	}

	// Token: 0x06000005 RID: 5 RVA: 0x00002370 File Offset: 0x00000570
	public void method_4(string string_1)
	{
		bool flag = File.Exists(string_1);
		if (flag)
		{
			File.Delete(string_1);
		}
	}

	// Token: 0x06000006 RID: 6 RVA: 0x00002394 File Offset: 0x00000594
	public string method_5(string string_1)
	{
		string text = "@echo off\nfiles\\ideviceinfo.exe | files\\grep.exe -w " + string_1 + " | files\\awk.exe '{printf $NF}'";
		File.WriteAllText("Info.cmd", text);
		this.process_1 = new Process
		{
			StartInfo = new ProcessStartInfo
			{
				FileName = "Info.cmd",
				UseShellExecute = false,
				RedirectStandardOutput = true,
				CreateNoWindow = true
			}
		};
		this.process_1.Start();
		StreamReader standardOutput = this.process_1.StandardOutput;
		string text2 = standardOutput.ReadToEnd();
		this.method_4("Info.cmd");
		return text2;
	}

	// Token: 0x06000007 RID: 7 RVA: 0x0000242C File Offset: 0x0000062C
	public void method_6()
	{
		bool flag = this.method_5("UniqueDeviceID") == "";
		if (flag)
		{
			MessageBox.Show("Không phát hiện thiết bị!", "Lỗi");
		}
		else
		{
			bool flag2 = !(this.method_5("SerialNumber") == "F97SF2AQFFGD");
			if (flag2)
			{
				this.method_7();
			}
			else
			{
				this.method_8();
			}
		}
	}

	// Token: 0x06000008 RID: 8 RVA: 0x00002498 File Offset: 0x00000698
	public void method_7()
	{
		string text = Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0;
		try
		{
			this.method_9();
			bool flag = File.Exists(text);
			if (flag)
			{
				this.method_12();
			}
			else
			{
				Directory.CreateDirectory(text);
				this.method_12();
			}
			MessageBox.Show("INFORMATION:\nFIles tạo hoàn tất !\nGiờ vào PUWNFU và kích hoạt thiết bị", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		catch
		{
			MessageBox.Show("Không thể tạo kích hoạt, thử lại", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x06000009 RID: 9 RVA: 0x00002528 File Offset: 0x00000728
	public void method_8()
	{
		string text = Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0;
		try
		{
			this.method_10();
			bool flag = File.Exists(text);
			if (flag)
			{
				this.method_11();
			}
			else
			{
				Directory.CreateDirectory(text);
				this.method_11();
			}
			MessageBox.Show("INFORMATION:\nFIles tạo hoàn tất !\nGiờ vào PUWNFU và kích hoạt thiết bị", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		catch (Exception ex)
		{
			string text2 = "Không thể tạo kích hoạt, thử lại\n";
			Exception ex2 = ex;
			MessageBox.Show(text2 + ((ex2 != null) ? ex2.ToString() : null), "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x0600000A RID: 10 RVA: 0x000025D0 File Offset: 0x000007D0
	public string method_9()
	{
		string text = string.Concat(new string[]
		{
			"https://pentaboy.my.id/ios2/activation_pwn.php?udid=",
			this.method_13("UniqueDeviceID").Trim(),
			"&sn=",
			this.method_13("SerialNumber").Trim(),
			"&ucid=",
			this.method_13("UniqueChipID").Trim()
		});
		HttpWebRequest httpWebRequest = WebRequest.CreateHttp(text);
		httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
		httpWebRequest.Timeout = 12000;
		string text2;
		using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
		{
			using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
			{
				text2 = streamReader.ReadToEnd();
			}
		}
		return text2;
	}

	// Token: 0x0600000B RID: 11 RVA: 0x000026BC File Offset: 0x000008BC
	public string method_10()
	{
		string text = string.Concat(new string[]
		{
			"https://pentaboy.my.id/ios/iOS16Act.php?udid=",
			this.method_13("UniqueDeviceID").Trim(),
			"&bv=",
			this.method_13("BuildVersion").Trim(),
			"&dc=",
			this.method_13("DeviceClass").Trim(),
			"&dv=",
			this.method_13("DeviceVariant").Trim(),
			"&mn=",
			this.method_13("ModelNumber").Trim(),
			"&ot=",
			this.method_13("OSType").Trim(),
			"&pt=",
			this.method_13("ProductType").Trim(),
			"&pv=",
			this.method_13("ProductVersion").Trim(),
			"&rmn=",
			this.method_13("RegulatoryModelNumber").Trim(),
			"&ucid=",
			this.method_13("UniqueChipID").Trim()
		});
		HttpWebRequest httpWebRequest = WebRequest.CreateHttp(text);
		httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
		httpWebRequest.Timeout = 12000;
		string text2;
		using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
		{
			using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
			{
				text2 = streamReader.ReadToEnd();
			}
		}
		return text2;
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00002870 File Offset: 0x00000A70
	private void method_11()
	{
		try
		{
			using (WebClient webClient = new WebClient())
			{
				webClient.DownloadFile("https://pentaboy.my.id/ios/" + this.method_13("UniqueDeviceID").Trim() + "/activation_record.plist", Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0 + "\\activation_record.plist");
				webClient.DownloadFile("https://pentaboy.my.id/ios/" + this.method_13("UniqueDeviceID").Trim() + "/IC-Info.sisv", Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0 + "\\IC-Info.sisv");
				webClient.DownloadFile("https://pentaboy.my.id/ios/" + this.method_13("UniqueDeviceID").Trim() + "/Wildcard.der", Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0 + "\\Wildcard.der");
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message + " 404 Result = FIles không tồn tại trên server", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x0600000D RID: 13 RVA: 0x00002998 File Offset: 0x00000B98
	private void method_12()
	{
		try
		{
			using (WebClient webClient = new WebClient())
			{
				webClient.DownloadFile("https://pentaboy.my.id/ios2/Devices/activation_records/" + Class20.string_7 + "/activation_record.plist", Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0 + "\\activation_record.plist");
				webClient.DownloadFile("https://pentaboy.my.id/ios2/Devices/activation_records/" + Class20.string_7 + "/IC-Info.sisv", Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0 + "\\IC-Info.sisv");
				webClient.DownloadFile("https://pentaboy.my.id/ios2/Devices/activation_records/" + Class20.string_7 + "/Wildcard.der", Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0 + "\\Wildcard.der");
				webClient.DownloadFile("https://pentaboy.my.id/ios2/Devices/activation_records/" + Class20.string_7 + "/com.apple.commcenter.device_specific_nobackup.plist", Directory.GetCurrentDirectory() + ".\\ActivationFiles\\" + this.string_0 + "\\com.apple.commcenter.device_specific_nobackup.plist");
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message + " 404 Result = FIles không tồn tại trên server", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x0600000E RID: 14 RVA: 0x00002AD4 File Offset: 0x00000CD4
	public string method_13(string string_1)
	{
		string text = "@echo off\nfiles\\ideviceinfo.exe -k " + string_1;
		File.WriteAllText(".\\files\\swp\\Info.cmd", text);
		Process process = new Process
		{
			StartInfo = new ProcessStartInfo
			{
				FileName = ".\\files\\swp\\Info.cmd",
				UseShellExecute = false,
				RedirectStandardOutput = true,
				CreateNoWindow = true
			}
		};
		process.Start();
		StreamReader standardOutput = process.StandardOutput;
		string text2 = standardOutput.ReadToEnd();
		text2.Replace("\n", "");
		process.WaitForExit();
		return text2;
	}

	// Token: 0x0600000F RID: 15 RVA: 0x00002B64 File Offset: 0x00000D64
	public void method_15(int int_0, string string_1 = "")
	{
		Class14.Class15 @class = new Class14.Class15();
		@class.int_0 = int_0;
		@class.FRM_Onii_0 = (FRM_Onii)Application.OpenForms["FRM_Onii"];
		@class.FRM_Onii_0.Invoke(new MethodInvoker(@class.method_0));
		bool bool_ = Class20.bool_0;
		if (bool_)
		{
			Console.WriteLine(@class.int_0.ToString() + string_1);
		}
		@class.FRM_Onii_0.method_5(string_1);
	}

	// Token: 0x04000001 RID: 1
	private Process process_0 = new Process();

	// Token: 0x04000002 RID: 2
	public Process process_1 = new Process();

	// Token: 0x04000003 RID: 3
	public string string_0 = File.ReadAllText("ssl\\udid.pl");

	// Token: 0x02000018 RID: 24
	[CompilerGenerated]
	private sealed class Class15
	{
		// Token: 0x060000F5 RID: 245 RVA: 0x00010479 File Offset: 0x0000E679
		internal void method_0()
		{
			this.FRM_Onii_0.method_6(this.int_0, this.int_0.ToString());
		}

		// Token: 0x040000A7 RID: 167
		public FRM_Onii FRM_Onii_0;

		// Token: 0x040000A8 RID: 168
		public int int_0;
	}
}
