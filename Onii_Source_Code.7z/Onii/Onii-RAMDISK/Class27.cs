﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

// Token: 0x0200000A RID: 10
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[CompilerGenerated]
[DebuggerNonUserCode]
internal class Class27
{
	// Token: 0x0600004F RID: 79 RVA: 0x000088A2 File Offset: 0x00006AA2
	internal Class27()
	{
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000050 RID: 80 RVA: 0x000088AC File Offset: 0x00006AAC
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager_0
	{
		get
		{
			bool flag = Class27.resourceManager_0 == null;
			if (flag)
			{
				ResourceManager resourceManager = new ResourceManager("Jo=p_:8d\\\\<@v\\,\\*ZB0YwI@pkQ)", typeof(Class27).Assembly);
				Class27.resourceManager_0 = resourceManager;
			}
			return Class27.resourceManager_0;
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000051 RID: 81 RVA: 0x000088F4 File Offset: 0x00006AF4
	// (set) Token: 0x06000052 RID: 82 RVA: 0x0000890B File Offset: 0x00006B0B
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo CultureInfo_0
	{
		get
		{
			return Class27.cultureInfo_0;
		}
		set
		{
			Class27.cultureInfo_0 = value;
		}
	}

	// Token: 0x0400002E RID: 46
	private static ResourceManager resourceManager_0;

	// Token: 0x0400002F RID: 47
	private static CultureInfo cultureInfo_0;
}
