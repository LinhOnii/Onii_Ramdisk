﻿using System;

// Token: 0x02000005 RID: 5
internal class Class20
{
	// Token: 0x0600002C RID: 44 RVA: 0x00005584 File Offset: 0x00003784
	public void method_0()
	{
		string text = Class20.string_4;
		string text2 = text;
		uint num = Hash.smethod_0(text2);
		bool flag = num > 1101423134U;
		if (flag)
		{
			bool flag2 = num > 2303764324U;
			if (flag2)
			{
				bool flag3 = num <= 3317288369U;
				if (flag3)
				{
					bool flag4 = num > 2337319562U;
					if (flag4)
					{
						bool flag5 = num == 3266955512U;
						if (flag5)
						{
							bool flag6 = text2 == "iPad7,11";
							if (flag6)
							{
								Class20.string_1 = "iPad (7th gen) (WiFi)";
								return;
							}
						}
						else
						{
							bool flag7 = num == 3317288369U;
							if (flag7)
							{
								bool flag8 = text2 == "iPad7,12";
								if (flag8)
								{
									Class20.string_1 = "iPad (7th gen) (Cellular)";
									return;
								}
							}
						}
					}
					else
					{
						bool flag9 = num != 2320541943U;
						if (flag9)
						{
							bool flag10 = num == 2337319562U;
							if (flag10)
							{
								bool flag11 = text2 == "iPhone10,1";
								if (flag11)
								{
									Class20.string_1 = "iPhone 8 (Global)";
									return;
								}
							}
						}
						else
						{
							bool flag12 = text2 == "iPhone10,2";
							if (flag12)
							{
								Class20.string_1 = "iPhone 8+ (Global)";
								return;
							}
						}
					}
				}
				else
				{
					bool flag13 = num > 3663264999U;
					if (flag13)
					{
						bool flag14 = num != 3680042618U;
						if (flag14)
						{
							bool flag15 = num == 4191237488U;
							if (flag15)
							{
								bool flag16 = text2 == "iPad6,3";
								if (flag16)
								{
									Class20.string_1 = "iPad Pro (9.7-inch) (WiFi)";
									return;
								}
							}
							else
							{
								bool flag17 = num == 4258347964U;
								if (flag17)
								{
									bool flag18 = text2 == "iPad6,7";
									if (flag18)
									{
										Class20.string_1 = "iPad Pro (12.9-inch)  (WiFi)";
										return;
									}
								}
							}
						}
						else
						{
							bool flag19 = text2 == "iPhone8,2";
							if (flag19)
							{
								Class20.string_1 = "iPhone 6s+";
								return;
							}
						}
					}
					else
					{
						bool flag20 = num != 3579376904U;
						if (flag20)
						{
							bool flag21 = num == 3663264999U;
							if (flag21)
							{
								bool flag22 = text2 == "iPhone8,1";
								if (flag22)
								{
									Class20.string_1 = "iPhone 6s";
									return;
								}
							}
						}
						else
						{
							bool flag23 = text2 == "iPhone8,4";
							if (flag23)
							{
								Class20.string_1 = "iPhone SE (1st Gen)";
								return;
							}
						}
					}
				}
			}
			else
			{
				bool flag24 = num > 1760014814U;
				if (flag24)
				{
					bool flag25 = num <= 2270209086U;
					if (flag25)
					{
						bool flag26 = num != 2253431467U;
						if (flag26)
						{
							bool flag27 = num == 2270209086U;
							if (flag27)
							{
								bool flag28 = text2 == "iPhone10,5";
								if (flag28)
								{
									Class20.string_1 = "iPhone 8+ (GSM)";
									return;
								}
							}
						}
						else
						{
							bool flag29 = text2 == "iPhone10,6";
							if (flag29)
							{
								Class20.string_1 = "iPhone X (GSM)";
								return;
							}
						}
					}
					else
					{
						bool flag30 = num == 2286986705U;
						if (flag30)
						{
							bool flag31 = text2 == "iPhone10,4";
							if (flag31)
							{
								Class20.string_1 = "iPhone 8 (GSM)";
								return;
							}
						}
						else
						{
							bool flag32 = num == 2303764324U;
							if (flag32)
							{
								bool flag33 = text2 == "iPhone10,3";
								if (flag33)
								{
									Class20.string_1 = "iPhone X (Global)";
									return;
								}
							}
						}
					}
				}
				else
				{
					bool flag34 = num <= 1134978372U;
					if (flag34)
					{
						bool flag35 = num != 1118200753U;
						if (flag35)
						{
							bool flag36 = num == 1134978372U && text2 == "iPad5,4";
							if (flag36)
							{
								Class20.string_1 = "iPad Air 2 (Cellular)";
								return;
							}
						}
						else
						{
							bool flag37 = text2 == "iPad5,3";
							if (flag37)
							{
								Class20.string_1 = "iPad Air 2 (WiFi)";
								return;
							}
						}
					}
					else
					{
						bool flag38 = num == 1743237195U;
						if (flag38)
						{
							bool flag39 = text2 == "iPhone7,2";
							if (flag39)
							{
								Class20.string_1 = "iPhone 6";
								return;
							}
						}
						else
						{
							bool flag40 = num == 1760014814U && text2 == "iPhone7,1";
							if (flag40)
							{
								Class20.string_1 = "iPhone 6+";
								return;
							}
						}
					}
				}
			}
		}
		else
		{
			bool flag41 = num > 291253989U;
			if (flag41)
			{
				bool flag42 = num > 897947417U;
				if (flag42)
				{
					bool flag43 = num <= 960488082U;
					if (flag43)
					{
						bool flag44 = num != 926932844U;
						if (flag44)
						{
							bool flag45 = num == 960488082U && text2 == "iPhone9,3";
							if (flag45)
							{
								Class20.string_1 = "iPhone 7 (GSM)";
								return;
							}
						}
						else
						{
							bool flag46 = text2 == "iPhone9,1";
							if (flag46)
							{
								Class20.string_1 = "iPhone 7 (Global)";
								return;
							}
						}
					}
					else
					{
						bool flag47 = num != 977265701U;
						if (flag47)
						{
							bool flag48 = num == 1084645515U;
							if (flag48)
							{
								bool flag49 = text2 == "iPad5,1";
								if (flag49)
								{
									Class20.string_1 = "iPad mini 4 (WiFi)";
									return;
								}
							}
							else
							{
								bool flag50 = num == 1101423134U;
								if (flag50)
								{
									bool flag51 = text2 == "iPad5,2";
									if (flag51)
									{
										Class20.string_1 = "iPad mini 4 (Cellular)";
										return;
									}
								}
							}
						}
						else
						{
							bool flag52 = text2 == "iPhone9,2";
							if (flag52)
							{
								Class20.string_1 = "iPhone 7+ (Global)";
								return;
							}
						}
					}
				}
				else
				{
					bool flag53 = num > 318674021U;
					if (flag53)
					{
						bool flag54 = num != 876599987U;
						if (flag54)
						{
							bool flag55 = num == 897947417U && text2 == "iPod9,1";
							if (flag55)
							{
								Class20.string_1 = "iPod touch 7";
								return;
							}
						}
						else
						{
							bool flag56 = text2 == "iPhone9,4";
							if (flag56)
							{
								Class20.string_1 = "iPhone 7 Plus (GSM)";
								return;
							}
						}
					}
					else
					{
						bool flag57 = num != 301896402U;
						if (flag57)
						{
							bool flag58 = num == 318674021U;
							if (flag58)
							{
								bool flag59 = text2 == "iPad7,5";
								if (flag59)
								{
									Class20.string_1 = "iPad (6th gen) (WiFi)";
									return;
								}
							}
						}
						else
						{
							bool flag60 = text2 == "iPad7,4";
							if (flag60)
							{
								Class20.string_1 = "iPad Pro (10.5-inch, Cellular)";
								return;
							}
						}
					}
				}
			}
			else
			{
				bool flag61 = num <= 218008307U;
				if (flag61)
				{
					bool flag62 = num > 80824001U;
					if (flag62)
					{
						bool flag63 = num == 201230688U;
						if (flag63)
						{
							bool flag64 = text2 == "iPad7,2";
							if (flag64)
							{
								Class20.string_1 = "iPad Pro 2 (12.9-inch, Cellular)";
								return;
							}
						}
						else
						{
							bool flag65 = num == 218008307U && text2 == "iPad7,3";
							if (flag65)
							{
								Class20.string_1 = "iPad Pro (10.5-inch, WiFi)";
								return;
							}
						}
					}
					else
					{
						bool flag66 = num == 13713525U;
						if (flag66)
						{
							bool flag67 = text2 == "iPad6,4";
							if (flag67)
							{
								Class20.string_1 = "iPad Pro (9.7-inch)";
								return;
							}
						}
						else
						{
							bool flag68 = num == 80824001U;
							if (flag68)
							{
								bool flag69 = text2 == "iPad6,8";
								if (flag69)
								{
									Class20.string_1 = "iPad Pro (12.9-inch)  (WiFi)";
									return;
								}
							}
						}
					}
				}
				else
				{
					bool flag70 = num <= 251563545U;
					if (flag70)
					{
						bool flag71 = num == 240921132U;
						if (flag71)
						{
							bool flag72 = text2 == "iPad6,12";
							if (flag72)
							{
								Class20.string_1 = "iPad (5th generation) (Cellular)";
								return;
							}
						}
						else
						{
							bool flag73 = num == 251563545U;
							if (flag73)
							{
								bool flag74 = text2 == "iPad7,1";
								if (flag74)
								{
									Class20.string_1 = "iPad Pro 2 (12.9-inch, WiFi)";
									return;
								}
							}
						}
					}
					else
					{
						bool flag75 = num != 268341164U;
						if (flag75)
						{
							bool flag76 = num == 291253989U && text2 == "iPad6,11";
							if (flag76)
							{
								Class20.string_1 = "iPad 5 (WiFi)";
								return;
							}
						}
						else
						{
							bool flag77 = text2 == "iPad7,6";
							if (flag77)
							{
								Class20.string_1 = "iPad (6th gen) (Cellular)";
								return;
							}
						}
					}
				}
			}
		}
		Class20.string_1 = "UNSUPPORTED !!";
	}

	// Token: 0x0400000C RID: 12
	public static bool bool_0 = false;

	// Token: 0x0400000D RID: 13
	public static string string_0 = "";

	// Token: 0x0400000E RID: 14
	public static string string_1 = "";

	// Token: 0x0400000F RID: 15
	public static string string_2 = "";

	// Token: 0x04000010 RID: 16
	public static string string_3 = "";

	// Token: 0x04000011 RID: 17
	public static string string_4 = "";

	// Token: 0x04000012 RID: 18
	public static string string_5 = "";

	// Token: 0x04000013 RID: 19
	public static string string_6 = "";

	// Token: 0x04000014 RID: 20
	public static string string_7 = "";

	// Token: 0x04000015 RID: 21
	public static string string_8 = "";

	// Token: 0x04000016 RID: 22
	public static bool bool_1 = false;

	// Token: 0x04000017 RID: 23
	public static string string_9 = "";

	// Token: 0x04000018 RID: 24
	public static string string_10 = "";

	// Token: 0x04000019 RID: 25
	public static string string_11 = "";

	// Token: 0x0400001A RID: 26
	public static string string_12 = "";

	// Token: 0x0400001B RID: 27
	public static string string_13 = "";

	// Token: 0x0400001C RID: 28
	public static string string_14 = "";
}
