﻿using System;
using System.IO;
using System.IO.Compression;

// Token: 0x02000007 RID: 7
internal class Class23
{
	// Token: 0x06000046 RID: 70 RVA: 0x00008545 File Offset: 0x00006745
	public void method_0()
	{
		ZipFile.ExtractToDirectory(Class23.string_1, this.string_2);
	}

	// Token: 0x0400002B RID: 43
	public static string string_0 = Directory.GetCurrentDirectory();

	// Token: 0x0400002C RID: 44
	public static string string_1 = ".\\Backups\\0x00164966102b003a.zip";

	// Token: 0x0400002D RID: 45
	private string string_2 = Environment.CurrentDirectory + "\\Backups\\0x00164966102b003a";
}
