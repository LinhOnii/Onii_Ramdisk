﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("5.8.0.0")]
[assembly: AssemblyTrademark("Onii Ramdisk")]
[assembly: AssemblyCopyright("Copyright © Onii Ramdisk 2022")]
[assembly: AssemblyProduct("Onii-Ramdisk")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("5.8.0.0")]
[assembly: Guid("0402165d-78a1-43ad-aec0-2d7468f19ad1")]
[assembly: AssemblyTitle("Onii Ramdisk")]
[assembly: AssemblyCompany("Onii TECH")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("Developed by Onii")]
