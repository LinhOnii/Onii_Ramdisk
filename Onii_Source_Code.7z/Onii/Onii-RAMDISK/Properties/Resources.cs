﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Onii_Ramdisk.Properties.Properties
{
	// Token: 0x02000017 RID: 23
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x060000EF RID: 239 RVA: 0x000088A2 File Offset: 0x00006AA2
		internal Resources()
		{
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x000103B4 File Offset: 0x0000E5B4
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = Resources.resourceMan == null;
				if (flag)
				{
					ResourceManager temp = new ResourceManager("Onii_Ramdisk.Properties.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = temp;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060000F1 RID: 241 RVA: 0x000103FC File Offset: 0x0000E5FC
		// (set) Token: 0x060000F2 RID: 242 RVA: 0x00010413 File Offset: 0x0000E613
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x060000F3 RID: 243 RVA: 0x0001041C File Offset: 0x0000E61C
		internal static Bitmap background1
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("background1", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x0001044C File Offset: 0x0000E64C
		internal static Bitmap photo_2024_06_14_21_38_23
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("photo_2024-06-14_21-38-23", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x040000A5 RID: 165
		private static ResourceManager resourceMan;

		// Token: 0x040000A6 RID: 166
		private static CultureInfo resourceCulture;
	}
}
