﻿// Token: 0x02000010 RID: 16
public partial class FRM_Helper : global::MetroFramework.Forms.MetroForm
{
	// Token: 0x06000081 RID: 129 RVA: 0x00009E68 File Offset: 0x00008068
	private void InitializeComponent()
	{
		this.components = new global::System.ComponentModel.Container();
		global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::FRM_Helper));
		this.devicePicture = new global::System.Windows.Forms.PictureBox();
		this.label24 = new global::System.Windows.Forms.Label();
		this.btn_Start = new global::System.Windows.Forms.Button();
		this.btn_Cancel = new global::System.Windows.Forms.Button();
		this.metroLabel1 = new global::MetroFramework.Controls.MetroLabel();
		this.metroLabel2 = new global::MetroFramework.Controls.MetroLabel();
		this.metroLabel6 = new global::MetroFramework.Controls.MetroLabel();
		this.metroLabel7 = new global::MetroFramework.Controls.MetroLabel();
		this.metroLabel8 = new global::MetroFramework.Controls.MetroLabel();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.components);
		this.timer_1 = new global::System.Windows.Forms.Timer(this.components);
		this.lbl_start = new global::System.Windows.Forms.Label();
		this.lbl_timer1 = new global::System.Windows.Forms.Label();
		this.lbl_timer2 = new global::System.Windows.Forms.Label();
		this.metroLabel3 = new global::MetroFramework.Controls.MetroLabel();
		this.panel1 = new global::System.Windows.Forms.Panel();
		this.progressBar1 = new global::MetroFramework.Controls.MetroProgressBar();
		this.label1 = new global::System.Windows.Forms.Label();
		((global::System.ComponentModel.ISupportInitialize)this.devicePicture).BeginInit();
		this.panel1.SuspendLayout();
		base.SuspendLayout();
		this.devicePicture.BackColor = global::System.Drawing.SystemColors.Control;
		this.devicePicture.Location = new global::System.Drawing.Point(106, 79);
		this.devicePicture.Name = "devicePicture";
		this.devicePicture.Size = new global::System.Drawing.Size(115, 211);
		this.devicePicture.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.devicePicture.TabIndex = 11;
		this.devicePicture.TabStop = false;
		this.devicePicture.Visible = false;
		this.label24.AutoSize = true;
		this.label24.Location = new global::System.Drawing.Point(22, 33);
		this.label24.Name = "label24";
		this.label24.Size = new global::System.Drawing.Size(0, 13);
		this.label24.TabIndex = 15;
		this.btn_Start.Location = new global::System.Drawing.Point(440, 304);
		this.btn_Start.Name = "btn_Start";
		this.btn_Start.Size = new global::System.Drawing.Size(90, 23);
		this.btn_Start.TabIndex = 25;
		this.btn_Start.Text = "Start";
		this.btn_Start.UseVisualStyleBackColor = true;
		this.btn_Start.Click += new global::System.EventHandler(this.btn_Start_Click);
		this.btn_Cancel.Location = new global::System.Drawing.Point(336, 304);
		this.btn_Cancel.Name = "btn_Cancel";
		this.btn_Cancel.Size = new global::System.Drawing.Size(90, 23);
		this.btn_Cancel.TabIndex = 24;
		this.btn_Cancel.Text = "Cancel";
		this.btn_Cancel.UseVisualStyleBackColor = true;
		this.btn_Cancel.Click += new global::System.EventHandler(this.btn_Cancel_Click);
		this.metroLabel1.AutoSize = true;
		this.metroLabel1.Location = new global::System.Drawing.Point(7, 27);
		this.metroLabel1.Name = "metroLabel1";
		this.metroLabel1.Size = new global::System.Drawing.Size(471, 19);
		this.metroLabel1.TabIndex = 26;
		this.metroLabel1.Text = "Time to put the device into DFU mode. Locate the buttons as marked below on";
		this.metroLabel1.Theme = global::MetroFramework.MetroThemeStyle.Dark;
		this.metroLabel2.AutoSize = true;
		this.metroLabel2.Location = new global::System.Drawing.Point(7, 46);
		this.metroLabel2.Name = "metroLabel2";
		this.metroLabel2.Size = new global::System.Drawing.Size(436, 19);
		this.metroLabel2.TabIndex = 27;
		this.metroLabel2.Text = "device and check the instructions on the right *before* clicking Start.";
		this.metroLabel2.Theme = global::MetroFramework.MetroThemeStyle.Dark;
		this.metroLabel6.AutoSize = true;
		this.metroLabel6.Location = new global::System.Drawing.Point(227, 103);
		this.metroLabel6.Name = "metroLabel6";
		this.metroLabel6.Size = new global::System.Drawing.Size(88, 19);
		this.metroLabel6.TabIndex = 31;
		this.metroLabel6.Text = "--Side Button";
		this.metroLabel6.Theme = global::MetroFramework.MetroThemeStyle.Dark;
		this.metroLabel7.AutoSize = true;
		this.metroLabel7.Location = new global::System.Drawing.Point(4, 126);
		this.metroLabel7.Name = "metroLabel7";
		this.metroLabel7.Size = new global::System.Drawing.Size(102, 19);
		this.metroLabel7.TabIndex = 20;
		this.metroLabel7.Text = "Volume Down--";
		this.metroLabel7.Theme = global::MetroFramework.MetroThemeStyle.Dark;
		this.metroLabel8.AutoSize = true;
		this.metroLabel8.Location = new global::System.Drawing.Point(178, 261);
		this.metroLabel8.Name = "metroLabel8";
		this.metroLabel8.Size = new global::System.Drawing.Size(99, 19);
		this.metroLabel8.TabIndex = 32;
		this.metroLabel8.Text = "--Home Button";
		this.metroLabel8.Theme = global::MetroFramework.MetroThemeStyle.Dark;
		this.metroLabel8.Visible = false;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		this.timer_1.Interval = 1000;
		this.timer_1.Tick += new global::System.EventHandler(this.timer_1_Tick);
		this.lbl_start.AutoSize = true;
		this.lbl_start.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lbl_start.ForeColor = global::System.Drawing.SystemColors.ControlLight;
		this.lbl_start.Location = new global::System.Drawing.Point(330, 120);
		this.lbl_start.Name = "lbl_start";
		this.lbl_start.Size = new global::System.Drawing.Size(79, 16);
		this.lbl_start.TabIndex = 35;
		this.lbl_start.Text = "1. Click Start";
		this.lbl_timer1.AutoSize = true;
		this.lbl_timer1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lbl_timer1.ForeColor = global::System.Drawing.SystemColors.ControlDark;
		this.lbl_timer1.Location = new global::System.Drawing.Point(330, 160);
		this.lbl_timer1.Name = "lbl_timer1";
		this.lbl_timer1.Size = new global::System.Drawing.Size(165, 48);
		this.lbl_timer1.TabIndex = 38;
		this.lbl_timer1.Text = "2. Press and hold the Side \r\nand Volume down buttons \r\ntogether (6)";
		this.lbl_timer2.AutoSize = true;
		this.lbl_timer2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lbl_timer2.ForeColor = global::System.Drawing.SystemColors.ControlDark;
		this.lbl_timer2.Location = new global::System.Drawing.Point(330, 228);
		this.lbl_timer2.Name = "lbl_timer2";
		this.lbl_timer2.Size = new global::System.Drawing.Size(188, 16);
		this.lbl_timer2.TabIndex = 39;
		this.lbl_timer2.Text = "3. Release the Side button (10)";
		this.metroLabel3.AutoSize = true;
		this.metroLabel3.Location = new global::System.Drawing.Point(20, 103);
		this.metroLabel3.Name = "metroLabel3";
		this.metroLabel3.Size = new global::System.Drawing.Size(86, 19);
		this.metroLabel3.TabIndex = 40;
		this.metroLabel3.Text = "Volume Up--";
		this.metroLabel3.Theme = global::MetroFramework.MetroThemeStyle.Dark;
		this.metroLabel3.Visible = false;
		this.panel1.Controls.Add(this.progressBar1);
		this.panel1.Controls.Add(this.label1);
		this.panel1.Location = new global::System.Drawing.Point(4, 78);
		this.panel1.Name = "panel1";
		this.panel1.Size = new global::System.Drawing.Size(543, 212);
		this.panel1.TabIndex = 41;
		this.panel1.Visible = false;
		this.progressBar1.FontSize = global::MetroFramework.MetroProgressBarSize.Small;
		this.progressBar1.HideProgressText = false;
		this.progressBar1.Location = new global::System.Drawing.Point(5, 145);
		this.progressBar1.Name = "progressBar1";
		this.progressBar1.Size = new global::System.Drawing.Size(534, 21);
		this.progressBar1.TabIndex = 3;
		this.progressBar1.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.progressBar1.Theme = global::MetroFramework.MetroThemeStyle.Dark;
		this.label1.AutoSize = true;
		this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.label1.ForeColor = global::System.Drawing.Color.LawnGreen;
		this.label1.Location = new global::System.Drawing.Point(3, 121);
		this.label1.Name = "label1";
		this.label1.Size = new global::System.Drawing.Size(124, 18);
		this.label1.TabIndex = 1;
		this.label1.Text = "Setting Up Exploit";
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(550, 334);
		base.Controls.Add(this.panel1);
		base.Controls.Add(this.metroLabel3);
		base.Controls.Add(this.lbl_timer2);
		base.Controls.Add(this.lbl_timer1);
		base.Controls.Add(this.lbl_start);
		base.Controls.Add(this.metroLabel8);
		base.Controls.Add(this.metroLabel7);
		base.Controls.Add(this.metroLabel6);
		base.Controls.Add(this.metroLabel2);
		base.Controls.Add(this.metroLabel1);
		base.Controls.Add(this.btn_Start);
		base.Controls.Add(this.btn_Cancel);
		base.Controls.Add(this.label24);
		base.Controls.Add(this.devicePicture);
		base.Icon = (global::System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "FRM_Helper";
		base.Resizable = false;
		base.Style = global::MetroFramework.MetroColorStyle.Pink;
		base.Theme = global::MetroFramework.MetroThemeStyle.Dark;
		base.Load += new global::System.EventHandler(this.FRM_Helper_Load);
		((global::System.ComponentModel.ISupportInitialize)this.devicePicture).EndInit();
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400003C RID: 60
	private global::System.Windows.Forms.PictureBox devicePicture;

	// Token: 0x0400003D RID: 61
	private global::System.Windows.Forms.Label label24;

	// Token: 0x0400003E RID: 62
	private global::System.Windows.Forms.Button btn_Start;

	// Token: 0x0400003F RID: 63
	private global::System.Windows.Forms.Button btn_Cancel;

	// Token: 0x04000040 RID: 64
	private global::MetroFramework.Controls.MetroLabel metroLabel1;

	// Token: 0x04000041 RID: 65
	private global::MetroFramework.Controls.MetroLabel metroLabel2;

	// Token: 0x04000042 RID: 66
	private global::MetroFramework.Controls.MetroLabel metroLabel6;

	// Token: 0x04000043 RID: 67
	private global::MetroFramework.Controls.MetroLabel metroLabel7;

	// Token: 0x04000044 RID: 68
	private global::MetroFramework.Controls.MetroLabel metroLabel8;

	// Token: 0x04000045 RID: 69
	private global::System.Windows.Forms.Timer timer_0;

	// Token: 0x04000046 RID: 70
	private global::System.Windows.Forms.Timer timer_1;

	// Token: 0x04000047 RID: 71
	private global::System.Windows.Forms.Label lbl_start;

	// Token: 0x04000048 RID: 72
	private global::System.Windows.Forms.Label lbl_timer1;

	// Token: 0x04000049 RID: 73
	private global::System.Windows.Forms.Label lbl_timer2;

	// Token: 0x0400004A RID: 74
	private global::MetroFramework.Controls.MetroLabel metroLabel3;

	// Token: 0x0400004B RID: 75
	private global::System.Windows.Forms.Panel panel1;

	// Token: 0x0400004C RID: 76
	private global::System.Windows.Forms.Label label1;

	// Token: 0x0400004D RID: 77
	private global::MetroFramework.Controls.MetroProgressBar progressBar1;

	// Token: 0x0400004E RID: 78
	private global::System.ComponentModel.IContainer components;
}
