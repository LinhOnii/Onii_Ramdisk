﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using LibUsbDotNet.DeviceNotify;
using MetroFramework;
using MetroFramework.Controls;
using MetroFramework.Forms;
using Onii_Ramdisk.Properties.Properties;
using Renci.SshNet;
using Renci.SshNet.Common;

// Token: 0x02000011 RID: 17
public partial class FRM_Onii : MetroForm
{
	// Token: 0x06000083 RID: 131 RVA: 0x0000A9E8 File Offset: 0x00008BE8
	public FRM_Onii()
	{
		this.InitializeComponent();
		this.gclass2_0.method_6();
		this.method_0();
		this.txt_info.Text = "Welcome to Onii Ramdisk | Version " + Application.ProductVersion;
		this.method_7();
		this.method_1();
	}

	// Token: 0x06000084 RID: 132 RVA: 0x0000AADC File Offset: 0x00008CDC
	private string method_0()
	{
		string text3;
		try
		{
			string text = "https://api.ipify.org/";
			HttpWebRequest httpWebRequest = WebRequest.CreateHttp(text);
			httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
			httpWebRequest.Timeout = -1;
			string text2;
			using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
			{
				using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
				{
					text2 = (GClass1.string_5 = streamReader.ReadToEnd());
				}
				GClass1.string_5 = text2;
			}
			text3 = text2;
		}
		catch
		{
			text3 = "Lỗi";
		}
		return text3;
	}

	// Token: 0x06000085 RID: 133 RVA: 0x0000AB98 File Offset: 0x00008D98
	private void method_1()
	{
		string text = "";
		try
		{
			string text2 = "http://pentaboy.my.id/ramdisk/update.php?version=" + Application.ProductVersion;
			HttpWebRequest httpWebRequest = WebRequest.CreateHttp(text2);
			httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
			httpWebRequest.Timeout = -1;
			using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
			{
				using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
				{
					text = streamReader.ReadToEnd();
				}
			}
			bool flag = text == "Maintenance";
			if (flag)
			{
				MessageBox.Show("Server Maintenance !!! \nPlease be patience to FIX !!!", "Onii Ramdisk Maintenance !!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Process.GetCurrentProcess().Kill();
			}
		}
		catch
		{
		}
	}

	// Token: 0x06000086 RID: 134 RVA: 0x0000AC78 File Offset: 0x00008E78
	private void btn_checkdev_Click(object sender, EventArgs e)
	{
		this.gclass2_0.method_6();
		this.method_2();
		this.timer_0.Enabled = false;
	}

	// Token: 0x06000087 RID: 135 RVA: 0x0000AC9C File Offset: 0x00008E9C
	private void copyBox_Click(object sender, EventArgs e)
	{
		try
		{
			Clipboard.SetText(Class20.string_2);
			MessageBox.Show("ECID: " + Class20.string_2 + " Hoàn thành COPY", "Onii Ramdisk", MessageBoxButtons.OK);
		}
		catch
		{
		}
	}

	// Token: 0x06000088 RID: 136 RVA: 0x0000ACF0 File Offset: 0x00008EF0
	public void method_2()
	{
		Control.CheckForIllegalCrossThreadCalls = false;
		bool flag = Interlocked.Exchange(ref FRM_Onii.int_3, 1) != 0;
		if (flag)
		{
			Console.WriteLine("   {0} was denied the lock", Thread.CurrentThread.Name);
		}
		else
		{
			bool flag2 = !this.method_3("");
			if (flag2)
			{
				Class20.string_2 = "";
				Class20.string_9 = "";
				this.txt_model.Text = "-";
				this.txt_Type.Text = "-";
				this.txt_mode.Text = "-";
				this.lbl_pwned.Text = "-";
				this.btn_boot1.Enabled = false;
				this.txt_info.Text = "No device Detected";
			}
			else
			{
				this.btn_boot1.Enabled = true;
				this.txt_info.Text = Class20.string_1 + " Connected";
			}
		}
	}

	// Token: 0x06000089 RID: 137 RVA: 0x0000ADEC File Offset: 0x00008FEC
	private bool method_3(string string_5 = "")
	{
		Control.CheckForIllegalCrossThreadCalls = false;
		Process process = new Process();
		process.StartInfo.FileName = Environment.CurrentDirectory + "/files/irecovery.exe";
		process.StartInfo.Arguments = "-q";
		process.StartInfo.UseShellExecute = false;
		process.StartInfo.RedirectStandardOutput = true;
		process.StartInfo.CreateNoWindow = true;
		process.Start();
		int num = 0;
		while (!process.StandardOutput.EndOfStream)
		{
			num++;
			string text = process.StandardOutput.ReadLine();
			string text2 = text.Replace("\r", "");
			bool flag = !text2.StartsWith("ECID: ");
			if (flag)
			{
				bool flag2 = !text2.StartsWith("MODEL: ");
				if (flag2)
				{
					bool flag3 = !text2.StartsWith("PRODUCT: ");
					if (flag3)
					{
						bool flag4 = text2.StartsWith("NAME: ");
						if (flag4)
						{
							Class20.string_1 = text2.Replace("NAME: ", "");
						}
						else
						{
							bool flag5 = !text2.StartsWith("CPID: ");
							if (flag5)
							{
								bool flag6 = text2.StartsWith("MODE: ");
								if (flag6)
								{
									Class20.string_5 = text2.Replace("MODE: ", "");
								}
								else
								{
									bool flag7 = text2.StartsWith("PWND: ");
									if (flag7)
									{
										string text3 = Class20.string_3 = text2.Replace("PWND: ", "");
										this.lbl_pwned.Text = text3;
										string text4 = Class20.string_3;
										this.btn_changeSN.Enabled = true;
										bool flag8 = !(text4 == "CHECKM8") && !(text4 == "GASTER") && !(text4 == "IBOYM8") && !(text4 == "IKEYM8");
										if (flag8)
										{
											this.lbl_pwned.ForeColor = Color.Yellow;
										}
										else
										{
											this.lbl_pwned.ForeColor = Color.SpringGreen;
										}
									}
								}
							}
							else
							{
								Class20.string_9 = text2.Replace("CPID: ", "").Trim();
							}
						}
					}
					else
					{
						Class20.string_4 = text2.Replace("PRODUCT: ", "");
					}
				}
				else
				{
					Class20.string_0 = text2.Replace("MODEL: ", "");
				}
			}
			else
			{
				string text5 = text2.Replace("ECID: ", "");
				Class20.string_2 = text5.Trim();
			}
			text.Split(new char[]
			{
				':'
			});
		}
		this.txt_mode.Text = Class20.string_5;
		this.txt_model.Text = Class20.string_1;
		this.txt_Type.Text = Class20.string_4 + "-" + Class20.string_0;
		Class20.string_12 = Class20.string_4 + "-" + Class20.string_0 + ".zip";
		Interlocked.Exchange(ref FRM_Onii.int_3, 0);
		return num > 2;
	}

	// Token: 0x0600008A RID: 138 RVA: 0x0000B114 File Offset: 0x00009314
	private void btn_changeSN_Click(object sender, EventArgs e)
	{
		FRM_Purple frm_Purple = new FRM_Purple();
		bool flag = !(this.lbl_pwned.Text != "-");
		if (flag)
		{
			bool flag2 = this.txt_mode.Text == "Recovery";
			if (flag2)
			{
				MessageBox.Show("device in Recovery Mode \nPlease Connect in PWNDFU MODE", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				MessageBox.Show("iPWNDFU Not Detected! \nPlease Connect Device With iPWNDFU Done!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}
		else
		{
			frm_Purple.ShowDialog();
		}
	}

	// Token: 0x0600008B RID: 139 RVA: 0x0000B198 File Offset: 0x00009398
	private void btn_boot1_Click(object sender, EventArgs e)
	{
		bool flag = !(this.lbl_pwned.Text != "-");
		if (flag)
		{
			MessageBox.Show("PLEASE CONNECT PWNDFU DEVICES !", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
		else
		{
			bool flag2 = !(this.ComboBox1.Text == "-select-");
			if (flag2)
			{
				bool flag3 = this.ComboBox1.Text == "15";
				if (flag3)
				{
					Class20.string_11 = "15";
					this.string_4 = "boot";
					this.backgroundWorker_1.RunWorkerAsync();
				}
				else
				{
					bool flag4 = this.ComboBox1.Text == "16";
					if (flag4)
					{
						this.string_4 = "boot2";
						Class20.string_11 = "16";
						this.backgroundWorker_1.RunWorkerAsync();
					}
					else
					{
						this.string_4 = "boot2";
						Class20.string_11 = "16.4";
						this.backgroundWorker_1.RunWorkerAsync();
					}
				}
			}
			else
			{
				MessageBox.Show("PLEASE SELECT RAMDISK VERSION!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}
	}

	// Token: 0x0600008C RID: 140 RVA: 0x0000B2B3 File Offset: 0x000094B3
	public void method_5(string string_5)
	{
		this.txt_info.Text = string_5;
	}

	// Token: 0x0600008D RID: 141 RVA: 0x0000B2C3 File Offset: 0x000094C3
	public void method_6(int int_4, string string_5)
	{
		this.progressBar1.Value = int_4;
	}

	// Token: 0x0600008E RID: 142 RVA: 0x0000B2D3 File Offset: 0x000094D3
	private void Thongtin(object sender, EventArgs e)
	{
		Process.Start("https://docs.google.com/document/d/1HYy-E9yRi2pEXhx0sVwJdkbpQZiZZURJWCoPi9ViWGo/edit");
	}

	// Token: 0x0600008F RID: 143 RVA: 0x0000B2E1 File Offset: 0x000094E1
	private void btn_readHello_Click(object sender, EventArgs e)
	{
		this.method_32();
	}

	// Token: 0x06000090 RID: 144 RVA: 0x0000B2EC File Offset: 0x000094EC
	private void btn_get_activation_Click(object sender, EventArgs e)
	{
		this.string_4 = "gen_activation";
		this.method_7();
		Class14 @class = new Class14();
		File.WriteAllText("ssl\\udid.pl", @class.method_13("UniqueDeviceID").Trim());
		this.backgroundWorker_1.RunWorkerAsync();
		this.method_7();
	}

	// Token: 0x06000091 RID: 145 RVA: 0x0000B340 File Offset: 0x00009540
	public void method_7()
	{
		this.btn_activate.Enabled = false;
		this.btn_backup.Enabled = false;
		this.btn_boot1.Enabled = false;
		this.btn_eraser.Enabled = false;
		this.btn_checkSSH.Enabled = false;
		this.btn_get_activation.Enabled = false;
		this.btn_act_hello.Enabled = false;
		this.btn_changeSN.Enabled = false;
		this.btn_checkdev.Enabled = false;
	}

	// Token: 0x06000092 RID: 146 RVA: 0x0000B3C3 File Offset: 0x000095C3
	private void btn_act_hello_Click(object sender, EventArgs e)
	{
		this.method_7();
		this.string_4 = "hello_activation";
		this.backgroundWorker_1.RunWorkerAsync();
		this.method_8();
	}

	// Token: 0x06000093 RID: 147 RVA: 0x0000B3EC File Offset: 0x000095EC
	public void method_8()
	{
		this.btn_activate.Enabled = true;
		this.btn_backup.Enabled = true;
		this.btn_boot1.Enabled = true;
		this.btn_eraser.Enabled = true;
		this.btn_get_activation.Enabled = true;
		this.btn_act_hello.Enabled = true;
		this.btn_changeSN.Enabled = true;
		this.btn_checkdev.Enabled = true;
		this.btn_checkSSH.Enabled = true;
	}

	// Token: 0x06000094 RID: 148 RVA: 0x0000B470 File Offset: 0x00009670
	private void btn_checkSSH_Click(object sender, EventArgs e)
	{
		this.method_7();
		bool flag = !(Class20.string_11 == "15");
		if (flag)
		{
			bool flag2 = !(Class20.string_11 == "16.4");
			if (flag2)
			{
				this.method_11();
			}
			else
			{
				bool flag3 = Class20.string_4.Contains("iPad");
				if (flag3)
				{
					this.method_11();
				}
				else
				{
					this.method_12();
				}
			}
		}
		else
		{
			this.method_10();
		}
		this.method_8();
	}

	// Token: 0x06000095 RID: 149 RVA: 0x0000B4F8 File Offset: 0x000096F8
	private bool method_9()
	{
		bool flag;
		try
		{
			this.method_20(this.int_1, 22);
			this.method_19("127.0.0.1", this.int_1, "alpine");
			this.method_16();
			bool flag2 = !this.sshClient_0.IsConnected;
			if (flag2)
			{
				this.sshClient_0.Connect();
			}
			flag = true;
		}
		catch
		{
			flag = false;
		}
		return flag;
	}

	// Token: 0x06000096 RID: 150 RVA: 0x0000B578 File Offset: 0x00009778
	public void method_10()
	{
		bool flag = this.method_9();
		if (flag)
		{
			this.progressBar1.Value = 100;
			Class21 @class = new Class21();
			@class.method_4();
			@class.method_2();
		}
		else
		{
			this.method_24();
		}
	}

	// Token: 0x06000097 RID: 151 RVA: 0x0000B5C0 File Offset: 0x000097C0
	public void method_11()
	{
		bool flag = this.method_14();
		if (flag)
		{
			this.progressBar1.Value = 100;
			MessageBox.Show("Hoàn thành SSH Connected!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else
		{
			this.method_24();
		}
	}

	// Token: 0x06000098 RID: 152 RVA: 0x0000B608 File Offset: 0x00009808
	public void method_12()
	{
		bool flag = this.method_9();
		if (flag)
		{
			this.progressBar1.Value = 100;
			MessageBox.Show("Hoàn thành SSH Connected!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else
		{
			this.method_24();
		}
	}

	// Token: 0x06000099 RID: 153 RVA: 0x0000B650 File Offset: 0x00009850
	public void method_13()
	{
		bool flag = this.method_15();
		if (flag)
		{
			this.progressBar1.Value = 100;
			MessageBox.Show("Hoàn thành SSH Connected!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else
		{
			this.method_24();
		}
	}

	// Token: 0x0600009A RID: 154 RVA: 0x0000B698 File Offset: 0x00009898
	private bool method_14()
	{
		bool flag;
		try
		{
			this.method_20(this.int_1, 86);
			this.method_19("127.0.0.1", this.int_1, "TgRam2022");
			this.method_17();
			bool flag2 = !this.sshClient_0.IsConnected;
			if (flag2)
			{
				this.sshClient_0.Connect();
			}
			flag = true;
		}
		catch
		{
			flag = false;
		}
		return flag;
	}

	// Token: 0x0600009B RID: 155 RVA: 0x0000B718 File Offset: 0x00009918
	private bool method_15()
	{
		bool flag;
		try
		{
			this.method_20(this.int_1, 44);
			this.method_19("127.0.0.1", this.int_1, "alpine");
			this.method_18();
			bool flag2 = !this.sshClient_0.IsConnected;
			if (flag2)
			{
				this.sshClient_0.Connect();
			}
			flag = true;
		}
		catch
		{
			flag = false;
		}
		return flag;
	}

	// Token: 0x0600009C RID: 156 RVA: 0x0000B798 File Offset: 0x00009998
	public void method_16()
	{
		this.method_24();
		Thread.Sleep(2000);
		using (Process process = new Process())
		{
			process.StartInfo.FileName = FRM_Onii.string_0 + "\\files\\iproxy.exe";
			process.StartInfo.Arguments = this.int_0.ToString() + " 22";
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			process.StartInfo.CreateNoWindow = true;
			process.Start();
		}
		try
		{
			this.method_21();
		}
		catch
		{
		}
	}

	// Token: 0x0600009D RID: 157 RVA: 0x0000B874 File Offset: 0x00009A74
	public void method_17()
	{
		this.method_24();
		Thread.Sleep(2000);
		using (Process process = new Process())
		{
			process.StartInfo.FileName = FRM_Onii.string_0 + "\\files\\iproxy.exe";
			process.StartInfo.Arguments = this.int_0.ToString() + " 86";
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			process.StartInfo.CreateNoWindow = true;
			process.Start();
		}
		try
		{
			this.method_23();
		}
		catch
		{
		}
	}

	// Token: 0x0600009E RID: 158 RVA: 0x0000B950 File Offset: 0x00009B50
	public void method_18()
	{
		this.method_24();
		Thread.Sleep(2000);
		using (Process process = new Process())
		{
			process.StartInfo.FileName = FRM_Onii.string_0 + "\\files\\iproxy.exe";
			process.StartInfo.Arguments = this.int_0.ToString() + " 44";
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			process.StartInfo.CreateNoWindow = true;
			process.Start();
		}
		try
		{
			this.method_22();
		}
		catch
		{
		}
	}

	// Token: 0x0600009F RID: 159 RVA: 0x0000BA2C File Offset: 0x00009C2C
	public void method_19(string string_5, int int_4, string string_6)
	{
		AuthenticationMethod[] array = new AuthenticationMethod[]
		{
			new PasswordAuthenticationMethod("root", string_6)
		};
		ConnectionInfo connectionInfo = new ConnectionInfo(string_5, int_4, "root", array);
		SshClient sshClient = new SshClient(connectionInfo);
		sshClient.Connect();
		sshClient.Disconnect();
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x0000BA74 File Offset: 0x00009C74
	public void method_20(int int_4, int int_5)
	{
		string text = FRM_Onii.string_0 + "/files/iproxy.exe";
		bool flag = (this.process_0 == null && File.Exists(text)) || this.process_0.HasExited;
		if (flag)
		{
			this.process_0 = new Process();
			this.process_0.StartInfo.FileName = text;
			this.process_0.StartInfo.Arguments = int_4.ToString() + " " + int_5.ToString();
			this.process_0.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			this.process_0.Start();
		}
		else
		{
			bool flag2 = File.Exists(text);
			if (flag2)
			{
			}
		}
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x0000BB28 File Offset: 0x00009D28
	public void method_21()
	{
		AuthenticationMethod[] array = new AuthenticationMethod[]
		{
			new PasswordAuthenticationMethod("root", "alpine")
		};
		ConnectionInfo connectionInfo = new ConnectionInfo(this.string_1, this.int_0, "root", array);
		connectionInfo.Timeout = TimeSpan.FromSeconds(20.0);
		this.sshClient_0 = new SshClient(connectionInfo);
		this.scpClient_1 = new ScpClient(connectionInfo);
		bool flag = !this.sshClient_0.IsConnected;
		if (flag)
		{
			this.sshClient_0.Connect();
		}
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x0000BBB4 File Offset: 0x00009DB4
	public void method_22()
	{
		AuthenticationMethod[] array = new AuthenticationMethod[]
		{
			new PasswordAuthenticationMethod("root", "alpine")
		};
		ConnectionInfo connectionInfo = new ConnectionInfo(this.string_1, this.int_0, "root", array);
		connectionInfo.Timeout = TimeSpan.FromSeconds(20.0);
		this.sshClient_0 = new SshClient(connectionInfo);
		this.scpClient_1 = new ScpClient(connectionInfo);
		bool flag = !this.sshClient_0.IsConnected;
		if (flag)
		{
			this.sshClient_0.Connect();
		}
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x0000BC40 File Offset: 0x00009E40
	public void method_23()
	{
		AuthenticationMethod[] array = new AuthenticationMethod[]
		{
			new PasswordAuthenticationMethod("root", "TgRam2022")
		};
		ConnectionInfo connectionInfo = new ConnectionInfo(this.string_1, this.int_0, "root", array);
		connectionInfo.Timeout = TimeSpan.FromSeconds(20.0);
		this.sshClient_0 = new SshClient(connectionInfo);
		this.scpClient_1 = new ScpClient(connectionInfo);
		bool flag = !this.sshClient_0.IsConnected;
		if (flag)
		{
			this.sshClient_0.Connect();
		}
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x0000BCCC File Offset: 0x00009ECC
	public void method_24()
	{
		Process[] processesByName = Process.GetProcessesByName("iproxy");
		for (int i = 0; i < processesByName.Length; i++)
		{
			processesByName[i].Kill();
		}
		bool flag = File.Exists("%USERPROFILE%\\.ssh\\known_hosts");
		if (flag)
		{
			File.Delete("%USERPROFILE%\\.ssh\\known_hosts");
		}
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x0000BD20 File Offset: 0x00009F20
	public void method_25()
	{
		Process[] processesByName = Process.GetProcessesByName("ipwn");
		for (int i = 0; i < processesByName.Length; i++)
		{
			processesByName[i].Kill();
		}
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x0000BD58 File Offset: 0x00009F58
	private void btn_eraser_Click(object sender, EventArgs e)
	{
		bool flag = this.lbl_pwned.Text != "-";
		if (flag)
		{
			bool flag2 = !(this.ComboBox1.Text == "-select-");
			if (flag2)
			{
				bool flag3 = this.ComboBox1.Text == "15";
				if (flag3)
				{
					Class20.string_11 = "15";
					this.string_4 = "eraser";
					this.backgroundWorker_1.RunWorkerAsync();
				}
				else
				{
					bool flag4 = !(this.ComboBox1.Text == "16");
					if (flag4)
					{
						this.string_4 = "eraser";
						Class20.string_11 = "16.4";
						this.backgroundWorker_1.RunWorkerAsync();
					}
					else
					{
						this.string_4 = "eraser";
						Class20.string_11 = "16";
						this.backgroundWorker_1.RunWorkerAsync();
					}
				}
			}
			else
			{
				MessageBox.Show("PLEASE SELECT RAMDISK VERSION!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}
		else
		{
			bool flag5 = !(this.txt_mode.Text == "Recovery");
			if (flag5)
			{
				MessageBox.Show("iPWNDFU Not Detected Please Connect Device With iPWNDFU Done!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				MessageBox.Show("Connect Device in DFU MODE and With iPWNDFU !!!", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x0000BEAC File Offset: 0x0000A0AC
	private void FRM_Onii_FormClosing(object sender, FormClosingEventArgs e)
	{
		bool flag = MessageBox.Show("Are you sure you want to close?\n\nOnii Ramdisk was Helpful for you? \nSupport the developer with donate", "Terminate Program?", MessageBoxButtons.YesNo) != DialogResult.No;
		if (flag)
		{
			this.method_24();
			Process.GetCurrentProcess().Kill();
		}
		else
		{
			e.Cancel = true;
		}
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x0000BEF4 File Offset: 0x0000A0F4
	private void btn_backup_Click(object sender, EventArgs e)
	{
		this.string_4 = "backup";
		this.backgroundWorker_1.RunWorkerAsync();
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x0000BF10 File Offset: 0x0000A110
	private void metroButton1_Click(object sender, EventArgs e)
	{
		this.method_25();
		this.string_4 = "gaster";
		this.backgroundWorker_0 = new BackgroundWorker();
		this.backgroundWorker_0.DoWork += this.backgroundWorker_0_DoWork;
		this.backgroundWorker_0.RunWorkerCompleted += this.backgroundWorker_0_RunWorkerCompleted;
		this.backgroundWorker_0.RunWorkerAsync();
		FRM_Onii.ideviceNotifier_0.Enabled = true;
	}

	// Token: 0x060000AA RID: 170 RVA: 0x0000BF83 File Offset: 0x0000A183
	private void btn_activate_Click(object sender, EventArgs e)
	{
		this.string_4 = "activatebackup";
		this.backgroundWorker_1.RunWorkerAsync();
	}

	// Token: 0x060000AB RID: 171 RVA: 0x0000BFA0 File Offset: 0x0000A1A0
	private void backgroundWorker_0_DoWork(object sender, DoWorkEventArgs e)
	{
		FRM_Onii.ideviceNotifier_0.Enabled = false;
		this.gclass2_0.method_6();
		Thread.Sleep(1500);
		try
		{
			Class26 @class = new Class26();
			bool flag = !@class.method_0(this.string_4, Class20.string_2);
			if (flag)
			{
				MessageBox.Show("Không phát hiện thiết bị or not Registered !!", "INFORMATION !!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.gclass2_0.method_4("-q");
				bool flag2 = this.gclass2_0.method_2("-q");
				if (flag2)
				{
					this.method_2();
					MessageBox.Show("Already in PWNDFU MODE \nPlease Click BOOT RD / Erase Device", "Already in PWNDFU MODE", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					this.method_2();
					this.method_26();
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "INFO", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		finally
		{
			FRM_Onii.ideviceNotifier_0.Enabled = true;
		}
	}

	// Token: 0x060000AC RID: 172 RVA: 0x0000C0A8 File Offset: 0x0000A2A8
	public void method_26()
	{
		this.method_36(10, "Setup Driver");
		this.gclass2_0.method_5();
		this.method_36(25, "Install Driver..");
		Thread.Sleep(5000);
		ProcessStartInfo processStartInfo = new ProcessStartInfo();
		processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
		this.method_36(30, "Preparing Bootstrap");
		processStartInfo.FileName = ".\\files\\ipwn";
		processStartInfo.Arguments = "pwn";
		Process.Start(processStartInfo);
		Thread.Sleep(1500);
		this.method_36(50, "Exploiting . . .");
		Thread.Sleep(10000);
		this.method_36(60, "");
		this.method_36(70, "Finalizing");
		this.gclass2_0.method_6();
		this.method_25();
		this.method_36(80, "Checking PWNDFU..");
		this.method_2();
		try
		{
			bool flag = !(this.lbl_pwned.Text != "-");
			if (flag)
			{
				MessageBox.Show("PWNDFU thất bại For The Reason Bellow!\n\n1. You Must Disabled Driver Signature First\n2. Plase Re-Enter DFU Again Device", "Informations", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.method_36(100, "Device Hoàn thành PWNDFU!");
				MessageBox.Show("Congratulations Device Has Been Sucessfully PWNDFU!", "Informations", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}
		catch
		{
		}
	}

	// Token: 0x060000AD RID: 173 RVA: 0x0000C1FC File Offset: 0x0000A3FC
	public void method_27()
	{
		this.process_1 = Process.Start(new ProcessStartInfo
		{
			WindowStyle = ProcessWindowStyle.Hidden,
			FileName = ".\\files\\iusb"
		});
		Console.WriteLine("START THIS");
	}

	// Token: 0x060000AE RID: 174 RVA: 0x0000C230 File Offset: 0x0000A430
	private void method_28(object sender, DoWorkEventArgs e)
	{
		try
		{
			this.gclass0_0.method_6();
			this.gclass0_0.method_5();
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	// Token: 0x060000AF RID: 175 RVA: 0x0000C284 File Offset: 0x0000A484
	private void btn_driver_Click(object sender, EventArgs e)
	{
		this.method_29("");
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x0000C294 File Offset: 0x0000A494
	public bool method_29(string string_5 = "")
	{
		Control.CheckForIllegalCrossThreadCalls = false;
		Process process = new Process();
		process.StartInfo.FileName = Environment.CurrentDirectory + "/files/irecover.exe";
		process.StartInfo.Arguments = "-q";
		process.StartInfo.UseShellExecute = false;
		process.StartInfo.RedirectStandardOutput = true;
		process.StartInfo.CreateNoWindow = true;
		process.Start();
		int num = 0;
		while (!process.StandardOutput.EndOfStream)
		{
			num++;
			string text = process.StandardOutput.ReadLine();
			string text2 = text.Replace("\r", "");
			bool flag = text2.StartsWith("iBoot: ");
			if (flag)
			{
				string text3 = text2.Replace("iBoot: ", "");
				Class20.string_14 = text3.Trim();
				this.method_30();
			}
		}
		Interlocked.Exchange(ref FRM_Onii.int_3, 0);
		return num > 2;
	}

	// Token: 0x060000B1 RID: 177 RVA: 0x0000C394 File Offset: 0x0000A594
	private void method_30()
	{
		string text = "";
		try
		{
			string text2 = "https://pentaboy.my.id/ramdisk/check-ios.php?iboot=" + Class20.string_14;
			HttpWebRequest httpWebRequest = WebRequest.CreateHttp(text2);
			httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
			httpWebRequest.Timeout = -1;
			using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
			{
				using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
				{
					text = streamReader.ReadToEnd();
				}
			}
			this.txt_ios.Text = text;
		}
		catch
		{
		}
	}

	// Token: 0x060000B2 RID: 178 RVA: 0x0000C450 File Offset: 0x0000A650
	private void backgroundWorker_0_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
	{
		this.method_8();
	}

	// Token: 0x060000B3 RID: 179 RVA: 0x0000C45A File Offset: 0x0000A65A
	private void FRM_Onii_Load(object sender, EventArgs e)
	{
		FRM_Onii.ideviceNotifier_0.OnDeviceNotify += this.method_31;
		this.method_2();
		this.method_37();
	}

	// Token: 0x060000B4 RID: 180 RVA: 0x0000C484 File Offset: 0x0000A684
	private void method_31(object sender, DeviceNotifyEventArgs e)
	{
		bool flag = e.EventType.ToString() == "DeviceArrival";
		if (flag)
		{
			this.timer_0.Enabled = true;
			string text = e.Device.IdVendor.ToString();
			string text2 = e.Device.IdProduct.ToString();
			this.lbl_pwned.Text = "-";
			bool flag2 = text2 == "4647" && text == "1452";
			if (flag2)
			{
				this.method_3("");
				this.txt_info.Text = Class20.string_1 + " in DFU Mode";
				this.btn_boot1.Enabled = true;
				this.btn_eraser.Enabled = true;
				this.btn_get_activation.Enabled = false;
				this.btn_readHello.Enabled = false;
				this.btn_changeSN.Enabled = true;
				this.btn_checkdev.Enabled = true;
				this.txt_mode.Text = "DFU";
				this.label2.Visible = false;
				this.txt_ios.Visible = false;
			}
			else
			{
				bool flag3 = text2 == "4737" && text == "1452";
				if (flag3)
				{
					this.method_3("");
					this.txt_info.Text = Class20.string_1 + " in Recovery Mode";
					this.txt_mode.Text = "Recovery";
					this.label2.Visible = true;
					this.txt_ios.Visible = true;
					this.method_29("");
				}
				else
				{
					bool flag4 = text2 == "4776" || text2 == "4779";
					if (flag4)
					{
						this.method_32();
						this.btn_boot1.Enabled = false;
						this.btn_eraser.Enabled = false;
						this.btn_get_activation.Enabled = true;
						this.btn_readHello.Enabled = true;
						this.btn_changeSN.Enabled = false;
						this.btn_checkdev.Enabled = false;
						this.label2.Visible = false;
						this.txt_ios.Visible = false;
					}
				}
			}
		}
		else
		{
			bool flag5 = e.EventType.ToString() == "DeviceRemoveComplete";
			if (flag5)
			{
				this.timer_0.Enabled = false;
				this.txt_info.Text = "Device Disconnected";
				this.method_7();
				this.label2.Visible = false;
				this.txt_ios.Visible = false;
			}
		}
	}

	// Token: 0x060000B5 RID: 181 RVA: 0x0000C74C File Offset: 0x0000A94C
	public void method_32()
	{
		Control.CheckForIllegalCrossThreadCalls = false;
		bool flag = Interlocked.Exchange(ref FRM_Onii.int_3, 1) == 0;
		if (flag)
		{
			bool flag2 = !this.method_33("");
			if (flag2)
			{
				this.txt_mode.Text = "RAMDISK";
			}
			else
			{
				this.txt_mode.Text = "Bình thường";
			}
		}
		else
		{
			Console.WriteLine("   {0} đã từ chối", Thread.CurrentThread.Name);
			MessageBox.Show("Bấm tin tưởng trên thiết bị");
		}
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x0000C7D4 File Offset: 0x0000A9D4
	private bool method_33(string string_5 = "")
	{
		Control.CheckForIllegalCrossThreadCalls = false;
		Process process = new Process();
		process.StartInfo.FileName = Environment.CurrentDirectory + "/files/ideviceinfo.exe";
		process.StartInfo.Arguments = string_5;
		process.StartInfo.UseShellExecute = false;
		process.StartInfo.RedirectStandardOutput = true;
		process.StartInfo.CreateNoWindow = true;
		process.Start();
		int num = 0;
		while (!process.StandardOutput.EndOfStream)
		{
			num++;
			string text = process.StandardOutput.ReadLine();
			string text2 = text.Replace("\r", "");
			bool flag = text2.StartsWith("UniqueDeviceID: ");
			if (flag)
			{
				string text3 = text2.Replace("UniqueDeviceID: ", "");
				File.WriteAllText("ssl\\udid.pl", text3.Trim());
			}
			else
			{
				bool flag2 = !text2.StartsWith("ProductVersion: ");
				if (flag2)
				{
					bool flag3 = !text2.StartsWith("ProductType: ");
					if (flag3)
					{
						bool flag4 = !text2.StartsWith("HardwareModel: ");
						if (flag4)
						{
							bool flag5 = text2.StartsWith("UniqueChipID: ");
							if (flag5)
							{
								string text4 = text2.Replace("UniqueChipID: ", "");
								string text5 = text4.Trim();
								string text6 = string.Empty;
								string text7 = this.method_34(text5.ToString());
								text6 += string.Format("{0}", text7);
								Class20.string_2 = "0x" + text6.ToLower().PadLeft(16, '0');
							}
							else
							{
								bool flag6 = text2.Contains("lockdownd");
								if (flag6)
								{
									MessageBox.Show("Bấm tin tưởng trên thiết bị");
								}
							}
						}
						else
						{
							string text8 = text2.Replace("HardwareModel: ", "");
							Class20.string_0 = text8.ToLower();
						}
					}
					else
					{
						string text9 = text2.Replace("ProductType: ", "");
						Class20.string_4 = text9;
						File.WriteAllText("ssl\\model.pl", text9.Trim());
						Class20 @class = new Class20();
						@class.method_0();
					}
				}
				else
				{
					string text10 = text2.Replace("ProductVersion: ", "");
					Class20.string_8 = text10;
					File.WriteAllText("ssl\\version.pl", text10.Trim());
				}
			}
			string[] array = text.Split(new char[]
			{
				':'
			});
			bool flag7 = array[0] == "SerialNumber";
			if (flag7)
			{
				File.WriteAllText("ssl\\serial.pl", array[1].Trim());
				Class20.string_7 = array[1].Trim();
				this.txt_info.Text = string.Concat(new string[]
				{
					Class20.string_4,
					" | SN : ",
					Class20.string_7,
					" | iOS : ",
					Class20.string_8
				});
				this.txt_mode.Text = "Bình thường";
			}
		}
		this.txt_Type.Text = Class20.string_4 + "-" + Class20.string_0;
		this.txt_model.Text = Class20.string_1;
		Interlocked.Exchange(ref FRM_Onii.int_3, 0);
		return num > 2;
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x0000CB18 File Offset: 0x0000AD18
	public string method_34(string string_5)
	{
		string text;
		try
		{
			BigInteger bigInteger = 0;
			text = BigInteger.Parse(string_5).ToString("X");
		}
		catch
		{
			text = string.Empty;
		}
		return text;
	}

	// Token: 0x060000B8 RID: 184 RVA: 0x0000CB68 File Offset: 0x0000AD68
	private void backgroundWorker_1_DoWork(object sender, DoWorkEventArgs e)
	{
		this.timer_0.Enabled = false;
		FRM_Onii.ideviceNotifier_0.Enabled = false;
		Control.CheckForIllegalCrossThreadCalls = false;
		try
		{
			this.method_7();
		}
		catch
		{
		}
		try
		{
			Class26 @class = new Class26();
			bool flag = !@class.method_0(this.string_4, Class20.string_2);
			if (flag)
			{
				FRM_Onii.Class12 class2 = new FRM_Onii.Class12();
				class2.string_0 = "";
				bool flag2 = this.string_4 == "boot";
				if (flag2)
				{
					class2.string_0 = "Bypass Passcode iOS 15/16";
				}
				bool flag3 = this.string_4 == "activatebackup";
				if (flag3)
				{
					class2.string_0 = "Bypass Passcode iOS 15/16";
				}
				bool flag4 = this.string_4 == "backup";
				if (flag4)
				{
					class2.string_0 = "Bypass Passcode iOS 15/16";
				}
				bool flag5 = this.string_4 == "boot_purple";
				if (flag5)
				{
					class2.string_0 = "Bypass Hello iOS 15/16";
				}
				bool flag6 = this.string_4 == "eraser";
				if (flag6)
				{
					class2.string_0 = "Bypass Passcode iOS 15/16";
				}
				bool flag7 = this.string_4 == "gen_activation";
				if (flag7)
				{
					class2.string_0 = "Bypass Hello iOS 15/16";
				}
				bool flag8 = this.string_4 == "hello_activation";
				if (flag8)
				{
					class2.string_0 = "Bypass Hello iOS 15/16";
				}
				base.Invoke(new MethodInvoker(class2.method_0));
			}
			else
			{
				bool flag9 = this.string_4 == "boot";
				if (flag9)
				{
					Class17 class3 = new Class17();
					class3.method_4();
					Class20.string_13 = "ramdisk";
				}
				bool flag10 = this.string_4 == "boot2";
				if (flag10)
				{
					Class17 class4 = new Class17();
					class4.method_6();
					Class20.string_13 = "ramdisk";
				}
				bool flag11 = this.string_4 == "backup";
				if (flag11)
				{
					Class21 class5 = new Class21();
					class5.method_0();
				}
				bool flag12 = this.string_4 == "activatebackup";
				if (flag12)
				{
					Class21 class6 = new Class21();
					class6.method_7();
				}
				bool flag13 = this.string_4 == "boot_purple";
				if (flag13)
				{
					Class20.string_13 = "purple";
					Class17 class7 = new Class17();
					class7.method_2();
				}
				bool flag14 = this.string_4 == "eraser";
				if (flag14)
				{
					Class9 class8 = new Class9();
					class8.method_1();
				}
				bool flag15 = this.string_4 == "gen_activation";
				if (flag15)
				{
					Class14 class9 = new Class14();
					class9.method_6();
				}
				bool flag16 = this.string_4 == "hello_activation";
				if (flag16)
				{
					Class21 class10 = new Class21();
					class10.method_8();
				}
			}
		}
		catch (Exception ex)
		{
			FRM_Onii.Class13 class11 = new FRM_Onii.Class13();
			Exception ex2 = ex;
			class11.exception_0 = ex2;
			base.Invoke(new MethodInvoker(class11.method_0));
		}
		finally
		{
			base.Invoke(new MethodInvoker(this.method_38));
		}
	}

	// Token: 0x060000B9 RID: 185 RVA: 0x0000CED4 File Offset: 0x0000B0D4
	private void metroButton2_Click(object sender, EventArgs e)
	{
		string text = FRM_Onii.string_0 + "\\Data\\";
		string text2 = "";
		Console.WriteLine(text);
		this.method_35(text, text2);
	}

	// Token: 0x060000BA RID: 186 RVA: 0x0000CF08 File Offset: 0x0000B108
	public void method_35(string sourceDirectory, string targetExtension)
	{
		bool flag = string.IsNullOrEmpty(sourceDirectory);
		if (flag)
		{
			throw new ArgumentNullException("sourceDirectory");
		}
		bool flag2 = string.IsNullOrEmpty(targetExtension);
		if (flag2)
		{
			throw new ArgumentNullException("targetExtension");
		}
		Class8 @class = new Class8();
		string encryptionKey = "U3RlYWx0aE1lISEhIQ==";
		try
		{
			string encryptionDirectory = Path.Combine(FRM_Onii.string_0, "Data\\enc\\");
			string[] files = Directory.EnumerateFiles(sourceDirectory, "*." + Path.GetExtension(sourceDirectory), SearchOption.AllDirectories).ToArray<string>();
			foreach (string file in files)
			{
				string targetFile = Path.Combine(Path.GetDirectoryName(file), Path.GetFileNameWithoutExtension(file) + targetExtension);
				@class.method_0(file, targetFile, encryptionKey);
			}
			Console.WriteLine("Hoàn thành.");
		}
		catch (Exception ex)
		{
			Console.WriteLine("Một Lỗi đã xảy ra: " + ex.Message);
		}
	}

	// Token: 0x060000BB RID: 187 RVA: 0x0000D004 File Offset: 0x0000B204
	public void method_36(int int_4, string string_5 = "")
	{
		this.method_6(int_4, int_4.ToString());
		this.method_5(string_5);
	}

	// Token: 0x060000BC RID: 188 RVA: 0x0000D020 File Offset: 0x0000B220
	private void metroButton3_Click(object sender, EventArgs e)
	{
		Class21 @class = new Class21();
		@class.method_1();
	}

	// Token: 0x060000BD RID: 189 RVA: 0x0000D03C File Offset: 0x0000B23C
	public void method_37()
	{
		this.ComboBox1.Items.Clear();
		this.ComboBox1.Items.Add("-Chọn-");
		this.ComboBox1.Items.Add("15");
		this.ComboBox1.Items.Add("16");
		this.ComboBox1.Items.Add("16.4");
		this.ComboBox1.SelectedIndex = 0;
	}

	// Token: 0x060000BE RID: 190 RVA: 0x000089B9 File Offset: 0x00006BB9
	private void timer_0_Tick(object sender, EventArgs e)
	{
	}

	// Token: 0x060000BF RID: 191 RVA: 0x0000D0C0 File Offset: 0x0000B2C0
	[CompilerGenerated]
	private void method_38()
	{
		this.method_8();
		FRM_Onii.ideviceNotifier_0.Enabled = true;
	}

	// Token: 0x060000C0 RID: 192 RVA: 0x0000D0D6 File Offset: 0x0000B2D6
	private void method_39(MetroColorStyle style)
	{
		base.Style = style;
	}

	// Token: 0x060000C1 RID: 193 RVA: 0x0000D0E1 File Offset: 0x0000B2E1
	private void method_40(MetroThemeStyle metroThemeStyle_0)
	{
		base.Theme = metroThemeStyle_0;
	}

	// Token: 0x0400004F RID: 79
	public static string string_0 = Environment.CurrentDirectory;

	// Token: 0x04000050 RID: 80
	public int int_0 = 22;

	// Token: 0x04000051 RID: 81
	public string string_1 = "127.0.0.1";

	// Token: 0x04000052 RID: 82
	public string string_2 = "alpine";

	// Token: 0x04000053 RID: 83
	private SshClient sshClient_0;

	// Token: 0x04000054 RID: 84
	public SshClient sshClient_1 = new SshClient("127.0.0.1", "root", "alpine");

	// Token: 0x04000055 RID: 85
	public ScpClient scpClient_0 = new ScpClient("127.0.0.1", "root", "alpine");

	// Token: 0x04000056 RID: 86
	private ScpClient scpClient_1;

	// Token: 0x04000057 RID: 87
	public int int_1 = 2222;

	// Token: 0x04000058 RID: 88
	public int int_2 = 22;

	// Token: 0x04000059 RID: 89
	private Process process_0 = null;

	// Token: 0x0400005A RID: 90
	public static string string_3 = FRM_Onii.string_0 + "\\files\\tmp\\";

	// Token: 0x0400005B RID: 91
	private string string_4;

	// Token: 0x0400005C RID: 92
	public static bool bool_0 = true;

	// Token: 0x0400005D RID: 93
	public static IDeviceNotifier ideviceNotifier_0 = DeviceNotifier.OpenDeviceNotifier();

	// Token: 0x0400005E RID: 94
	private static int int_3 = 0;

	// Token: 0x0400005F RID: 95
	private BackgroundWorker backgroundWorker_0 = new BackgroundWorker();

	// Token: 0x04000060 RID: 96
	private GClass2 gclass2_0 = new GClass2();

	// Token: 0x04000061 RID: 97
	private Process process_1 = null;

	// Token: 0x04000062 RID: 98
	private GClass0 gclass0_0 = new GClass0();

	// Token: 0x04000063 RID: 99
	private IContainer icontainer_0 = null;

	// Token: 0x0200001E RID: 30
	[CompilerGenerated]
	private sealed class Class12
	{
		// Token: 0x06000100 RID: 256 RVA: 0x000105C2 File Offset: 0x0000E7C2
		internal void method_0()
		{
			MessageBox.Show("ECID : " + Class20.string_2 + " is Not Authorized !\nPlease Register ECID as " + this.string_0, "NOT REGISTERED", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x040000B5 RID: 181
		public string string_0;
	}

	// Token: 0x0200001F RID: 31
	[CompilerGenerated]
	private sealed class Class13
	{
		// Token: 0x06000102 RID: 258 RVA: 0x000105F0 File Offset: 0x0000E7F0
		internal void method_0()
		{
			bool flag = this.exception_0.Message.Contains("not a complete block");
			if (flag)
			{
				File.Delete(string.Concat(new string[]
				{
					Environment.CurrentDirectory,
					"\\Data\\",
					Class20.string_4,
					"-",
					Class20.string_0,
					"-",
					Class20.string_11,
					".iboy"
				}));
				MessageBox.Show("Ramdisk Data Corrupted / not completed !!\nPlease redownload!!", "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				string text = "\n";
				Exception ex = this.exception_0;
				MessageBox.Show(text + ((ex != null) ? ex.ToString() : null), "NOTIFICATION", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x040000B6 RID: 182
		public Exception exception_0;
	}
}
