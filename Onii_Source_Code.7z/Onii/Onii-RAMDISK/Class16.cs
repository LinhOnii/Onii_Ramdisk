﻿using System;

// Token: 0x02000003 RID: 3
internal class Class16
{
	// Token: 0x06000011 RID: 17 RVA: 0x00002C10 File Offset: 0x00000E10
	public void method_0()
	{
		bool flag = !Class20.string_14.Contains("iBoot-5540.140");
		if (flag)
		{
			bool flag2 = Class20.string_14.Contains("iBoot-5540.140");
			if (flag2)
			{
				Class20.string_8 = "";
			}
			else
			{
				Class20.string_8 = "";
			}
		}
		else
		{
			Class20.string_8 = "13.4.8";
		}
	}
}
