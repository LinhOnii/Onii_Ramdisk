﻿using System;
using System.Windows.Forms;

// Token: 0x02000008 RID: 8
internal class MainClass
{
	// Token: 0x06000049 RID: 73 RVA: 0x0000858D File Offset: 0x0000678D
	private static void Main(string[] args)
	{
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);
		Application.Run(new FRM_Onii());
	}
}
