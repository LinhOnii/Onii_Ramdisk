﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

// Token: 0x02000015 RID: 21
public class GClass2
{
	// Token: 0x060000DE RID: 222 RVA: 0x0000FE2C File Offset: 0x0000E02C
	private string method_0(string string_1, string string_2, bool bool_0 = false)
	{
		bool flag = !bool_0;
		string text;
		if (flag)
		{
			text = string.Format("install --inf=\"{0}\"", string_2);
		}
		else
		{
			text = string.Format("uninstall --inf=\"{0}\"", string_2);
		}
		Process process = new Process
		{
			StartInfo = new ProcessStartInfo
			{
				UseShellExecute = false,
				CreateNoWindow = true,
				FileName = string_1,
				Verb = "runas",
				Arguments = text,
				WorkingDirectory = Path.GetDirectoryName(string_1),
				RedirectStandardOutput = true,
				RedirectStandardError = true
			}
		};
		process.Start();
		return process.StandardOutput.ReadToEnd() + process.StandardError.ReadToEnd();
	}

	// Token: 0x060000DF RID: 223 RVA: 0x0000FEE4 File Offset: 0x0000E0E4
	private void method_1(bool bool_0 = false, bool bool_1 = false)
	{
		try
		{
			if (bool_0)
			{
				this.method_11("irecovery");
			}
			if (bool_1)
			{
				this.method_11("gaster");
			}
		}
		catch
		{
		}
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x0000FF34 File Offset: 0x0000E134
	public bool method_2(string string_1 = "-q")
	{
		this.method_1(true, false);
		string text = this.method_10(this.method_12(), string_1);
		bool flag = string.IsNullOrEmpty(text);
		if (flag)
		{
			throw new Exception("Not Found .");
		}
		bool flag2 = text.Contains("Unable to connect to device");
		if (flag2)
		{
			throw new Exception("Unable to connect to devic");
		}
		string[] array = Regex.Split(text, "\n");
		for (int i = 0; i < array.Count<string>(); i++)
		{
			string[] array2 = Regex.Split(array[i], ":");
			bool flag3 = array2[0] == "PWND";
			if (flag3)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x0000FFE4 File Offset: 0x0000E1E4
	public void method_3(string string_1 = "-q")
	{
		this.method_1(true, false);
		string text = this.method_10(this.method_12(), string_1);
		bool flag = string.IsNullOrEmpty(text);
		if (flag)
		{
			throw new Exception("Not Found .");
		}
		bool flag2 = text.Contains("Please connect device in dfu mode");
		if (flag2)
		{
			throw new Exception("Please connected device in dfu mode");
		}
		string[] array = Regex.Split(text, "\n");
		for (int i = 0; i < array.Count<string>(); i++)
		{
			string[] array2 = Regex.Split(array[i], ":");
			bool flag3 = array2[0] == "PWND";
			if (flag3)
			{
				return;
			}
		}
		throw new Exception("Fail process try again");
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x00010098 File Offset: 0x0000E298
	public void method_4(string string_1 = "-q")
	{
		this.method_1(true, false);
		string text = this.method_10(this.method_12(), string_1);
		bool flag = string.IsNullOrEmpty(text);
		if (flag)
		{
			throw new Exception("Not Found .");
		}
		bool flag2 = !text.Contains("Connect device in dfu mode");
		if (flag2)
		{
			string[] array = Regex.Split(text, "\n");
			for (int i = 0; i < array.Count<string>(); i++)
			{
				string[] array2 = Regex.Split(array[i], ":");
				bool flag3 = array2[0] == "MODE" && array2[1].Substring(1, 3) != "DFU";
				if (flag3)
				{
					throw new Exception("Please connect device to DFU mode ..");
				}
			}
			return;
		}
		throw new Exception("connect device in dfu mode");
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x00010166 File Offset: 0x0000E366
	public void method_5()
	{
		this.method_9("files/x64\\install-filter.exe", "pwndfu\\Apple_Mobile_Device_(DFU_Mode).inf", false);
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x0001017B File Offset: 0x0000E37B
	public void method_6()
	{
		this.method_9("files/x64\\install-filter.exe", "usbaapl64.inf", false);
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x00010190 File Offset: 0x0000E390
	public void method_7()
	{
		this.method_9("files/x64\\install-filter.exe", "Diags_CDC_Serial.inf", false);
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x000101A5 File Offset: 0x0000E3A5
	public void method_8()
	{
		this.method_9("files/x64\\install_x64.exe", "pwndfu\\Apple_Mobile_Device_(DFU_Mode).inf", true);
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x000101BC File Offset: 0x0000E3BC
	private void method_9(string string_1, string string_2, bool bool_0 = false)
	{
		bool flag = !bool_0;
		if (flag)
		{
		}
		bool flag2 = File.Exists(string_1);
		if (flag2)
		{
			try
			{
				this.method_0(string_1, string_2, bool_0);
				return;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}
		throw new Exception("Please Wait..");
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x00010218 File Offset: 0x0000E418
	private string method_10(string string_1, string string_2)
	{
		string text;
		try
		{
			Process process = new Process
			{
				StartInfo = new ProcessStartInfo
				{
					UseShellExecute = false,
					CreateNoWindow = true,
					FileName = string_1,
					Verb = "runas",
					Arguments = string_2,
					WorkingDirectory = Path.GetDirectoryName(string_1),
					RedirectStandardOutput = true,
					RedirectStandardError = true
				}
			};
			process.Start();
			text = process.StandardOutput.ReadToEnd() + process.StandardError.ReadToEnd();
		}
		catch (Exception ex)
		{
			throw new Exception(ex.Message);
		}
		return text;
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x000102CC File Offset: 0x0000E4CC
	public void method_11(string string_1)
	{
		try
		{
			Process[] processes = Process.GetProcesses();
			foreach (Process process in processes)
			{
				bool flag = process.ProcessName.ToLower().Contains(string_1);
				if (flag)
				{
					process.Kill();
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x060000EA RID: 234 RVA: 0x00010330 File Offset: 0x0000E530
	private string method_12()
	{
		bool flag = !File.Exists(this.string_0);
		if (flag)
		{
			throw new Exception("iData not found ! Please reinstall app.");
		}
		return this.string_0;
	}

	// Token: 0x040000A3 RID: 163
	private string string_0 = "files\\irecovery.exe";

	// Token: 0x02000022 RID: 34
	public static class GClass3
	{
		// Token: 0x06000108 RID: 264
		[DllImport("kernel32.dll")]
		private static extern IntPtr GetCurrentProcess();

		// Token: 0x06000109 RID: 265
		[DllImport("kernel32.dll")]
		private static extern IntPtr GetModuleHandle(string string_0);

		// Token: 0x0600010A RID: 266
		[DllImport("kernel32")]
		private static extern IntPtr GetProcAddress(IntPtr intptr_0, string string_0);

		// Token: 0x0600010B RID: 267
		[DllImport("kernel32.dll")]
		private static extern bool IsWow64Process(IntPtr intptr_0, out bool bool_0);

		// Token: 0x0600010C RID: 268 RVA: 0x000106E0 File Offset: 0x0000E8E0
		public static bool smethod_0()
		{
			bool flag3 = IntPtr.Size == 8;
			bool flag;
			if (flag3)
			{
				flag = true;
			}
			else
			{
				IntPtr moduleHandle = GClass2.GClass3.GetModuleHandle("kernel32");
				bool flag4 = moduleHandle != IntPtr.Zero;
				if (flag4)
				{
					IntPtr procAddress = GClass2.GClass3.GetProcAddress(moduleHandle, "IsWow64Process");
					bool flag2;
					bool flag5 = procAddress != IntPtr.Zero && (GClass2.GClass3.IsWow64Process(GClass2.GClass3.GetCurrentProcess(), out flag2) && flag2);
					if (flag5)
					{
						return true;
					}
				}
				flag = false;
			}
			return flag;
		}
	}
}
