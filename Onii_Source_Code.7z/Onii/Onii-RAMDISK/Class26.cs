﻿using System;
using System.IO;
using System.Net;
using System.Text;

// Token: 0x02000009 RID: 9
internal class Class26
{
	// Token: 0x0600004B RID: 75 RVA: 0x000085A8 File Offset: 0x000067A8
	public bool method_0(string string_0, string string_1)
	{
		uint num = Hash.smethod_0(string_0);
		bool flag = num > 1090182821U;
		if (flag)
		{
			bool flag2 = num <= 2192567781U;
			if (flag2)
			{
				bool flag3 = num == 2065103420U;
				if (flag3)
				{
					bool flag4 = string_0 == "boot_purple";
					if (flag4)
					{
						return this.method_1(string_1);
					}
				}
				else
				{
					bool flag5 = num == 2192567781U;
					if (flag5)
					{
						bool flag6 = string_0 == "eraser";
						if (flag6)
						{
							return this.method_1(string_1);
						}
					}
				}
			}
			else
			{
				bool flag7 = num != 3499401685U;
				if (flag7)
				{
					bool flag8 = num == 3782165653U;
					if (flag8)
					{
						bool flag9 = string_0 == "gaster";
						if (flag9)
						{
							return this.method_1(string_1);
						}
					}
					else
					{
						bool flag10 = num == 4199289758U && string_0 == "activatebackup";
						if (flag10)
						{
							return this.method_1(string_1);
						}
					}
				}
				else
				{
					bool flag11 = string_0 == "boot";
					if (flag11)
					{
						return this.method_1(string_1);
					}
				}
			}
		}
		else
		{
			bool flag12 = num <= 898523926U;
			if (flag12)
			{
				bool flag13 = num != 850372319U;
				if (flag13)
				{
					bool flag14 = num == 898523926U && string_0 == "gen_activation";
					if (flag14)
					{
						return this.method_1(string_1);
					}
				}
				else
				{
					bool flag15 = string_0 == "backup";
					if (flag15)
					{
						return this.method_1(string_1);
					}
				}
			}
			else
			{
				bool flag16 = num == 1027909092U;
				if (flag16)
				{
					bool flag17 = string_0 == "hello_activation";
					if (flag17)
					{
						return this.method_1(string_1);
					}
				}
				else
				{
					bool flag18 = num == 1090182821U && string_0 == "boot2";
					if (flag18)
					{
						return this.method_1(string_1);
					}
				}
			}
		}
		return false;
	}

	// Token: 0x0600004C RID: 76 RVA: 0x000087A8 File Offset: 0x000069A8
	private bool method_1(string string_0)
	{
		try
		{
			string text = "http://pentaboy.my.id/ramdisk/api.php?ecid=" + string_0;
			HttpWebRequest httpWebRequest = WebRequest.CreateHttp(text);
			httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
			httpWebRequest.Timeout = -1;
			string text2;
			using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
			{
				using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
				{
					text2 = streamReader.ReadToEnd();
				}
			}
			bool flag = text2 == "AUTHORIZED";
		}
		catch
		{
		}
		return true;
	}

	// Token: 0x0600004D RID: 77 RVA: 0x00008864 File Offset: 0x00006A64
	public string method_3(string string_0, Encoding encoding_0 = null)
	{
		bool flag = string_0 == null;
		string text;
		if (flag)
		{
			text = null;
		}
		else
		{
			encoding_0 = (encoding_0 ?? Encoding.UTF8);
			byte[] bytes = encoding_0.GetBytes(string_0);
			text = Convert.ToBase64String(bytes);
		}
		return text;
	}
}
