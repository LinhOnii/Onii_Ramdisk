﻿using System;
using System.Management;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;

// Token: 0x0200000C RID: 12
internal sealed class Class6
{
	// Token: 0x06000055 RID: 85 RVA: 0x00008964 File Offset: 0x00006B64
	private string method_0()
	{
		return "1.1.1.1";
	}

	// Token: 0x06000056 RID: 86
	[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
	private static extern bool CheckRemoteDebuggerPresent(IntPtr intptr_0, ref bool bool_0);

	// Token: 0x06000057 RID: 87 RVA: 0x0000897B File Offset: 0x00006B7B
	internal void method_1()
	{
		new Thread(new ParameterizedThreadStart(this.method_5)).Start(Thread.CurrentThread);
	}

	// Token: 0x06000058 RID: 88 RVA: 0x0000899A File Offset: 0x00006B9A
	internal void method_2()
	{
		new Thread(new ParameterizedThreadStart(this.method_9)).Start(Thread.CurrentThread);
	}

	// Token: 0x06000059 RID: 89 RVA: 0x000089B9 File Offset: 0x00006BB9
	public void method_3(string string_0)
	{
	}

	// Token: 0x0600005A RID: 90 RVA: 0x000089B9 File Offset: 0x00006BB9
	public void method_4(string string_0)
	{
	}

	// Token: 0x0600005B RID: 91 RVA: 0x000089B9 File Offset: 0x00006BB9
	internal void method_5(object object_0)
	{
	}

	// Token: 0x0600005C RID: 92 RVA: 0x000089B9 File Offset: 0x00006BB9
	public void method_6(string string_0)
	{
	}

	// Token: 0x0600005D RID: 93 RVA: 0x000089B9 File Offset: 0x00006BB9
	public void method_7(string string_0)
	{
	}

	// Token: 0x0600005E RID: 94 RVA: 0x000089B9 File Offset: 0x00006BB9
	public void method_8(string string_0)
	{
	}

	// Token: 0x0600005F RID: 95 RVA: 0x000089B9 File Offset: 0x00006BB9
	internal void method_9(object object_0)
	{
	}

	// Token: 0x06000060 RID: 96 RVA: 0x000089B9 File Offset: 0x00006BB9
	public void method_10()
	{
	}

	// Token: 0x06000061 RID: 97 RVA: 0x000089BC File Offset: 0x00006BBC
	public static string smethod_0()
	{
		string text = "MBID";
		try
		{
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard");
			ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
			foreach (ManagementBaseObject managementBaseObject in managementObjectCollection)
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				text = (string)managementObject["SerialNumber"];
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine("Lỗi: ", ex);
			text = "2";
		}
		return text.Trim();
	}

	// Token: 0x06000062 RID: 98 RVA: 0x00008A6C File Offset: 0x00006C6C
	public string method_11()
	{
		return "Baka";
	}

	// Token: 0x06000063 RID: 99 RVA: 0x000089B9 File Offset: 0x00006BB9
	[CompilerGenerated]
	private void method_12(string string_0, ref Class6.Struct6 struct6_0)
	{
	}

	// Token: 0x0200001C RID: 28
	[CompilerGenerated]
	[StructLayout(LayoutKind.Auto)]
	private struct Struct6
	{
		// Token: 0x040000B1 RID: 177
		public Class6 class6_0;

		// Token: 0x040000B2 RID: 178
		public string[] string_0;
	}
}
