﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using LibUsbDotNet.DeviceNotify;
using MetroFramework;
using MetroFramework.Controls;
using MetroFramework.Forms;

// Token: 0x02000010 RID: 16
public partial class FRM_Helper : MetroForm
{
	// Token: 0x0600007A RID: 122 RVA: 0x00009AC3 File Offset: 0x00007CC3
	public FRM_Helper()
	{
		this.InitializeComponent();
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00009AE8 File Offset: 0x00007CE8
	private void FRM_Helper_Load(object sender, EventArgs e)
	{
		FRM_Helper.ideviceNotifier_0.OnDeviceNotify += this.method_0;
		bool flag = !(Class20.string_9 == "0x8015") && !(Class20.string_9 == "0x8010");
		if (flag)
		{
			this.metroLabel8.Visible = true;
			this.metroLabel3.Visible = false;
			this.metroLabel7.Visible = false;
		}
		else
		{
			this.metroLabel8.Visible = false;
			this.metroLabel3.Visible = false;
			this.metroLabel7.Visible = true;
		}
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00009B8C File Offset: 0x00007D8C
	private void method_0(object sender, DeviceNotifyEventArgs e)
	{
		bool flag = !(e.EventType.ToString() == "DeviceArrival");
		if (flag)
		{
			bool flag2 = e.EventType.ToString() == "DeviceRemoveComplete";
			if (flag2)
			{
				this.timer_1.Start();
				this.panel1.Visible = false;
			}
		}
		else
		{
			string text = e.Device.IdVendor.ToString();
			string text2 = e.Device.IdProduct.ToString();
			bool flag3 = text2 == "4647" && text == "1452";
			if (flag3)
			{
				this.timer_1.Stop();
				this.panel1.Visible = true;
			}
			else
			{
				bool flag4 = text2 == "4737" && text == "1452";
				if (flag4)
				{
					this.timer_0.Stop();
					this.btn_Start.Text = "Retry";
				}
				else
				{
					bool flag5 = text2 == "4776" || text2 == "4779";
					if (flag5)
					{
						this.btn_Start.Text = "Retry";
					}
				}
			}
		}
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00009CE8 File Offset: 0x00007EE8
	private void btn_Cancel_Click(object sender, EventArgs e)
	{
		base.Close();
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00009CF4 File Offset: 0x00007EF4
	private void btn_Start_Click(object sender, EventArgs e)
	{
		bool flag = !(this.btn_Start.Text == "Close");
		if (flag)
		{
			this.timer_0.Start();
			this.lbl_start.ForeColor = Color.DarkGray;
		}
		else
		{
			base.Close();
		}
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00009D48 File Offset: 0x00007F48
	private void timer_0_Tick(object sender, EventArgs e)
	{
		FRM_Helper.int_0--;
		bool flag = FRM_Helper.int_0 == 0;
		if (flag)
		{
			this.timer_0.Stop();
			this.lbl_timer1.ForeColor = Color.DarkGray;
			FRM_Helper.int_0 = 6;
			this.timer_1.Start();
		}
		bool flag2 = FRM_Helper.int_0 == 5;
		if (flag2)
		{
			this.lbl_timer1.ForeColor = Color.White;
		}
		this.lbl_timer1.Text = "2. Press and hold the Side \r\nand Volume down buttons \r\ntogether (" + FRM_Helper.int_0.ToString() + ")";
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00009DE4 File Offset: 0x00007FE4
	private void timer_1_Tick(object sender, EventArgs e)
	{
		this.lbl_timer2.ForeColor = Color.White;
		FRM_Helper.int_1--;
		bool flag = FRM_Helper.int_1 == 0;
		if (flag)
		{
			this.timer_1.Stop();
			FRM_Helper.int_1 = 10;
			this.lbl_timer2.ForeColor = Color.DarkGray;
		}
		this.lbl_timer2.Text = "3. Release the Side button (" + FRM_Helper.int_1.ToString() + ")";
	}

	// Token: 0x04000037 RID: 55
	public static IDeviceNotifier ideviceNotifier_0 = DeviceNotifier.OpenDeviceNotifier();

	// Token: 0x04000038 RID: 56
	private GClass2 gclass2_0 = new GClass2();

	// Token: 0x04000039 RID: 57
	private static int int_0 = 6;

	// Token: 0x0400003A RID: 58
	private static int int_1 = 10;

	// Token: 0x0400003B RID: 59
	private IContainer icontainer_0 = null;
}
