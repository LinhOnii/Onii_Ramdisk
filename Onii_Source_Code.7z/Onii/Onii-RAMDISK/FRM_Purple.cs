﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO.Ports;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Controls;
using MetroFramework.Forms;

// Token: 0x02000012 RID: 18
public partial class FRM_Purple : MetroForm
{
	// Token: 0x060000C4 RID: 196 RVA: 0x0000EA96 File Offset: 0x0000CC96
	public FRM_Purple()
	{
		this.InitializeComponent();
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x0000EAAE File Offset: 0x0000CCAE
	private void metroButton3_Click(object sender, EventArgs e)
	{
		this.string_0 = "boot_purple";
		this.backgroundWorker_0.RunWorkerAsync();
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x0000EAC8 File Offset: 0x0000CCC8
	private void FRM_Purple_Load(object sender, EventArgs e)
	{
		string[] portNames = SerialPort.GetPortNames();
		ComboBox.ObjectCollection items = this.cBoxPORT.Items;
		object[] array2 = portNames;
		object[] array = array2;
		items.AddRange(array);
		this.metroButton1.Enabled = false;
		this.btn_Reboot.Enabled = false;
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x0000EB10 File Offset: 0x0000CD10
	private void btn_connect_Click(object sender, EventArgs e)
	{
		bool isOpen = this.serialPort_0.IsOpen;
		if (isOpen)
		{
			this.method_0();
		}
		else
		{
			try
			{
				this.serialPort_0.PortName = this.cBoxPORT.Text;
				this.serialPort_0.BaudRate = 115200;
				this.serialPort_0.DataBits = 8;
				this.serialPort_0.Open();
				this.btn_connect.Text = "CLOSE PORT";
				this.metroButton1.Enabled = true;
				this.btn_Reboot.Enabled = true;
				this.metroButton4.Enabled = false;
				this.cBoxPORT.Enabled = false;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x0000EBF0 File Offset: 0x0000CDF0
	public void method_0()
	{
		this.serialPort_0.Close();
		this.btn_connect.Text = "OPEN PORT";
		this.metroButton4.Enabled = true;
		this.cBoxPORT.Enabled = true;
		this.metroButton1.Enabled = false;
		this.btn_Reboot.Enabled = false;
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x0000EC50 File Offset: 0x0000CE50
	private void metroButton4_Click(object sender, EventArgs e)
	{
		string[] portNames = SerialPort.GetPortNames();
		this.cBoxPORT.Items.Clear();
		ComboBox.ObjectCollection items = this.cBoxPORT.Items;
		object[] array2 = portNames;
		object[] array = array2;
		items.AddRange(array);
	}

	// Token: 0x060000CA RID: 202 RVA: 0x0000EC90 File Offset: 0x0000CE90
	private void btn_Reboot_Click(object sender, EventArgs e)
	{
		bool isOpen = this.serialPort_0.IsOpen;
		if (isOpen)
		{
			try
			{
				this.serialPort_0.WriteLine("reset");
				this.method_0();
				return;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
		}
		MessageBox.Show("No COM-PORT Open", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
	}

	// Token: 0x060000CB RID: 203 RVA: 0x0000ED04 File Offset: 0x0000CF04
	private void metroButton1_Click(object sender, EventArgs e)
	{
		bool isOpen = this.serialPort_0.IsOpen;
		if (isOpen)
		{
			try
			{
				this.serialPort_0.WriteLine("Syscfg add SrNm " + this.metroTextBox1.Text);
				MessageBox.Show("Successfull Change Serial to " + this.metroTextBox1.Text, "Success !!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				this.serialPort_0.WriteLine("reset");
				this.method_0();
				return;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
		}
		MessageBox.Show("No COM-PORT Open \nPlease open port first!!", "Lỗi No SerialPort Open!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
	}

	// Token: 0x060000CC RID: 204 RVA: 0x0000EDBC File Offset: 0x0000CFBC
	private void metroButton5_Click(object sender, EventArgs e)
	{
		bool isOpen = this.serialPort_0.IsOpen;
		if (isOpen)
		{
			try
			{
				this.serialPort_0.WriteLine("nvram --set oblit-inprogress 5");
				this.serialPort_0.WriteLine("nvram --save");
				MessageBox.Show("Successfull Factory Reset !!!\n to start reset click reboot button! ", "Success !!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
		}
		MessageBox.Show("No COM-PORT Open \nPlease open port first!!", "Lỗi No SerialPort Open!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
	}

	// Token: 0x060000CD RID: 205 RVA: 0x0000EE50 File Offset: 0x0000D050
	private void metroButton2_Click(object sender, EventArgs e)
	{
		bool isOpen = this.serialPort_0.IsOpen;
		if (isOpen)
		{
			try
			{
				this.serialPort_0.WriteLine("Syscfg add Regn PA/A");
				this.serialPort_0.ReadExisting();
				MessageBox.Show("Successfull Change Serial to PA/A", "Success !!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
		}
		MessageBox.Show("No COM-PORT Open \nPlease open port first!!", "Lỗi No SerialPort Open!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
	}

	// Token: 0x060000CE RID: 206 RVA: 0x000089B9 File Offset: 0x00006BB9
	private void method_1(object sender, DoWorkEventArgs e)
	{
	}

	// Token: 0x060000CF RID: 207 RVA: 0x0000EEDC File Offset: 0x0000D0DC
	private void backgroundWorker_0_DoWork(object sender, DoWorkEventArgs e)
	{
		Class26 @class = new Class26();
		bool flag = !@class.method_0(this.string_0, Class20.string_2);
		if (flag)
		{
			string string_0 = "";
			bool flag2 = this.string_0 == "boot_purple";
			if (flag2)
			{
				string_0 = "Bypass Hello iOS 15";
			}
		}
		else
		{
			bool flag3 = this.string_0 == "boot_purple";
			if (flag3)
			{
				Class17 class3 = new Class17();
				class3.method_0();
			}
		}
	}

	// Token: 0x04000088 RID: 136
	private string string_0;

	// Token: 0x04000089 RID: 137
	public string string_1;

	// Token: 0x02000020 RID: 32
	[CompilerGenerated]
	private sealed class Class11
	{
		// Token: 0x040000B7 RID: 183
		public string string_0;
	}
}
