﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Ionic.Zip;

// Token: 0x0200000F RID: 15
internal class Class9
{
	// Token: 0x06000070 RID: 112 RVA: 0x00008DA4 File Offset: 0x00006FA4
	public void method_0()
	{
		Class8 @class = new Class8();
		this.method_6();
		this.method_3(1);
		bool flag = File.Exists(".\\Data\\" + Class9.string_2 + ".iboy");
		if (flag)
		{
			Console.WriteLine("Ada File");
			string text = string.Concat(new string[]
			{
				Class9.string_0,
				"\\files\\swp\\",
				Class20.string_4,
				"-",
				Class20.string_0,
				".zip"
			});
			string text2 = Class9.string_0 + "\\Data\\" + Class9.string_2 + ".iboy";
			string text3 = "U3RlYWx0aE1lISEhIQ==";
			@class.method_1(text2, text, text3);
			this.method_3(3);
			this.method_4(Class20.string_4 + "-" + Class20.string_0 + ".zip");
			this.method_3(3);
			File.Delete(text);
			this.method_2();
		}
		else
		{
			this.class17_0.method_18(Class9.string_3, Class9.string_2 + ".iboy");
		}
		this.method_6();
	}

	// Token: 0x06000071 RID: 113 RVA: 0x00008EC8 File Offset: 0x000070C8
	public void method_1()
	{
		string string_ = Class20.string_4;
		string text = string_;
		uint num = Hash.smethod_0(text);
		bool flag = num > 1084645515U;
		if (flag)
		{
			bool flag2 = num > 2320541943U;
			if (flag2)
			{
				bool flag3 = num > 3579376904U;
				if (flag3)
				{
					bool flag4 = num > 3680042618U;
					if (flag4)
					{
						bool flag5 = num != 4191237488U;
						if (flag5)
						{
							bool flag6 = num == 4258347964U && text == "iPad6,7";
							if (flag6)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag7 = text == "iPad6,3";
							if (flag7)
							{
								this.method_0();
								return;
							}
						}
					}
					else
					{
						bool flag8 = num != 3663264999U;
						if (flag8)
						{
							bool flag9 = num == 3680042618U && text == "iPhone8,2";
							if (flag9)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag10 = text == "iPhone8,1";
							if (flag10)
							{
								this.method_0();
								return;
							}
						}
					}
				}
				else
				{
					bool flag11 = num <= 3266955512U;
					if (flag11)
					{
						bool flag12 = num == 2337319562U;
						if (flag12)
						{
							bool flag13 = text == "iPhone10,1";
							if (flag13)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag14 = num == 3266955512U && text == "iPad7,11";
							if (flag14)
							{
								this.method_0();
								return;
							}
						}
					}
					else
					{
						bool flag15 = num == 3317288369U;
						if (flag15)
						{
							bool flag16 = text == "iPad7,12";
							if (flag16)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag17 = num == 3579376904U && text == "iPhone8,4";
							if (flag17)
							{
								this.method_0();
								return;
							}
						}
					}
				}
			}
			else
			{
				bool flag18 = num <= 2253431467U;
				if (flag18)
				{
					bool flag19 = num > 1118200753U;
					if (flag19)
					{
						bool flag20 = num != 1134978372U;
						if (flag20)
						{
							bool flag21 = num == 2253431467U && text == "iPhone10,6";
							if (flag21)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag22 = text == "iPad5,4";
							if (flag22)
							{
								this.method_0();
								return;
							}
						}
					}
					else
					{
						bool flag23 = num != 1101423134U;
						if (flag23)
						{
							bool flag24 = num == 1118200753U && text == "iPad5,3";
							if (flag24)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag25 = text == "iPad5,2";
							if (flag25)
							{
								this.method_0();
								return;
							}
						}
					}
				}
				else
				{
					bool flag26 = num <= 2286986705U;
					if (flag26)
					{
						bool flag27 = num != 2270209086U;
						if (flag27)
						{
							bool flag28 = num == 2286986705U;
							if (flag28)
							{
								bool flag29 = text == "iPhone10,4";
								if (flag29)
								{
									this.method_0();
									return;
								}
							}
						}
						else
						{
							bool flag30 = text == "iPhone10,5";
							if (flag30)
							{
								this.method_0();
								return;
							}
						}
					}
					else
					{
						bool flag31 = num == 2303764324U;
						if (flag31)
						{
							bool flag32 = text == "iPhone10,3";
							if (flag32)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag33 = num == 2320541943U;
							if (flag33)
							{
								bool flag34 = text == "iPhone10,2";
								if (flag34)
								{
									this.method_0();
									return;
								}
							}
						}
					}
				}
			}
		}
		else
		{
			bool flag35 = num <= 291253989U;
			if (flag35)
			{
				bool flag36 = num > 218008307U;
				if (flag36)
				{
					bool flag37 = num > 251563545U;
					if (flag37)
					{
						bool flag38 = num != 268341164U;
						if (flag38)
						{
							bool flag39 = num == 291253989U && text == "iPad6,11";
							if (flag39)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag40 = text == "iPad7,6";
							if (flag40)
							{
								this.method_0();
								return;
							}
						}
					}
					else
					{
						bool flag41 = num != 240921132U;
						if (flag41)
						{
							bool flag42 = num == 251563545U;
							if (flag42)
							{
								bool flag43 = text == "iPad7,1";
								if (flag43)
								{
									this.method_0();
									return;
								}
							}
						}
						else
						{
							bool flag44 = text == "iPad6,12";
							if (flag44)
							{
								this.method_0();
								return;
							}
						}
					}
				}
				else
				{
					bool flag45 = num > 80824001U;
					if (flag45)
					{
						bool flag46 = num != 201230688U;
						if (flag46)
						{
							bool flag47 = num == 218008307U && text == "iPad7,3";
							if (flag47)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag48 = text == "iPad7,2";
							if (flag48)
							{
								this.method_0();
								return;
							}
						}
					}
					else
					{
						bool flag49 = num != 13713525U;
						if (flag49)
						{
							bool flag50 = num == 80824001U && text == "iPad6,8";
							if (flag50)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag51 = text == "iPad6,4";
							if (flag51)
							{
								this.method_0();
								return;
							}
						}
					}
				}
			}
			else
			{
				bool flag52 = num <= 897947417U;
				if (flag52)
				{
					bool flag53 = num <= 318674021U;
					if (flag53)
					{
						bool flag54 = num != 301896402U;
						if (flag54)
						{
							bool flag55 = num == 318674021U && text == "iPad7,5";
							if (flag55)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag56 = text == "iPad7,4";
							if (flag56)
							{
								this.method_0();
								return;
							}
						}
					}
					else
					{
						bool flag57 = num == 876599987U;
						if (flag57)
						{
							bool flag58 = text == "iPhone9,4";
							if (flag58)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag59 = num == 897947417U && text == "iPod9,1";
							if (flag59)
							{
								this.method_0();
								return;
							}
						}
					}
				}
				else
				{
					bool flag60 = num <= 960488082U;
					if (flag60)
					{
						bool flag61 = num != 926932844U;
						if (flag61)
						{
							bool flag62 = num == 960488082U && text == "iPhone9,3";
							if (flag62)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag63 = text == "iPhone9,1";
							if (flag63)
							{
								this.method_0();
								return;
							}
						}
					}
					else
					{
						bool flag64 = num == 977265701U;
						if (flag64)
						{
							bool flag65 = text == "iPhone9,2";
							if (flag65)
							{
								this.method_0();
								return;
							}
						}
						else
						{
							bool flag66 = num == 1084645515U && text == "iPad5,1";
							if (flag66)
							{
								this.method_0();
								return;
							}
						}
					}
				}
			}
		}
		MessageBox.Show("Sorry " + Class20.string_4 + " Không hỗ trợ For Now", "Onii Ramdisk", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
	}

	// Token: 0x06000072 RID: 114 RVA: 0x0000960C File Offset: 0x0000780C
	public void method_2()
	{
		this.method_5(10, "==> Truyền Boot bước 1 <==");
		Console.WriteLine("SEND 1");
		Class9.smethod_0(".\\files\\irecovery -f .\\files\\shsh\\" + Class20.string_9 + ".shsh");
		Class9.smethod_0(".\\files\\irecovery -f .\\files\\tmp\\iBSS.img4");
		this.method_3(2);
		Console.WriteLine("SEND 2");
		Class9.smethod_0(".\\files\\irecovery -f .\\files\\tmp\\iBSS.img4");
		File.Delete(".\\files\\tmp\\iBSS.img4");
		this.method_3(3);
		this.method_5(30, "==> Truyền Boot bước 2 <==");
		bool flag = !(Class20.string_9 == "8010") && !(Class20.string_9 == "8015") && !(Class20.string_9 == "8011") && !(Class20.string_9 == "8012");
		if (flag)
		{
			Console.WriteLine("SEND 3");
			this.method_3(4);
			Class9.smethod_0(".\\files\\irecovery -f .\\files\\tmp\\iBEC.img4");
		}
		else
		{
			Console.WriteLine("Skip IBEC");
		}
		this.method_3(3);
		Class9.smethod_0(".\\files\\irecovery -c \"setenv oblit-inprogress 5\"");
		this.method_5(70, "==> Cài Boot args");
		this.method_3(3);
		Class9.smethod_0(".\\files\\irecovery -c \"saveenv\"");
		this.method_3(4);
		Console.WriteLine("Done");
		Class9.smethod_0(".\\files\\irecovery -c reset");
		this.method_5(100, "Device Hoàn thành Erase in Next Boot");
		this.method_3(6);
		this.method_6();
		Console.WriteLine("==> Truyền Done done");
	}

	// Token: 0x06000073 RID: 115 RVA: 0x0000978C File Offset: 0x0000798C
	public void method_3(int int_0)
	{
		int num = int_0 * 1000;
		Thread.Sleep(num);
	}

	// Token: 0x06000074 RID: 116 RVA: 0x000097AC File Offset: 0x000079AC
	public void method_4(string string_4)
	{
		try
		{
			Console.WriteLine("==>> Started Extract Bootchain.ZIP <==\n");
			this.method_5(50, "==> Giải nén Bootchain <==");
			this.method_6();
			string text = Class9.string_0 + "/files/tmp/";
			using (ZipFile zipFile = ZipFile.Read(Class9.string_0 + "/files/swp/" + string_4))
			{
				zipFile.Password = "iBoyRamdisk123!@#";
				zipFile.ExtractSelectedEntries("name=iBSS.img4", null, text, ExtractExistingFileAction.OverwriteSilently);
				bool flag = Class20.string_9 == "8000" || Class20.string_9 == "8003" || Class20.string_9 == "7000" || Class20.string_9 == "7001";
				if (flag)
				{
					zipFile.ExtractSelectedEntries("name=iBEC.img4", null, text, ExtractExistingFileAction.OverwriteSilently);
				}
			}
			this.method_5(100, "==> Giải nén Bootchain <==");
			Console.WriteLine("=>> iBSS Boot đã được giải nén <==");
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Cảnh báo !", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x06000075 RID: 117 RVA: 0x000098D8 File Offset: 0x00007AD8
	private static void smethod_0(string string_4)
	{
		ProcessStartInfo processStartInfo = new ProcessStartInfo("cmd", "/c " + string_4);
		processStartInfo.RedirectStandardOutput = true;
		processStartInfo.UseShellExecute = false;
		processStartInfo.CreateNoWindow = true;
		Process process = new Process();
		process.StartInfo = processStartInfo;
		process.Start();
		string text = process.StandardOutput.ReadToEnd();
		Console.WriteLine(text);
	}

	// Token: 0x06000076 RID: 118 RVA: 0x0000993C File Offset: 0x00007B3C
	public void method_5(int int_0, string string_4 = "")
	{
		Class9.Class10 @class = new Class9.Class10();
		@class.int_0 = int_0;
		@class.FRM_Onii_0 = (FRM_Onii)Application.OpenForms["FRM_Onii"];
		@class.FRM_Onii_0.Invoke(new MethodInvoker(@class.method_0));
		bool bool_ = Class20.bool_0;
		if (bool_)
		{
			Console.WriteLine(@class.int_0.ToString() + string_4);
		}
		@class.FRM_Onii_0.method_5(string_4);
	}

	// Token: 0x06000077 RID: 119 RVA: 0x000099B8 File Offset: 0x00007BB8
	public void method_6()
	{
		try
		{
			bool flag = Directory.Exists(Class9.string_1);
			if (flag)
			{
				Directory.Delete(Class9.string_1, true);
			}
			Thread.Sleep(1000);
			Directory.CreateDirectory(Class9.string_1);
		}
		catch (Exception)
		{
		}
	}

	// Token: 0x04000032 RID: 50
	public static string string_0 = Environment.CurrentDirectory;

	// Token: 0x04000033 RID: 51
	public static string string_1 = Class9.string_0 + "\\files\\tmp\\";

	// Token: 0x04000034 RID: 52
	public static string string_2 = string.Concat(new string[]
	{
		Class20.string_4,
		"-",
		Class20.string_0,
		"-",
		Class20.string_11
	});

	// Token: 0x04000035 RID: 53
	public static string string_3 = string.Concat(new string[]
	{
		"https://sin1.contabostorage.com/47c5cad1ab9a448dbb8f520da61dcd7b:ramdisk2/",
		Class20.string_11,
		"/",
		Class9.string_2,
		".iboy"
	});

	// Token: 0x04000036 RID: 54
	private Class17 class17_0 = new Class17();

	// Token: 0x0200001D RID: 29
	[CompilerGenerated]
	private sealed class Class10
	{
		// Token: 0x060000FE RID: 254 RVA: 0x000105A2 File Offset: 0x0000E7A2
		internal void method_0()
		{
			this.FRM_Onii_0.method_6(this.int_0, this.int_0.ToString());
		}

		// Token: 0x040000B3 RID: 179
		public FRM_Onii FRM_Onii_0;

		// Token: 0x040000B4 RID: 180
		public int int_0;
	}
}
